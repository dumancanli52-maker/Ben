﻿function global:Convert-BTeamName([string]$name) {
    $name = ($name -replace '\s*\(K\)\s*$', ' W').ToLowerInvariant().Replace('ı', 'i').Normalize([Text.NormalizationForm]::FormKD)
    return ($name -replace '[^a-z0-9]', '')
}

function global:Read-BNumber($value) {
    $number = 0.0
    $inputText = ([string]$value).Replace(',', '.')
    if ([double]::TryParse($inputText, [Globalization.NumberStyles]::Float, $global:BInv, [ref]$number) -and
        -not [double]::IsNaN($number) -and -not [double]::IsInfinity($number)) { return $number }
    return $null
}

function global:Get-BNameMatch([string]$name, [string]$other, [string]$teamId, $aliases) {
    if ($aliases.ContainsKey($name)) {
        if ([string]$aliases[$name] -ceq $teamId) { return 4 }
        return 0
    }
    if ($name.Length -ge 3 -and $name -eq $other) { return 3 }
    if ([Math]::Min($name.Length, $other.Length) -ge 6 -and ($name.Contains($other) -or $other.Contains($name))) { return 1 }
    return 0
}

# 113. düzeltme: ad tam tutmayınca kelimeyle eşleştirme (ikinci geçiş). "Telekom Bonn" ↔ "Bonn", "CSKA Moskova" ↔ "CSKA Moscow",
# "Dabrowa Gorn." ↔ "Dabrowa Gornicza", "Legia Warsz." ↔ "Legia". İki takım da tutmalı, saat farkı 45 dakikayı geçmemeli, tek aday kalmalı;
# kadın / erkek aynı olmalı. 2.824 eski maçta denendi: eşleşme %61'den %80'e çıktı, yeni eşleşen 554 maçın 550'sinde skor birebir aynı (kalan 4'ü kaynak farkı).
$global:BStopTokens = @{}
foreach ($w in 'basket basketbol basketball baloncesto pallacanestro bc bk kk cb cd club sk spor sport sports bbk ss as asd us sc ac fc the de del la le di real team city united st saint univ university state college ks'.Split(' ')) { $global:BStopTokens[$w] = $true }
$global:BKelimeEsles = 0
function global:Get-BNameTokens([string]$raw) {
    $s = ([string]$raw).Trim()
    $w = ($s -cmatch '\(K\)\s*$') -or ($s -cmatch '\sW$')
    $s = ($s -creplace '\s*\(K\)\s*$', '') -creplace '\sW$', ''
    $s = $s.ToLowerInvariant().Replace('ı', 'i')
    $out = New-Object System.Collections.ArrayList
    foreach ($t0 in ($s -split '[\s\-/]+')) {
        $ab = $t0.EndsWith('.')
        $t = ($t0.Normalize([Text.NormalizationForm]::FormKD) -replace '[^a-z0-9]', '')
        if ($t.Length -lt 3 -or $global:BStopTokens.ContainsKey($t)) { continue }
        [void]$out.Add(@($t, $ab))
    }
    return @{ w = $w; t = $out }
}
function global:Test-BTokenMatch([string]$nraw, [string]$fraw, [bool]$kadin) {
    $n = Get-BNameTokens $nraw; $f = Get-BNameTokens $fraw
    if ((($n.w -or $kadin) -ne $f.w) -or $n.t.Count -eq 0 -or $f.t.Count -eq 0) { return $false }
    foreach ($x in $n.t) {
        $a = [string]$x[0]; $ab = [bool]$x[1]
        foreach ($y in $f.t) {
            $b = [string]$y[0]
            if ([string]::Equals($a, $b, [StringComparison]::Ordinal)) { return $true }
            if ($ab -and $a.Length -ge 3 -and $b.StartsWith($a, [StringComparison]::Ordinal)) { return $true }
            if ([Math]::Min($a.Length, $b.Length) -ge 5 -and ($a.StartsWith($b, [StringComparison]::Ordinal) -or $b.StartsWith($a, [StringComparison]::Ordinal))) { return $true }
        }
    }
    return $false
}

function global:Find-BForecastFixture($match, $fixtures, $aliases) {
    $homeName = Convert-BTeamName $match.Home
    $away = Convert-BTeamName $match.Away
    $best = $null; $bestScore = 0; $tied = $false
    foreach ($f in $fixtures) {
        if ([Math]::Abs($f.Kick - $match.Kick) -gt 2700) { continue }
        $h = Get-BNameMatch $homeName $f.Home $f.HomeId $aliases
        $a = Get-BNameMatch $away $f.Away $f.AwayId $aliases
        if ($h -eq 0 -or $a -eq 0) { continue }
        $quality = $h + $a
        if ($quality -gt $bestScore) { $best = $f; $bestScore = $quality; $tied = $false }
        elseif ($quality -eq $bestScore) { $tied = $true }
    }
    if ($null -ne $best -and -not $tied) { return $best }
    # 113: ikinci geçiş, kelimeyle (yukarıdaki açıklama)
    $kd = [bool]([string]$match.League -match 'kad[ıi]n|wnbl|women|bayan')
    $hit = $null; $n = 0
    foreach ($f in $fixtures) {
        if ([Math]::Abs($f.Kick - $match.Kick) -gt 2700 -or -not $f.HomeRaw) { continue }
        if ((Test-BTokenMatch ([string]$match.Home) ([string]$f.HomeRaw) $kd) -and (Test-BTokenMatch ([string]$match.Away) ([string]$f.AwayRaw) $kd)) { $hit = $f; $n++ }
    }
    if ($n -eq 1) { $global:BKelimeEsles++; return $hit }
    return $null
}

function global:Get-BUpcomingLines($event) {
    $byLine = @{}
    $ambiguous = @{}
    foreach ($market in @($event['MA'])) {
        if ($market -isnot [System.Collections.IDictionary] -or [string]$market['MTID'] -ne '149') { continue }
        $line = Read-BNumber $market['SOV']
        if ($null -eq $line -or $line -le 0 -or [Math]::Abs(($line % 1) - 0.5) -gt 0.000001) { continue }
        $prices = @{}
        foreach ($outcome in @($market['OCA'])) {
            if ($outcome -isnot [System.Collections.IDictionary]) { continue }
            $price = Read-BNumber $outcome['O']
            if ($null -ne $price -and $price -gt 1) { $prices[[string]$outcome['N']] = $price }
        }
        if (-not ($prices.ContainsKey('1') -and $prices.ContainsKey('2'))) {
            if (-not $byLine.ContainsKey($line)) { $byLine[$line] = [pscustomobject]@{ Line = $line; Under = $null; Over = $null } }
            continue
        }
        if ($byLine.ContainsKey($line) -and $null -ne $byLine[$line].Under -and ($byLine[$line].Under -ne $prices['1'] -or $byLine[$line].Over -ne $prices['2'])) {
            $ambiguous[$line] = $true
        }
        $byLine[$line] = [pscustomobject]@{ Line = $line; Under = $prices['1']; Over = $prices['2'] }
    }
    foreach ($key in ($byLine.Keys | Sort-Object)) {
        if ($ambiguous.ContainsKey($key)) { [pscustomobject]@{ Line = $key; Under = $null; Over = $null } }
        else { $byLine[$key] }
    }
}

# 78. düzeltme: Nesine maç sonucu (uzatmalar dahil, iki seçenek) oranı · pazar 142, 1 = ev, 2 = deplasman
function global:Get-BWinnerOdds($event) {
    foreach ($market in @($event['MA'])) {
        if ($market -isnot [System.Collections.IDictionary] -or [string]$market['MTID'] -ne '142') { continue }
        $prices = @{}
        foreach ($outcome in @($market['OCA'])) {
            if ($outcome -isnot [System.Collections.IDictionary]) { continue }
            $price = Read-BNumber $outcome['O']
            if ($null -ne $price -and $price -gt 1) { $prices[[string]$outcome['N']] = $price }
        }
        if ($prices.ContainsKey('1') -and $prices.ContainsKey('2')) { return [pscustomobject]@{ Home = $prices['1']; Away = $prices['2'] } }
    }
}

function global:Find-BNesineCode($event, [string[]]$codes, [string]$providerId, [string]$providerField) {
    if ($event -isnot [System.Collections.IDictionary]) { return }
    $eventProvider = [string]$event[$providerField]
    if ($providerId -and $codes.Count -eq 1 -and $eventProvider -and $eventProvider -ne '0') {
        if ($eventProvider -eq $providerId) { return $codes[0] }
        return
    }
    foreach ($code in $codes) {
        if ($code -eq [string]$event['C'] -or $code -eq [string]$event['NID']) { return $code }
    }
}

function global:Get-BUpcomingBulletin([long]$now, [long]$end, [string[]]$codes, [string]$providerId) {
    $raw = ConvertFrom-BJson (Invoke-BGet $global:BNesUrl 'https://www.nesine.com/' $null)
    if ($null -eq $raw -or $null -eq $raw['sg'] -or $null -eq $raw['sg']['EA']) {
        throw 'Bülten okunamadı.'
    }
    $sg = $raw['sg']
    $league = @{}
    foreach ($l in @($sg['LA'])) {
        if ($l -is [System.Collections.IDictionary] -and $l.ContainsKey('LID')) { $league[[string]$l['LID']] = [string]$l['N'] }
    }
    $sport = Get-BNesType @($sg['EA']) $league
    $seen = @{}
    foreach ($e in @($sg['EA'])) {
        if ($e -isnot [System.Collections.IDictionary] -or [string]$e['TYPE'] -ne $sport) { continue }
        $code = if ($codes.Count) { Find-BNesineCode $e $codes $providerId 'BRID' } else { [string]$e['C'] }
        if (-not $code) { continue }
        $kick = 0L
        if (-not [long]::TryParse([string]$e['ESD'], [ref]$kick)) { continue }
        $kick = [long][Math]::Floor($kick / 1000.0)
        if ($kick -le 0 -or (-not $providerId -and ($kick -le $now -or $kick -ge $end)) -or $seen.ContainsKey($code)) { continue }
        $seen[$code] = $true
        $started = $kick -le ([DateTimeOffset]::UtcNow).ToUnixTimeSeconds()
        $lines = @(); $winner = $null
        if (-not $started) { $lines = @(Get-BUpcomingLines $e); $winner = Get-BWinnerOdds $e }
        [pscustomobject]@{
            Code = $code; Kick = $kick; Home = [string]$e['HN']; Away = [string]$e['AN']
            League = $league[[string]$e['LC']]; Lines = $lines
            WinnerHome = $(if ($winner) { $winner.Home }); WinnerAway = $(if ($winner) { $winner.Away })
            IsPast = $started; Actual = $null
        }
    }
}

function global:Read-BForecastHistory($wanted, [string]$seedPath) {
    $byTeam = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    foreach ($key in $wanted) { $byTeam[$key] = New-Object 'System.Collections.Generic.List[object]' }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]'
    $paths = @((Join-Path $Shared.DataDir 'basket_mac_sonuclari.csv'), (Join-Path $Shared.DataDir 'basket_flash_maclar.csv'), $seedPath)
    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $file = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        $reader = [IO.StreamReader]::new($file, [Text.Encoding]::UTF8)
        try {
            $columns = @{}
            $header = $reader.ReadLine()
            if (-not $header) { continue }
            $parts = $header.Split(';')
            for ($i = 0; $i -lt $parts.Count; $i++) { $columns[$parts[$i]] = $i }
            $idColumn = if ($columns.ContainsKey('mac_id')) { 'mac_id' } else { 'id' }
            $required = @($idColumn, 'zaman', 'ev_id', 'dep_id', 'skor_ev', 'skor_dep')
            $missing = @($required | Where-Object { -not $columns.ContainsKey($_) })
            if ($missing.Count) { continue }
            $maxIndex = ($required | ForEach-Object { $columns[$_] } | Measure-Object -Maximum).Maximum
            while ($null -ne ($record = $reader.ReadLine())) {
                $c = $record.Split(';')
                if ($c.Length -le $maxIndex) { continue }
                $hKey = $c[$columns['ev_id']] + '|ev'
                $aKey = $c[$columns['dep_id']] + '|dep'
                if (-not ($byTeam.ContainsKey($hKey) -or $byTeam.ContainsKey($aKey))) { continue }
                $mid = $c[$columns[$idColumn]]
                if (-not $mid -or $seen.Contains($mid)) { continue }
                $date = [datetime]::MinValue; $hs = 0; $as = 0
                if (-not [datetime]::TryParseExact($c[$columns['zaman']], 'yyyy-MM-dd HH:mm', $global:BInv, [Globalization.DateTimeStyles]::None, [ref]$date) -or
                    -not [int]::TryParse($c[$columns['skor_ev']], [ref]$hs) -or
                    -not [int]::TryParse($c[$columns['skor_dep']], [ref]$as) -or $hs -lt 0 -or $as -lt 0) { continue }
                [void]$seen.Add($mid)
                $row = [pscustomobject]@{ Id = $mid; Date = $date; Total = $hs + $as; HomeScore = $hs; AwayScore = $as }
                if ($byTeam.ContainsKey($hKey)) { $byTeam[$hKey].Add([pscustomobject]@{ Id=$mid; Date=$date; Total=($hs+$as); TeamScore=$hs; OppScore=$as }) }
                if ($byTeam.ContainsKey($aKey)) { $byTeam[$aKey].Add([pscustomobject]@{ Id=$mid; Date=$date; Total=($hs+$as); TeamScore=$as; OppScore=$hs }) }
            }
        } finally { $reader.Dispose() }
    }
    return ,$byTeam
}

function global:Get-BFixtureHistory([string]$eventId, [datetime]$cut) {
    if ($eventId -cnotmatch '^[a-zA-Z0-9]{8}$') { return }
    $text = Invoke-BFlash ('https://www.flashscore.com/x/feed/df_hh_1_' + $eventId)
    if (-not $text.StartsWith('SA')) { throw 'Takım geçmişi yanıtı okunamadı.' }
    foreach ($r in (ConvertFrom-BFeed $text)) {
        if (-not $r['KP'] -or -not $r['UQ'] -or -not $r['UO'] -or [string]$r['AC'] -notin @('3','10')) { continue }
        $kick = 0L
        if (-not [long]::TryParse([string]$r['KC'], [ref]$kick) -or $kick -le 0) { continue }
        $date = [DateTimeOffset]::FromUnixTimeSeconds($kick).ToOffset($global:BTz).DateTime
        if ($date -ge $cut) { continue }
        $total = Get-BPastScore $r['KU'] $r['KT']
        if ($null -ne $total) {
            # 114: ev / deplasman sayısı da (takımın attığı-yediği hesabı için; eksikken hesap "TeamScore bulunamadı" diye duruyordu)
            [pscustomobject]@{ Id = [string]$r['KP']; Date = $date; Total = $total; HomeId = [string]$r['UQ']; AwayId = [string]$r['UO']; HomeScore = [int]$r['KU']; AwayScore = [int]$r['KT'] }
        }
    }
}

# 77. düzeltme (Claude): modelin yüzdesi gerçeğe göre düzeltilir. 7.677 maçlık arşiv denemesinde (71.114 çizgi) model %75 dediğinde
# %57, %85 dediğinde %62, %95 dediğinde %71 tuttu; %50 civarı doğru. Ham yüzde bu tabloyla gerçekte tutan orana çevrilir (iki taraf simetrik).
$global:BCalib = @(@(0.0, 0.25), @(0.05, 0.291), @(0.15, 0.377), @(0.25, 0.426), @(0.35, 0.471), @(0.45, 0.483), @(0.55, 0.516), @(0.65, 0.529), @(0.75, 0.572), @(0.85, 0.624), @(0.95, 0.709), @(1.0, 0.75))
function global:Get-BCalibOne([double]$p) {
    $t = $global:BCalib
    for ($i = 1; $i -lt $t.Count; $i++) {
        if ($p -le [double]$t[$i][0]) { $a = $t[$i - 1]; $b = $t[$i]; $w = ($p - [double]$a[0]) / ([double]$b[0] - [double]$a[0]); return [double]$a[1] + $w * ([double]$b[1] - [double]$a[1]) }
    }
    return [double]$t[$t.Count - 1][1]
}
function global:Get-BCalibrated([double]$p) {
    $p = [Math]::Max(0.0, [Math]::Min(1.0, $p))
    return ((Get-BCalibOne $p) + 1.0 - (Get-BCalibOne (1.0 - $p))) / 2.0
}
function global:Get-BUnderProbability([double[]]$errors, [double]$gap) {
    $left = 0; $right = $errors.Length
    while ($left -lt $right) {
        $middle = [int][Math]::Floor(($left + $right) / 2)
        if ($errors[$middle] -le $gap) { $left = $middle + 1 } else { $right = $middle }
    }
    return (Get-BCalibrated (($left + 1.0) / ($errors.Length + 2.0)))
}

function global:Test-BCandidate([double]$odds, [double]$probability, [double]$edge,
    [double]$meanGap, [double]$medianGap) {
    return ($odds -ge 1.30 -and $probability -ge 0.70 -and $edge -ge 0.04 -and
        $meanGap -ge 10.0 -and $medianGap -ge 3.0)
}

# 78. düzeltme (Claude): maç başı yüzde ve OYNA / OYNAMA Nesine oranından gelir; takım verisi geçmiş maçta yüzdeyi iyileştirmedi (DENENENLER).
# 1) Oranın payı çıkarılır: Nesine'de oransal yöntem, aynı maçta Flashscore'un paysız olasılığıyla aynı çıktı (188 maç).
# 2) Paysız olasılık, geçmiş maçta o olasılığın gerçekte tutma oranına çevrilir: logit(tutan) = a + b · logit(paysız).
#    MS 9.118 taraf · Alt/Üst 63.442 çizgi (NBA hariç) · NBA 5.520 çizgi (NBA'de Alt beklenenden çok, Üst az tuttu). 29 Eylül – 12 Kasım 2026.
#    İlk yarıdan öğrenilip son yarıda denendi: program %60 dedi, %61 tuttu (805 OYNA).
# 3) OYNA = yüzde sınırın üstü + Nesine oranı 1,30 ve üstü. Maç başı tek bahis (en yüksek yüzde).
# 81. düzeltme: sınır %57 → %60 (5.482 geçmiş maçta %57'de %63,6, %60'ta %65,9 tuttu; günde ~18 aday 20'lik kuponu yine doldurur).
$global:BOranKatsayi = @{ 'MS' = @(0.0, 0.948); 'Alt' = @(-0.028, 0.793); 'Üst' = @(0.028, 0.793); 'NBA Alt' = @(0.171, 1.022); 'NBA Üst' = @(-0.171, 1.022) }
$global:BOynaSiniri = 0.60
$global:BEnDusukOran = 1.30
$global:BNesinePayi = 1.217   # Flashscore oranlı eski kayıtlarda 1,30 kuralı için site karşılığı (Site ortalama payı)
$global:BKararSurum = '109'     # Basket_Arsiv_Karar.csv bu sürümle hesaplandıysa kullanılır (arşiv kararları önceden hesaplı, ekran beklemesin)
# 131. düzeltme: BASKET HÜCRE DENETİMİ (futboldaki gibi). Maç toplamı Alt / Üst yüzdesine, görmediği günlerde katkı yapan karneler eklenir
# (takım karnesi, iç / dış, form, dinlenme); OYNA'yı bozan girmez. Sonuç basket_hucre.txt; ek varsa arşiv kararları "131.<imza>" sürümüyle yeniden hesaplanır.
# 132: taban değişmez (site oranı; puan gücü varsa karışımı): ekler onun üstüne. Denetim de aynı tabanla ölçer (site kayıtlarında puan gücü dahil).
$global:BHucreCode = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
namespace BasketHucre {
    // 131. düzeltme: BASKET HÜCRE DENETİMİ (futboldaki gibi). Hücre: maç toplamı Alt/Üst. Eklerin her biri görmediği günlerde (tek / çift gün) denenir:
    // toplam katkısı artıysa girer; OYNA'yı bozan (karar puanı eksi) girmez. Ekler: takım karnesi (iki takımın son 10 maçının toplam sayısı),
    // iç / dış (ev sahibinin evindeki, deplasmanın deplasmandaki son 7 maçı), form (son 5 maçta bu çizginin üstüne çıkma), dinlenme (son maçtan beri gün).
    // Hepsi maçtan önceki maçlardan (basket_mac_sonuclari.csv, basket_flash_maclar.csv). Taban: programın şimdiki Alt / Üst yüzdesi (Set-BKarar ile aynı hesap).
    public sealed class Ek { public string Add; public double[] W, Mu; }
    public sealed class Sonuc {
        public List<Ek> Ekler = new List<Ek>(); public List<string> Rapor = new List<string>(); public List<string> Satirlar = new List<string>();
        public int Satir, OynaOnce, TuttuOnce, OynaSon, TuttuSon; public string Tarih = "", Hata = "";
    }
    public sealed class F { public double Takim = double.NaN, Icdis = double.NaN, Rh = double.NaN, Ra = double.NaN; public int[] L5h, L5a; public bool Ok;
        // 137: periyot karnesi (1-4. çeyrek toplamı), yarılar, uzatma / yakın maç, rakibe göre puan gücü
        public double[] Pq; public double H1 = double.NaN, H2 = double.NaN, Ot = double.NaN, Mg = double.NaN, Guc = double.NaN; public int Nq; }
    public static class Hucre {
        public static readonly string[] Adds = new string[] { "takim", "icdis", "form", "dinlenme", "periyot", "yari", "uzatma", "guc" };
        public static int Dim(string a) { switch (a) { case "dinlenme": return 2; case "periyot": return 4; case "yari": return 2; case "uzatma": return 2; } return 1; }
        public static string Ad(string a) {
            switch (a) { case "takim": return "takım karnesi (son 10 maç)"; case "icdis": return "iç / dış (evinde / deplasmanda son 7)"; case "form": return "form (son 5 maçta çizgi üstü)"; case "dinlenme": return "dinlenme (son maçtan beri gün)";
                case "periyot": return "periyot karnesi (1-4. çeyrek sayıları)"; case "yari": return "yarı karnesi (1. ve 2. yarı sayıları)"; case "uzatma": return "uzatma / yakın maç (son maçlarda uzatma payı, sayı farkı)"; case "guc": return "puan gücü (rakibe göre hücum / savunma; Elo / Dixon-Coles benzeri)"; }
            return a;
        }
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        static readonly object Kilit = new object();
        sealed class M { public string Z, H, A, N1, N2, Lg; public int Fh, Fa, Rh = -1, Ra = -1; public int[] Q; public TM Th, Ta; }
        sealed class TM { public string Z, Id; public bool Home; public double Att, Def, L, Ha; public int N; }
        static Dictionary<string, M> R; static Dictionary<string, List<TM>> T; static string Yol = ""; static long Boy = -1;
        public static int CeyrekSayisi, SiteCeyrek;
        public static Sonuc Aktif;
        public static int MacSayisi { get { lock (Kilit) { return R == null ? 0 : R.Count; } } }
        static string[] Lines(string p) {
            using (FileStream fs = new FileStream(p, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (StreamReader sr = new StreamReader(fs, Encoding.UTF8)) { List<string> l = new List<string>(); string s; while ((s = sr.ReadLine()) != null) l.Add(s); return l.ToArray(); }
        }
        public static int Load(string dir) {
            string p1 = Path.Combine(dir, "basket_mac_sonuclari.csv"), p2 = Path.Combine(dir, "basket_flash_maclar.csv"), p3 = Path.Combine(dir, "basket_takim_maclari.csv");
            long len = (File.Exists(p1) ? new FileInfo(p1).Length : 0) + (File.Exists(p2) ? new FileInfo(p2).Length : 0) + (File.Exists(p3) ? new FileInfo(p3).Length : 0) * 7919;
            lock (Kilit) { if (R != null && Yol == dir && Boy == len) return R.Count; }
            Dictionary<string, M> r = new Dictionary<string, M>();
            // basket_mac_sonuclari: mac_id;zaman;ev_id;dep_id;ev;dep;skor_ev;skor_dep;normal_ev;normal_dep;lig;ulke;kayit (normal_*: uzatmaya giden maçta normal süre skoru)
            if (File.Exists(p1)) foreach (string ln in Lines(p1)) { string[] c = ln.Split(';'); if (c.Length < 8 || c[0] == "mac_id" || c[0].TrimStart('\uFEFF') == "mac_id" || c[1].Length < 16) continue; M m = Add(r, c[0], c[1], c[2], c[3], c[6], c[7]); if (m == null) continue; m.N1 = c[4]; m.N2 = c[5]; if (c.Length > 11) m.Lg = c[10] + "|" + c[11]; int x, y; if (c.Length > 9 && int.TryParse(c[8], out x) && int.TryParse(c[9], out y)) { m.Rh = x; m.Ra = y; } }
            // basket_flash_maclar: id;zaman;lig;ulke;ev_id;dep_id;ev;dep;skor_ev;skor_dep;ceyrekler(BA..BH);kayit
            if (File.Exists(p2)) foreach (string ln in Lines(p2)) {
                string[] c = ln.Split(';'); if (c.Length < 10 || c[0] == "id" || c[0].TrimStart('\uFEFF') == "id" || c[1].Length < 16) continue;
                M m; if (!r.TryGetValue(c[0].TrimStart('\uFEFF'), out m)) { m = Add(r, c[0], c[1], c[4], c[5], c[8], c[9]); if (m == null) continue; m.N1 = c[6]; m.N2 = c[7]; m.Lg = c[2] + "|" + c[3]; }
                if (c.Length > 10 && m.Q == null) { int[] q = Ceyrek(c[10]); if (q != null) { m.Q = q; int qh = q[0] + q[2] + q[4] + q[6], qa = q[1] + q[3] + q[5] + q[7]; if (m.Rh < 0 && (qh != m.Fh || qa != m.Fa) && qh <= m.Fh && qa <= m.Fa) { m.Rh = qh; m.Ra = qa; } } }
            }
            Dictionary<string, List<TM>> t = new Dictionary<string, List<TM>>();
            foreach (KeyValuePair<string, M> kv in r) { kv.Value.Th = Put(t, kv.Value.H, kv.Value.Z, kv.Key, true); kv.Value.Ta = Put(t, kv.Value.A, kv.Value.Z, kv.Key, false); }
            foreach (List<TM> L in t.Values) L.Sort(delegate (TM x, TM y) { return string.CompareOrdinal(x.Z, y.Z); });
            try { GucHesapla(r); } catch { }
            int nq = 0; foreach (M m in r.Values) if (m.Q != null) nq++;
            lock (Kilit) { R = r; T = t; Yol = dir; Boy = len; CeyrekSayisi = nq; SiteCeyrek = 0; QYol = p3; QHazir = false; }
            return r.Count;
        }
        // sitenin çeyrek skorları yalnız gerektiğinde bağlanır (denetimde ya da periyot / yarı karnesi karardaysa): her açılışta 2-3 sn eklemesin
        static readonly object QKilit = new object(); static bool QHazir; static string QYol = "";
        public static void CeyrekHazirla() {
            lock (QKilit) {
                Dictionary<string, M> r; string p3; lock (Kilit) { if (R == null || QHazir) return; r = R; p3 = QYol; }
                int site = 0; try { if (File.Exists(p3)) site = SiteCeyrekleri(r, p3); } catch { }
                int nq = 0; foreach (M m in r.Values) if (m.Q != null) nq++;
                lock (Kilit) { if (R == r) { QHazir = true; CeyrekSayisi = nq; SiteCeyrek = site; } }
            }
        }
        static bool QGerek() { Sonuc s = Aktif; if (s == null) return false; foreach (Ek e in s.Ekler) if (e.Add == "periyot" || e.Add == "yari") return true; return false; }
        static M Add(Dictionary<string, M> r, string id, string z, string h, string a, string fh, string fa) {
            int x, y; if (!int.TryParse(fh, out x) || !int.TryParse(fa, out y) || string.IsNullOrEmpty(h) || string.IsNullOrEmpty(a)) return null;
            M m = new M(); m.Z = z.Substring(0, 16); m.H = h; m.A = a; m.Fh = x; m.Fa = y; r[id.TrimStart('\uFEFF')] = m; return m;
        }
        static TM Put(Dictionary<string, List<TM>> t, string team, string z, string id, bool home) {
            List<TM> L; if (!t.TryGetValue(team, out L)) { L = new List<TM>(); t[team] = L; }
            TM m = new TM(); m.Z = z; m.Id = id; m.Home = home; L.Add(m); return m;
        }
        // Flashscore çeyrekleri: BA=ev 1. çeyrek, BB=dep 1. çeyrek, BC/BD 2., BE/BF 3., BG/BH 4.
        static int[] Ceyrek(string s) {
            if (string.IsNullOrEmpty(s)) return null; int[] q = new int[8]; int got = 0; string[] k = new string[] { "BA", "BB", "BC", "BD", "BE", "BF", "BG", "BH" };
            foreach (string part in s.Split(',')) { int e = part.IndexOf('='); if (e < 0) continue; int i = Array.IndexOf(k, part.Substring(0, e)); int v; if (i >= 0 && int.TryParse(part.Substring(e + 1), out v) && v >= 0) { q[i] = v; got |= 1 << i; } }
            return got == 255 ? q : null;
        }
        // 137: sitenin takım maç listelerindeki çeyrek skorları (basket_takim_maclari.csv; 201-204 = 1-4. çeyrek) Flashscore maçına bağlanır:
        // saat ±90 dk, normal süre skoru aynı (çeyreklerin toplamı = Flashscore'un normal süre skoru), en az bir takımın adı tutmalı, tek aday.
        static int SiteCeyrekleri(Dictionary<string, M> r, string p3) {
            Dictionary<long, List<M>> ix = new Dictionary<long, List<M>>(); Dictionary<M, DateTime> zt = new Dictionary<M, DateTime>();
            foreach (M m in r.Values) { DateTime d; if (!DateTime.TryParseExact(m.Z, "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out d)) continue; zt[m] = d; long k = d.Ticks / TimeSpan.TicksPerHour; List<M> b; if (!ix.TryGetValue(k, out b)) { b = new List<M>(); ix[k] = b; } b.Add(m); }
            HashSet<string> seen = new HashSet<string>(); int n = 0;
            string[] L = Lines(p3);
            for (int i = 1; i < L.Length; i++) {
                string[] c = L[i].Split(';'); if (c.Length < 10 || c[2].Length < 16 || !seen.Add(c[0])) continue;
                int[] q = new int[8]; int got = 0;
                foreach (string part in c[9].Split('|')) {
                    int sl = part.IndexOf('/'), eq = part.IndexOf('='); if (sl < 0 || eq < 0) continue;
                    int ty; if (!int.TryParse(part.Substring(0, sl), out ty) || ty < 201 || ty > 204) continue;
                    string[] hv = part.Substring(eq + 1).Split('-'); int a, b2; if (hv.Length != 2 || !int.TryParse(hv[0], out a) || !int.TryParse(hv[1], out b2)) continue;
                    q[(ty - 201) * 2] = a; q[(ty - 201) * 2 + 1] = b2; got |= 3 << ((ty - 201) * 2);
                }
                if (got != 255) continue;
                int sh = q[0] + q[2] + q[4] + q[6], sa = q[1] + q[3] + q[5] + q[7];
                DateTime t0; if (!DateTime.TryParseExact(c[2].Substring(0, 16), "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out t0)) continue;
                long k0 = t0.Ticks / TimeSpan.TicksPerHour; M hit = null; int cnt = 0;
                string hn = AdCevir(c[5]), an = AdCevir(c[6]);
                for (long k = k0 - 2; k <= k0 + 2; k++) {
                    List<M> b; if (!ix.TryGetValue(k, out b)) continue;
                    foreach (M m in b) {
                        if (Math.Abs((zt[m] - t0).TotalMinutes) > 90) continue;
                        int rh = m.Rh >= 0 ? m.Rh : m.Fh, ra = m.Ra >= 0 ? m.Ra : m.Fa;
                        if (rh != sh || ra != sa) continue;
                        string fh = AdCevir(m.N1 ?? ""), fa = AdCevir(m.N2 ?? "");
                        bool okH = (hn.Length >= 3 && Esit(hn, fh)) || (Math.Min(hn.Length, fh.Length) >= 6 && (hn.Contains(fh) || fh.Contains(hn))) || TokenEs(c[5], m.N1 ?? "", false);
                        bool okA = (an.Length >= 3 && Esit(an, fa)) || (Math.Min(an.Length, fa.Length) >= 6 && (an.Contains(fa) || fa.Contains(an))) || TokenEs(c[6], m.N2 ?? "", false);
                        if (!okH && !okA) continue;
                        if (hit != m) { hit = m; cnt++; }
                    }
                }
                if (cnt == 1 && hit.Q == null) { hit.Q = q; n++; }
            }
            return n;
        }
        // 137: rakibe göre puan gücü (penaltyblog'daki Elo / Dixon-Coles takım gücünün baskete uyarlaması): her maçtan sonra
        // hücum ve savunma, beklenen sayıyla gerçeğin farkının 0,08'i kadar düzeltilir; ligin maç başı sayısı ve ev avantajı da yavaşça izlenir.
        static void GucHesapla(Dictionary<string, M> r) {
            List<M> all = new List<M>(r.Values); all.Sort(delegate (M x, M y) { return string.CompareOrdinal(x.Z, y.Z); });
            Dictionary<string, double[]> st = new Dictionary<string, double[]>(); Dictionary<string, double[]> lg = new Dictionary<string, double[]>();
            foreach (M m in all) {
                string lk = m.Lg ?? ""; double[] L; if (!lg.TryGetValue(lk, out L)) { L = new double[] { (m.Fh + m.Fa) / 2.0, 0.0 }; lg[lk] = L; }
                double[] h, a; if (!st.TryGetValue(m.H, out h)) { h = new double[3]; st[m.H] = h; } if (!st.TryGetValue(m.A, out a)) { a = new double[3]; st[m.A] = a; }
                double eh = L[0] + h[0] + a[1] + L[1] / 2.0, ea = L[0] + a[0] + h[1] - L[1] / 2.0;
                double rh = m.Rh >= 0 ? m.Rh : m.Fh, ra = m.Ra >= 0 ? m.Ra : m.Fa;
                double e1 = Math.Max(-30, Math.Min(30, rh - eh)), e2 = Math.Max(-30, Math.Min(30, ra - ea));
                h[0] += 0.08 * e1; a[1] += 0.08 * e1; a[0] += 0.08 * e2; h[1] += 0.08 * e2; h[2]++; a[2]++;
                L[0] += 0.01 * ((rh + ra) / 2.0 - L[0]); L[1] += 0.01 * ((rh - ra) - L[1]);
                if (m.Th != null) { m.Th.Att = h[0]; m.Th.Def = h[1]; m.Th.N = (int)h[2]; m.Th.L = L[0]; m.Th.Ha = L[1]; }
                if (m.Ta != null) { m.Ta.Att = a[0]; m.Ta.Def = a[1]; m.Ta.N = (int)a[2]; m.Ta.L = L[0]; m.Ta.Ha = L[1]; }
            }
        }
        static TM Son(Dictionary<string, List<TM>> t, string team, string z) {
            List<TM> L; if (string.IsNullOrEmpty(team) || !t.TryGetValue(team, out L)) return null;
            int lo = 0, hi = L.Count; while (lo < hi) { int md = (lo + hi) / 2; if (string.CompareOrdinal(L[md].Z, z) < 0) lo = md + 1; else hi = md; }
            return lo > 0 ? L[lo - 1] : null;
        }
        // takımın bu saatten önceki, çeyrek skoru bilinen son n maçı
        static List<M> PrevQ(Dictionary<string, M> r, Dictionary<string, List<TM>> t, string team, string z, int n) {
            List<M> o = new List<M>(); List<TM> L; if (string.IsNullOrEmpty(team) || !t.TryGetValue(team, out L)) return o;
            int lo = 0, hi = L.Count; while (lo < hi) { int md = (lo + hi) / 2; if (string.CompareOrdinal(L[md].Z, z) < 0) lo = md + 1; else hi = md; }
            for (int j = lo - 1, sc = 0; j >= 0 && o.Count < n && sc < 120; j--, sc++) { M m = r[L[j].Id]; if (m.Q != null) o.Add(m); }
            return o;
        }
        // takımın bu saatten önceki son n maçı (side: 0 hepsi, 1 evinde, 2 deplasmanda)
        static List<M> Prev(Dictionary<string, M> r, Dictionary<string, List<TM>> t, string team, string z, int n, int side) {
            List<M> o = new List<M>(); List<TM> L; if (string.IsNullOrEmpty(team) || !t.TryGetValue(team, out L)) return o;
            int lo = 0, hi = L.Count; while (lo < hi) { int md = (lo + hi) / 2; if (string.CompareOrdinal(L[md].Z, z) < 0) lo = md + 1; else hi = md; }
            for (int j = lo - 1; j >= 0 && o.Count < n; j--) { if (side == 1 && !L[j].Home) continue; if (side == 2 && L[j].Home) continue; o.Add(r[L[j].Id]); }
            return o;
        }
        // maçın karneleri: kod Flashscore kimliğiyse takımlar sonuçlardan; site maçında takım kimlikleri kayıttan
        public static F Feat(string code, string homeId, string awayId, string time) {
            Dictionary<string, M> r; Dictionary<string, List<TM>> t; lock (Kilit) { r = R; t = T; }
            F f = new F(); if (r == null || string.IsNullOrEmpty(time) || time.Length < 16) return f;
            string h = homeId, a = awayId; M self;
            if ((string.IsNullOrEmpty(h) || string.IsNullOrEmpty(a)) && !string.IsNullOrEmpty(code) && r.TryGetValue(code, out self)) { h = self.H; a = self.A; }
            if (string.IsNullOrEmpty(h) || string.IsNullOrEmpty(a)) return f;
            string z = time.Substring(0, 16);
            List<M> ph = Prev(r, t, h, z, 10, 0), pa = Prev(r, t, a, z, 10, 0), hh = Prev(r, t, h, z, 7, 1), aa = Prev(r, t, a, z, 7, 2);
            if (ph.Count >= 5 && pa.Count >= 5) {
                f.Takim = (Avg(ph) + Avg(pa)) / 2.0;
                f.L5h = new int[5]; f.L5a = new int[5]; for (int i = 0; i < 5; i++) { f.L5h[i] = ph[i].Fh + ph[i].Fa; f.L5a[i] = pa[i].Fh + pa[i].Fa; }
                DateTime k, x1, x2;
                if (DateTime.TryParseExact(z, "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out k) && DateTime.TryParseExact(ph[0].Z, "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out x1) && DateTime.TryParseExact(pa[0].Z, "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out x2)) { f.Rh = (k - x1).TotalDays; f.Ra = (k - x2).TotalDays; }
            }
            if (hh.Count >= 3 && aa.Count >= 3) f.Icdis = (Avg(hh) + Avg(aa)) / 2.0;
            // 137: periyot / yarı karnesi (iki takımın çeyrek skoru bilinen son 10 maçı, her biri en az 3)
            if (QGerek()) CeyrekHazirla();
            List<M> qh = PrevQ(r, t, h, z, 10), qa = PrevQ(r, t, a, z, 10);
            if (qh.Count >= 3 && qa.Count >= 3) {
                f.Pq = new double[4]; f.Nq = Math.Min(qh.Count, qa.Count);
                for (int i = 0; i < 4; i++) { double s1 = 0, s2 = 0; foreach (M m in qh) s1 += m.Q[2 * i] + m.Q[2 * i + 1]; foreach (M m in qa) s2 += m.Q[2 * i] + m.Q[2 * i + 1]; f.Pq[i] = (s1 / qh.Count + s2 / qa.Count) / 2.0; }
                f.H1 = f.Pq[0] + f.Pq[1]; f.H2 = f.Pq[2] + f.Pq[3];
            }
            // 137: uzatma payı (son 20 maç) ve normal sürede ortalama sayı farkı (son 10 maç)
            List<M> oh = Prev(r, t, h, z, 20, 0), oa = Prev(r, t, a, z, 20, 0);
            if (oh.Count >= 8 && oa.Count >= 8) {
                int ot = 0; foreach (M m in oh) if (m.Rh >= 0) ot++; foreach (M m in oa) if (m.Rh >= 0) ot++;
                f.Ot = ot / (double)(oh.Count + oa.Count);
                double mg = 0; int mn = 0; for (int i = 0; i < 10 && i < oh.Count; i++) { mg += Math.Abs((oh[i].Rh >= 0 ? oh[i].Rh - oh[i].Ra : oh[i].Fh - oh[i].Fa)); mn++; } for (int i = 0; i < 10 && i < oa.Count; i++) { mg += Math.Abs((oa[i].Rh >= 0 ? oa[i].Rh - oa[i].Ra : oa[i].Fh - oa[i].Fa)); mn++; }
                f.Mg = mg / mn;
            }
            // 137: puan gücü (her iki takımın maçtan önceki son durumu, en az 5 maç)
            TM sh = Son(t, h, z), sa = Son(t, a, z);
            if (sh != null && sa != null && sh.N >= 5 && sa.N >= 5) f.Guc = 2.0 * sh.L + sh.Att + sa.Def + sa.Att + sh.Def;
            f.Ok = !double.IsNaN(f.Takim) || !double.IsNaN(f.Icdis) || f.Pq != null || !double.IsNaN(f.Ot) || !double.IsNaN(f.Guc);
            return f;
        }
        static double Avg(List<M> l) { double s = 0; foreach (M m in l) s += m.Fh + m.Fa; return s / l.Count; }
        public static double[] X(F f, string add, double line) {
            if (f == null) return null;
            switch (add) {
                case "takim": return double.IsNaN(f.Takim) ? null : new double[] { Clip((f.Takim - line) / 10.0) };
                case "icdis": return double.IsNaN(f.Icdis) ? null : new double[] { Clip((f.Icdis - line) / 10.0) };
                case "form": { if (f.L5h == null) return null; int c = 0; for (int i = 0; i < 5; i++) { if (f.L5h[i] > line) c++; if (f.L5a[i] > line) c++; } return new double[] { c / 10.0 - 0.5 }; }
                case "dinlenme": return (double.IsNaN(f.Rh) || double.IsNaN(f.Ra)) ? null : new double[] { (Math.Min(f.Rh, 4.0) - 2.0) / 2.0, (Math.Min(f.Ra, 4.0) - 2.0) / 2.0 };
                case "periyot": return f.Pq == null ? null : new double[] { Clip((f.Pq[0] * 4 - line) / 10.0), Clip((f.Pq[1] * 4 - line) / 10.0), Clip((f.Pq[2] * 4 - line) / 10.0), Clip((f.Pq[3] * 4 - line) / 10.0) };
                case "yari": return double.IsNaN(f.H1) ? null : new double[] { Clip((f.H1 * 2 - line) / 10.0), Clip((f.H2 * 2 - line) / 10.0) };
                case "uzatma": return double.IsNaN(f.Ot) ? null : new double[] { Clip((f.Ot - 0.05) * 10.0), Clip((f.Mg - 12.0) / 10.0) };
                case "guc": return double.IsNaN(f.Guc) ? null : new double[] { Clip((f.Guc - line) / 10.0) };
            }
            return null;
        }
        static double Clip(double v) { return Math.Max(-5.0, Math.Min(5.0, v)); }
        // Üst yönüne logit eklemesi (Alt için eksi)
        public static double Delta(F f, double line) { Sonuc s = Aktif; return Delta(s, f, line); }
        public static double Delta(Sonuc s, F f, double line) {
            if (s == null || f == null || !f.Ok) return 0.0;
            double d = 0.0;
            foreach (Ek e in s.Ekler) { double[] x = X(f, e.Add, line); if (x == null || e.W == null || x.Length != e.W.Length) continue; for (int j = 0; j < x.Length; j++) d += e.W[j] * (x[j] - e.Mu[j]); }
            return d;
        }
        public static string Imza() { return Imza(Aktif); }
        public static string Imza(Sonuc s) {
            if (s == null || s.Ekler.Count == 0) return "";
            StringBuilder sb = new StringBuilder();
            foreach (Ek e in s.Ekler) { sb.Append(e.Add).Append(':'); for (int j = 0; j < e.W.Length; j++) sb.Append(e.W[j].ToString("0.0000", Inv)).Append(',').Append(e.Mu[j].ToString("0.000", Inv)).Append(';'); }
            uint h = 2166136261; foreach (char ch in sb.ToString()) { h ^= ch; h *= 16777619; }
            return h.ToString("x8");
        }
        // ---------------- 136: takım kimliği eşleştirme ----------------
        // Resolve-BHucreIds'in (132) aynısı, C#'ta: kimliği olmayan site kaydı Flashscore maçıyla (basket_flash_maclar.csv + basket_flash_fikstur.csv)
        // saat (±60 dk) ve iki takımın adıyla eşleşir, tek aday kalmalı. PowerShell'de her kayıt için 3 günün bütün maçları taranıyordu; kayıtlar ekranı
        // eski bilgisayarda dakikalarca boş kalıyordu. Burada maçlar saat dilimine göre dizinli, adlar maç başına bir kez çevrilir. Sonuç aynı.
        sealed class Fx { public string Id, Gun, H, A, Hr, Ar, Hn, An; public DateTime T; public int Seq; }
        sealed class Tk { public bool W; public List<string> T = new List<string>(); public List<bool> Ab = new List<bool>(); }
        static Dictionary<long, List<Fx>> FxI; static string FxYol = ""; static long FxBoy = -1;
        static readonly Regex RxKs = new Regex(@"\s*\(K\)\s*$", RegexOptions.IgnoreCase);   // Convert-BTeamName: -replace (büyük / küçük harf fark etmez)
        static readonly Regex RxNa = new Regex("[^a-z0-9]", RegexOptions.IgnoreCase);
        static readonly Regex RxKc = new Regex(@"\(K\)\s*$");                                // -cmatch / -creplace (fark eder)
        static readonly Regex RxKcr = new Regex(@"\s*\(K\)\s*$");
        static readonly Regex RxWc = new Regex(@"\sW$");
        static readonly Regex RxSp = new Regex(@"[\s\-/]+", RegexOptions.IgnoreCase);
        static readonly HashSet<string> Stop = new HashSet<string>("basket basketbol basketball baloncesto pallacanestro bc bk kk cb cd club sk spor sport sports bbk ss as asd us sc ac fc the de del la le di real team city united st saint univ university state college ks".Split(' '), StringComparer.CurrentCultureIgnoreCase);   // PowerShell 5.1 @{} gibi
        static bool Esit(string a, string b) { return string.Compare(a, b, Inv, CompareOptions.IgnoreCase) == 0; }   // PowerShell -eq gibi (büyük / küçük harf fark etmez)
        public static string AdCevir(string name) {
            string s = RxKs.Replace(name ?? "", " W").ToLowerInvariant().Replace('ı', 'i').Normalize(NormalizationForm.FormKD);
            return RxNa.Replace(s, "");
        }
        static Tk Tokens(string raw) {
            string s = (raw ?? "").Trim();
            Tk k = new Tk(); k.W = RxKc.IsMatch(s) || RxWc.IsMatch(s);
            s = RxWc.Replace(RxKcr.Replace(s, ""), "");
            s = s.ToLowerInvariant().Replace('ı', 'i');
            foreach (string t0 in RxSp.Split(s)) {
                bool ab = t0.EndsWith(".", StringComparison.Ordinal);
                string t = RxNa.Replace(t0.Normalize(NormalizationForm.FormKD), "");
                if (t.Length < 3 || Stop.Contains(t)) continue;
                k.T.Add(t); k.Ab.Add(ab);
            }
            return k;
        }
        public static bool TokenEs(string nraw, string fraw, bool kadin) {
            Tk n = Tokens(nraw), f = Tokens(fraw);
            if ((n.W || kadin) != f.W || n.T.Count == 0 || f.T.Count == 0) return false;
            for (int i = 0; i < n.T.Count; i++) {
                string a = n.T[i]; bool ab = n.Ab[i];
                foreach (string b in f.T) {
                    if (string.Equals(a, b, StringComparison.Ordinal)) return true;
                    if (ab && a.Length >= 3 && b.StartsWith(a, StringComparison.Ordinal)) return true;
                    if (Math.Min(a.Length, b.Length) >= 5 && (a.StartsWith(b, StringComparison.Ordinal) || b.StartsWith(a, StringComparison.Ordinal))) return true;
                }
            }
            return false;
        }
        static Dictionary<long, List<Fx>> FixIdx(string dir) {
            string p1 = Path.Combine(dir, "basket_flash_maclar.csv"), p2 = Path.Combine(dir, "basket_flash_fikstur.csv");
            long len = (File.Exists(p1) ? new FileInfo(p1).Length : 0) + (File.Exists(p2) ? new FileInfo(p2).Length : 0);
            lock (Kilit) { if (FxI != null && FxYol == dir && FxBoy == len) return FxI; }
            Dictionary<long, List<Fx>> ix = new Dictionary<long, List<Fx>>(); int seq = 0;
            foreach (string p in new string[] { p1, p2 }) {
                if (!File.Exists(p)) continue;
                bool fix = (p == p2); string[] L = Lines(p);
                for (int i = 1; i < L.Length; i++) {
                    // maclar: id;zaman;lig;ulke;ev_id;dep_id;ev;dep;...   fikstur: id;zaman;ev_id;dep_id;ev;dep;lig;kayit
                    string[] c = L[i].Split(';'); string[] o;
                    if (fix) { if (c.Length < 6) continue; o = new string[] { c[0], c[1], c[2], c[3], c[4], c[5] }; }
                    else { if (c.Length < 8) continue; o = new string[] { c[0], c[1], c[4], c[5], c[6], c[7] }; }
                    if (o[1].Length < 13 || o[2].Length == 0 || o[3].Length == 0) continue;
                    DateTime z; if (!DateTime.TryParseExact(o[1].Substring(0, Math.Min(16, o[1].Length)), "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out z)) continue;
                    Fx x = new Fx(); x.Id = o[0]; x.Gun = o[1].Substring(0, 10); x.T = z; x.H = o[2]; x.A = o[3]; x.Hr = o[4]; x.Ar = o[5]; x.Seq = seq++;
                    long k = z.Ticks / TimeSpan.TicksPerHour; List<Fx> b; if (!ix.TryGetValue(k, out b)) { b = new List<Fx>(); ix[k] = b; } b.Add(x);
                }
            }
            lock (Kilit) { FxI = ix; FxYol = dir; FxBoy = len; }
            return ix;
        }
        // {flash_id, ev_id, dep_id} ya da null (tek aday yoksa)
        public static string[] Coz(string dir, string time, string home, string away) {
            try {
                DateTime t; if (string.IsNullOrEmpty(dir) || !DateTime.TryParseExact(time ?? "", "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out t)) return null;
                Dictionary<long, List<Fx>> ix = FixIdx(dir);
                home = home ?? ""; away = away ?? "";
                string hn = AdCevir(home), an = AdCevir(away); bool kadin = RxKc.IsMatch(home);
                List<Fx> c = new List<Fx>(); long k0 = t.Ticks / TimeSpan.TicksPerHour;
                for (long k = k0 - 1; k <= k0 + 1; k++) { List<Fx> b; if (ix.TryGetValue(k, out b)) foreach (Fx x in b) if (Math.Abs((x.T - t).TotalMinutes) <= 60) c.Add(x); }
                c.Sort(delegate (Fx x, Fx y) { int r = string.CompareOrdinal(x.Gun, y.Gun); return r != 0 ? r : x.Seq.CompareTo(y.Seq); });   // eski sıra: gün gün, dosya sırası
                List<Fx> found = new List<Fx>();
                foreach (Fx o in c) {
                    string fh = o.Hn, fa = o.An;
                    if (fh == null || fa == null) { fh = AdCevir(o.Hr); fa = AdCevir(o.Ar); o.An = fa; o.Hn = fh; }
                    bool okH = (hn.Length >= 3 && Esit(hn, fh)) || (Math.Min(hn.Length, fh.Length) >= 6 && (hn.Contains(fh) || fh.Contains(hn))) || TokenEs(home, o.Hr, kadin);
                    if (!okH) continue;
                    bool okA = (an.Length >= 3 && Esit(an, fa)) || (Math.Min(an.Length, fa.Length) >= 6 && (an.Contains(fa) || fa.Contains(an))) || TokenEs(away, o.Ar, kadin);
                    if (!okA) continue;
                    bool dup = false; foreach (Fx q in found) if (string.Equals(q.Id, o.Id, StringComparison.Ordinal)) { dup = true; break; }
                    if (!dup) found.Add(o);
                }
                if (found.Count != 1) return null;
                return new string[] { found[0].Id, found[0].H, found[0].A };
            } catch { return null; }
        }
        // ---------------- denetim ----------------
        sealed class Ln { public double Line, Zu, Zo, U, O; public bool OkU, OkO; }
        sealed class Row { public List<Ln> L = new List<Ln>(); public Ln C; public double Act; public int Fold; public F Fe; public bool Site; }
        static double Sig(double x) { x = Math.Max(-30, Math.Min(30, x)); return 1.0 / (1.0 + Math.Exp(-x)); }
        static double Lgt(double p) { return Math.Log(p / (1.0 - p)); }
        static double Num(string s) { double v; return double.TryParse((s ?? "").Replace(',', '.'), NumberStyles.Float, Inv, out v) ? v : double.NaN; }
        // satırlar: kod;zaman;lig;gercek;cizgiler(cizgi:alt:ust|...);prog;sapma  (kayıtlardaki ve arşivdeki biten maçlar)
        public static Sonuc Audit(string rowsPath, string dir, double[] ka, double[] ku, double[] kan, double[] kun, double[] kk, double esik, double enDusuk, double payi) {
            Sonuc res = new Sonuc(); res.Tarih = DateTime.Now.ToString("yyyy-MM-dd HH:mm", Inv);
            try {
                Load(dir); CeyrekHazirla();
                List<Row> rows = new List<Row>(); double maxFair = 1.0 / (enDusuk * payi);
                foreach (string ln in Lines(rowsPath)) {
                    string[] c = ln.Split(';'); if (c.Length < 7 || c[0] == "kod") continue;
                    double act = Num(c[3]); if (double.IsNaN(act)) continue;
                    bool nba = System.Text.RegularExpressions.Regex.IsMatch(c[2].Trim(), "^(USA:\\s*)?NBA$");
                    bool nes = System.Text.RegularExpressions.Regex.IsMatch(c[0], "^\\d+$");
                    double pt = Num(c[5]), ps = Num(c[6]); bool prog = !nba && !double.IsNaN(pt) && !double.IsNaN(ps) && ps > 0;
                    Row r = new Row(); r.Act = act; r.Site = nes;
                    foreach (string part in c[4].Split('|')) {
                        string[] q = part.Split(':'); if (q.Length < 3) continue;
                        double line = Num(q[0]), u = Num(q[1]), o = Num(q[2]); if (double.IsNaN(line) || !(u > 1.0) || !(o > 1.0)) continue;
                        double fu = Math.Min(0.98, Math.Max(0.02, (1.0 / u) / ((1.0 / u) + (1.0 / o)))); double g = Lgt(fu);
                        Ln l = new Ln(); l.Line = line; l.U = u; l.O = o;
                        if (prog) { double pp = Math.Min(0.98, Math.Max(0.02, Phi((pt - line) / ps))); double po = Sig(kk[0] - kk[1] * g + kk[2] * Lgt(pp)); l.Zo = Lgt(po); l.Zu = -l.Zo; }
                        else { double[] a = nba ? kan : ka, b = nba ? kun : ku; l.Zu = a[0] + a[1] * g; l.Zo = b[0] - b[1] * g; }
                        l.OkU = nes ? u >= enDusuk : fu <= maxFair; l.OkO = nes ? o >= enDusuk : (1.0 - fu) <= maxFair;
                        r.L.Add(l);
                    }
                    if (r.L.Count == 0 || c[1].Length < 16) continue;
                    double bd = 9; foreach (Ln l in r.L) { double d = Math.Abs(Sig(l.Zo) - 0.5); if (d < bd) { bd = d; r.C = l; } }
                    r.Fold = int.Parse(c[1].Substring(8, 2), Inv) % 2;
                    r.Fe = Feat(c[0], c.Length > 7 ? c[7] : "", c.Length > 8 ? c[8] : "", c[1]);
                    rows.Add(r);
                }
                res.Satir = rows.Count;
                if (rows.Count < 300) { res.Hata = "az satır (" + rows.Count + ")"; return res; }
                List<string> on = new List<string>();
                Dictionary<string, double[]> W0 = new Dictionary<string, double[]>();
                double[] cur = Eval(rows, on, esik); res.OynaOnce = (int)cur[2]; res.TuttuOnce = (int)cur[3]; double[] ilk = cur;
                List<string> notes = new List<string>(); Dictionary<string, string> son = new Dictionary<string, string>();
                for (int step = 0; step < 10; step++) {
                    string bestA = null; double bestS = double.NegativeInfinity; double[] bestE = null; bool bestRm = false;
                    foreach (string a in Adds) {
                        bool isOn = on.Contains(a); List<string> set = new List<string>(on); if (isOn) set.Remove(a); else set.Add(a);
                        double[] e = Eval(rows, set, esik);
                        double g0 = e[0] - cur[0], g1 = e[1] - cur[1], gt = g0 + g1;
                        double st = (e[3] - cur[3]) - esik * (e[2] - cur[2]);
                        bool llr = gt > 0 && st >= 0, sr = st > 0 && gt >= 0;
                        if (!isOn) son[a] = Ad(a) + " " + N1(gt) + (gt > 0 && st < 0 ? " (OYNA'yı bozuyor: karar puanı " + N1(st) + ")" : "");
                        if ((llr || sr) && gt + (sr ? 1000 + st : 0) > bestS) { bestS = gt + (sr ? 1000 + st : 0); bestA = a; bestE = e; bestRm = isOn;
                            notes.Add(""); notes.RemoveAt(notes.Count - 1);
                            son["_d"] = Ad(a) + (isOn ? " çıkarıldı" : " eklendi") + ": isabet " + N1(gt) + " (yarılar " + N1(g0) + " / " + N1(g1) + "); karar puanı " + N1(st); }
                    }
                    if (bestA == null) break;
                    if (bestRm) on.Remove(bestA); else on.Add(bestA);
                    notes.Add(son["_d"]); son.Remove(bestA); cur = bestE;
                }
                son.Remove("_d");
                res.OynaSon = (int)cur[2]; res.TuttuSon = (int)cur[3];
                // son katsayılar: bütün satırlarla
                foreach (string a in on) { }
                List<Ek> eks = FitAll(rows, on); res.Ekler = eks;
                List<string> top = new List<string>(); foreach (string a in Adds) if (!on.Contains(a) && son.ContainsKey(a)) top.Add(son[a]);
                List<string> ads = new List<string>(); foreach (string a in on) ads.Add(Ad(a));
                res.Satirlar.Add("TOP|Maç toplamı Alt / Üst|" + (ads.Count > 0 ? string.Join(", ", ads.ToArray()) : "—") + "|" + (top.Count > 0 ? string.Join(" · ", top.ToArray()) : "—") + "|" + string.Join(" · ", notes.ToArray()));
                int ns = 0; foreach (Row r in rows) if (r.Site) ns++;
                CultureInfo trc = CultureInfo.GetCultureInfo("tr-TR");
                res.Rapor.Add("ayrı ayrı: site oranlı " + ns.ToString("#,0", trc) + " maç: önce " + ilk[4] + " OYNA %" + Pct((int)ilk[5], (int)ilk[4]) + " → şimdi " + cur[4] + " OYNA %" + Pct((int)cur[5], (int)cur[4]) + "; Flashscore arşivi: önce " + ilk[6] + " OYNA %" + Pct((int)ilk[7], (int)ilk[6]) + " → şimdi " + cur[6] + " OYNA %" + Pct((int)cur[7], (int)cur[6]));
                res.Rapor.Insert(0, "Görmediği günlerde karar: önce " + res.OynaOnce.ToString("#,0", CultureInfo.GetCultureInfo("tr-TR")) + " OYNA %" + Pct(res.TuttuOnce, res.OynaOnce) + " → şimdi " + res.OynaSon.ToString("#,0", CultureInfo.GetCultureInfo("tr-TR")) + " OYNA %" + Pct(res.TuttuSon, res.OynaSon) + " (" + rows.Count.ToString("#,0", CultureInfo.GetCultureInfo("tr-TR")) + " biten maç)");
            } catch (Exception ex) { res.Hata = ex.Message; }
            return res;
        }
        static string N1(double x) { return (x > 0.05 ? "+" : "") + x.ToString("0.0", CultureInfo.GetCultureInfo("tr-TR")); }
        static string Pct(int h, int n) { return n == 0 ? "0" : (100.0 * h / n).ToString("0.0", CultureInfo.GetCultureInfo("tr-TR")); }
        static double Phi(double x) { double z = Math.Abs(x) / Math.Sqrt(2.0), t = 1.0 / (1.0 + 0.3275911 * z); double y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.Exp(-z * z); return x >= 0 ? 0.5 * (1.0 + y) : 0.5 * (1.0 - y); }
        // çapraz: tek günlerle öğren, çift günlerde ölç (ve tersi). Dönen: [log-olabilirlik yarı 0, yarı 1, OYNA, tuttu]
        static double[] Eval(List<Row> rows, List<string> set, double esik) {
            double[] o = new double[8];
            for (int f = 0; f < 2; f++) {
                List<Row> tr = new List<Row>(), te = new List<Row>(); foreach (Row r in rows) { if (r.Fold == f) te.Add(r); else tr.Add(r); }
                List<Ek> w = Fit(tr, set);
                foreach (Row r in te) {
                    Ln c = r.C;
                    if (r.Act != c.Line) { double p = Sig(c.Zo + D(w, r.Fe, c.Line)); bool y = r.Act > c.Line; o[f] += Math.Log(y ? p : 1 - p); }
                    double best = -1; int hit = -1;
                    foreach (Ln l in r.L) {
                        double d = D(w, r.Fe, l.Line), pu = Sig(l.Zu - d), po = Sig(l.Zo + d);
                        if (l.OkU && pu > best) { best = pu; hit = r.Act == l.Line ? -1 : (r.Act < l.Line ? 1 : 0); }
                        if (l.OkO && po > best) { best = po; hit = r.Act == l.Line ? -1 : (r.Act > l.Line ? 1 : 0); }
                    }
                    if (best >= esik && hit >= 0) { o[2]++; o[3] += hit; if (r.Site) { o[4]++; o[5] += hit; } else { o[6]++; o[7] += hit; } }
                }
            }
            return o;
        }
        static double D(List<Ek> w, F f, double line) { double d = 0; foreach (Ek e in w) { double[] x = X(f, e.Add, line); if (x == null) continue; for (int j = 0; j < x.Length; j++) d += e.W[j] * (x[j] - e.Mu[j]); } return d; }
        static List<Ek> FitAll(List<Row> rows, List<string> set) { return Fit(rows, set); }
        // ridge (λ=1) lojistik, taban logit sabit (ofset), yalnız eğim, ortalanmış
        static List<Ek> Fit(List<Row> rows, List<string> set) {
            List<Ek> res = new List<Ek>(); if (set.Count == 0) return res;
            List<int> dims = new List<int>(); int dim = 0; foreach (string a in set) { int k = Dim(a); dims.Add(k); dim += k; }
            List<double[]> X0 = new List<double[]>(); List<double> Z = new List<double>(); List<int> Y = new List<int>();
            foreach (Row r in rows) {
                if (r.Act == r.C.Line) continue;
                double[] v = new double[dim]; int p = 0; bool any = false;
                for (int i = 0; i < set.Count; i++) { double[] x = X(r.Fe, set[i], r.C.Line); for (int j = 0; j < dims[i]; j++) { v[p + j] = x == null ? double.NaN : x[j]; } if (x != null) any = true; p += dims[i]; }
                if (!any) continue;
                X0.Add(v); Z.Add(r.C.Zo); Y.Add(r.Act > r.C.Line ? 1 : 0);
            }
            double[] mu = new double[dim]; int[] cnt = new int[dim];
            foreach (double[] v in X0) for (int j = 0; j < dim; j++) if (!double.IsNaN(v[j])) { mu[j] += v[j]; cnt[j]++; }
            for (int j = 0; j < dim; j++) mu[j] = cnt[j] > 0 ? mu[j] / cnt[j] : 0;
            double[] w = new double[dim];
            for (int it = 0; it < 15; it++) {
                double[] g = new double[dim]; double[,] H = new double[dim, dim];
                for (int i = 0; i < X0.Count; i++) {
                    double[] xc = new double[dim]; for (int j = 0; j < dim; j++) xc[j] = double.IsNaN(X0[i][j]) ? 0 : X0[i][j] - mu[j];
                    double s = Z[i]; for (int j = 0; j < dim; j++) s += w[j] * xc[j];
                    double pr = Sig(s), e = Y[i] - pr, ww = pr * (1 - pr);
                    for (int a = 0; a < dim; a++) { g[a] += e * xc[a]; for (int b = 0; b < dim; b++) H[a, b] += ww * xc[a] * xc[b]; }
                }
                for (int a = 0; a < dim; a++) { g[a] -= w[a]; H[a, a] += 1.0; }
                double[] step = Solve(H, g, dim); for (int a = 0; a < dim; a++) w[a] += step[a];
            }
            int q = 0;
            for (int i = 0; i < set.Count; i++) { Ek e = new Ek(); e.Add = set[i]; e.W = new double[dims[i]]; e.Mu = new double[dims[i]]; for (int j = 0; j < dims[i]; j++) { e.W[j] = w[q + j]; e.Mu[j] = mu[q + j]; } q += dims[i]; res.Add(e); }
            return res;
        }
        static double[] Solve(double[,] A0, double[] b0, int n) {
            double[,] A = (double[,])A0.Clone(); double[] b = (double[])b0.Clone();
            for (int c = 0; c < n; c++) {
                int piv = c; for (int r = c + 1; r < n; r++) if (Math.Abs(A[r, c]) > Math.Abs(A[piv, c])) piv = r;
                if (piv != c) { for (int k = 0; k < n; k++) { double t = A[c, k]; A[c, k] = A[piv, k]; A[piv, k] = t; } double tb = b[c]; b[c] = b[piv]; b[piv] = tb; }
                for (int r = 0; r < n; r++) { if (r == c) continue; double f = A[r, c] / A[c, c]; for (int k = c; k < n; k++) A[r, k] -= f * A[c, k]; b[r] -= f * b[c]; }
            }
            double[] x = new double[n]; for (int i = 0; i < n; i++) x[i] = b[i] / A[i, i]; return x;
        }
        // ---------------- kaydet / oku ----------------
        public static void Save(Sonuc s, string path) {
            StringBuilder sb = new StringBuilder(); sb.Append("#bhucre;1\n").Append("tarih;").Append(s.Tarih).Append('\n');
            sb.Append("karar;").Append(s.OynaOnce).Append(';').Append(s.TuttuOnce).Append(';').Append(s.OynaSon).Append(';').Append(s.TuttuSon).Append(';').Append(s.Satir).Append('\n');
            foreach (Ek e in s.Ekler) { sb.Append("ek;").Append(e.Add); for (int j = 0; j < e.W.Length; j++) sb.Append(';').Append(e.W[j].ToString("R", Inv)).Append(';').Append(e.Mu[j].ToString("R", Inv)); sb.Append('\n'); }
            foreach (string r in s.Rapor) sb.Append("rapor;").Append(r.Replace("\n", " ")).Append('\n');
            foreach (string r in s.Satirlar) sb.Append("satir;").Append(r.Replace("\n", " ")).Append('\n');
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
        }
        public static Sonuc LoadFile(string path) {
            if (!File.Exists(path)) return null;
            Sonuc s = new Sonuc();
            foreach (string ln in File.ReadAllLines(path, Encoding.UTF8)) {
                int i = ln.IndexOf(';'); if (i < 0) continue; string k = ln.Substring(0, i), v = ln.Substring(i + 1);
                if (k == "tarih") s.Tarih = v;
                else if (k == "karar") { string[] c = v.Split(';'); if (c.Length >= 5) { int.TryParse(c[0], out s.OynaOnce); int.TryParse(c[1], out s.TuttuOnce); int.TryParse(c[2], out s.OynaSon); int.TryParse(c[3], out s.TuttuSon); int.TryParse(c[4], out s.Satir); } }
                else if (k == "ek") { string[] c = v.Split(';'); Ek e = new Ek(); e.Add = c[0]; int n = (c.Length - 1) / 2; e.W = new double[n]; e.Mu = new double[n]; for (int j = 0; j < n; j++) { e.W[j] = double.Parse(c[1 + 2 * j], Inv); e.Mu[j] = double.Parse(c[2 + 2 * j], Inv); } s.Ekler.Add(e); }
                else if (k == "rapor") s.Rapor.Add(v);
                else if (k == "satir") s.Satirlar.Add(v);
            }
            return s;
        }
    }
}
'@
function global:Initialize-BHucre([string]$dir, [switch]$Veri) {
    try {
        if (-not ('BasketHucre.Hucre' -as [type])) { Add-Type -TypeDefinition $global:BHucreCode }
        if ($dir) {
            $global:BHucreDataDir = $dir
            if ($null -eq [BasketHucre.Hucre]::Aktif) { $f = Join-Path $dir 'basket_hucre.txt'; if (Test-Path -LiteralPath $f) { [BasketHucre.Hucre]::Aktif = [BasketHucre.Hucre]::LoadFile($f) } }
            if ($Veri) { [void][BasketHucre.Hucre]::Load($dir) }
        }
        $im = [BasketHucre.Hucre]::Imza(); $global:BKararSurum = $(if ($im) { '131.' + $im } else { '109' })
        return $true
    } catch { $global:BHucreHata = $_.Exception.Message; return $false }
}
# 144: ARŞİV BÜYÜR. Basket_Arsiv_Testi (29 Eylül - 12 Kasım, 7.677 maç) paketle gelir ve büyümüyordu; program 12 Kasım'dan sonra da biten
# Flashscore maçlarını (basket_flash_maclar.csv) ve oranlarını (basket_flash_oranlar.csv) topluyor. Burada bunlar arşivle AYNI biçimde
# (açılış oranları, yalnız ,5 çizgiler, maç toplamı uzatma dahil) veri klasöründeki Basket_Arsiv_Ek'e 150'şer maçlık dosyalarla (ek_000.json ...)
# yazılır (paketteki arşiv gibi; PowerShell 5.1 büyük JSON'u okurken zorlanabiliyor). Paketteki arşive dokunulmaz.
# Arşivde zaten olan maç eklenmez. Dosya her seferinde baştan yazılır (aynı veriyle aynı sonuç). Hücre denetimi ve Kayıtlar iki klasörü birlikte okur.
function global:Build-BArsivEk([string]$dataDir, [string]$arsivDir) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $inv = [Globalization.CultureInfo]::InvariantCulture; $style = [Globalization.NumberStyles]::Float
    $res = [pscustomobject]@{ Yeni = 0; Arsiv = 0; Sn = 0.0; Hata = '' }
    try {
        $codes = New-Object 'System.Collections.Generic.HashSet[string]'
        if ($arsivDir -and (Test-Path -LiteralPath $arsivDir)) {
            $rx = New-Object Text.RegularExpressions.Regex('"Code"\s*:\s*"([^"]+)"')
            foreach ($f in (Get-ChildItem -LiteralPath $arsivDir -Filter '*.json' -File)) {
                foreach ($m in $rx.Matches([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8))) { [void]$codes.Add($m.Groups[1].Value) }
            }
        }
        $res.Arsiv = $codes.Count
        $readLines = {
            param([string]$path)
            $fs = New-Object IO.FileStream($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
            try { $sr = New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8); return $sr.ReadToEnd().Split("`n") } finally { $fs.Close() }
        }
        $mp = Join-Path $dataDir 'basket_flash_maclar.csv'; $op = Join-Path $dataDir 'basket_flash_oranlar.csv'
        if (-not (Test-Path -LiteralPath $mp) -or -not (Test-Path -LiteralPath $op)) { $res.Hata = 'Flashscore dosyaları yok'; return $res }
        # oranlar: maç başına son satır (geçmiş maçta 'gecmis' aşaması); yalnız maç toplamı Alt / Üst grubu tutulur
        $odds = @{}
        foreach ($ln in (& $readLines $op)) {
            $i1 = $ln.IndexOf(';'); if ($i1 -le 0) { continue }
            $c = $ln.TrimEnd("`r").Split(';', 4); if ($c.Count -lt 4) { continue }
            $g0 = $c[3].IndexOf('OVER_UNDER@FULL_TIME_OVER_TIME='); if ($g0 -lt 0) { continue }
            $g1 = $c[3].IndexOf('|', $g0); $grp = $(if ($g1 -gt 0) { $c[3].Substring($g0, $g1 - $g0) } else { $c[3].Substring($g0) })
            $id = $c[0].TrimStart([char]0xFEFF)
            if ($c[1] -eq 'gecmis' -or -not $odds.ContainsKey($id)) { $odds[$id] = $grp }
        }
        $esc = { param([string]$t) return ($t.Replace('\', '\\').Replace('"', '\"') -replace '[\x00-\x1F]', ' ') }
        $recs = New-Object Collections.ArrayList
        $hd = $null; $ix = @{}; $n = 0
        foreach ($ln in (& $readLines $mp)) {
            $l2 = $ln.TrimEnd("`r"); if (-not $l2) { continue }
            $c = $l2.Split(';')
            if ($null -eq $hd) { $hd = $c; for ($i = 0; $i -lt $c.Count; $i++) { $ix[$c[$i].TrimStart([char]0xFEFF)] = $i }; continue }
            if ($c.Count -lt $hd.Count) { continue }
            $id = $c[$ix['id']]; if (-not $id -or $codes.Contains($id) -or -not $odds.ContainsKey($id)) { continue }
            $h = 0; $a = 0
            if (-not [int]::TryParse($c[$ix['skor_ev']], [ref]$h) -or -not [int]::TryParse($c[$ix['skor_dep']], [ref]$a) -or ($h + $a) -le 0) { continue }
            $tm = [string]$c[$ix['zaman']]; if ($tm.Length -lt 16) { continue }
            # çizgiler: çizgi:seçim:oran:açılış:büro:sonuç. Arşiv açılış oranıyla kurulmuş (aynı maçlarda adil yüzde farkı ortalama 0,17 puan).
            $lines = @{}
            foreach ($e in $odds[$id].Substring($odds[$id].IndexOf('=') + 1).Split(' ')) {
                $p = $e.Split(':'); if ($p.Count -lt 5 -or -not $p[0].EndsWith('.5') -or -not $p[3]) { continue }
                $v = 0.0; if (-not [double]::TryParse($p[3], $style, $inv, [ref]$v) -or $v -le 1.0) { continue }
                if (-not $lines.ContainsKey($p[0])) { $lines[$p[0]] = @{} }
                $lines[$p[0]][$p[1]] = $v
            }
            $ls = New-Object Collections.ArrayList
            foreach ($k in @($lines.Keys | Sort-Object { [double]::Parse($_, $inv) })) {
                $q = $lines[$k]; if (-not $q.ContainsKey('UNDER') -or -not $q.ContainsKey('OVER')) { continue }
                $lt = $k.Replace('.', ',')
                [void]$ls.Add('{"Line":"' + $lt + '","Under":"","Over":"","UnderOdds":"' + $q['UNDER'].ToString('0.00', $inv).Replace('.', ',') + '","OverOdds":"' + $q['OVER'].ToString('0.00', $inv).Replace('.', ',') + '"}')
            }
            if ($ls.Count -eq 0) { continue }
            $lig = [string]$c[$ix['lig']]; $ulke = [string]$c[$ix['ulke']]
            $lig = $lig -replace '^[^:]*:\s*', ''; if ($ulke -and $lig.EndsWith(' ' + $ulke)) { $lig = $lig.Substring(0, $lig.Length - $ulke.Length - 1) }; $lig = $lig -replace '\s+-\s+.*$', ''
            $sb = New-Object Text.StringBuilder
            [void]$sb.Append('{"Code":"' + (& $esc $id) + '","Time":"' + (& $esc $tm.Substring(0, 16)) + '","Home":"' + (& $esc ([string]$c[$ix['ev']])) + '","Away":"' + (& $esc ([string]$c[$ix['dep']])) + '","League":"' + (& $esc $lig) + '",')
            [void]$sb.Append('"Expected":"","Actual":' + ($h + $a) + ',"Candidate":"","CandidateProbability":null,"Edge":0.0,"Status":"Açılış oranı · arşive sonradan eklendi (144)","Mode":"Geçmiş maç","ReplaySource":"Flashscore","ReplayResult":"","ReplayQuote":"Açılış oranı",')
            [void]$sb.Append('"HomeId":"' + (& $esc ([string]$c[$ix['ev_id']])) + '","AwayId":"' + (& $esc ([string]$c[$ix['dep_id']])) + '","Lines":[' + ($ls -join ',') + ']}')
            [void]$recs.Add($sb.ToString()); $n++
        }
        $od = Join-Path $dataDir 'Basket_Arsiv_Ek'
        if (-not (Test-Path -LiteralPath $od)) { [void](New-Item -ItemType Directory -Path $od) }
        $enc = New-Object Text.UTF8Encoding $false; $yaz = @{}; $k0 = 0
        do {
            $nm = 'ek_' + $k0.ToString('000') + '.json'; $fp = Join-Path $od $nm; $tmp = $fp + '.tmp'
            $cnt = [Math]::Min(150, $recs.Count - 150 * $k0)
            $part = $(if ($cnt -gt 0) { $recs.GetRange(150 * $k0, $cnt) -join ',' } else { '' })
            [IO.File]::WriteAllText($tmp, '[' + $part + ']', $enc)
            if (Test-Path -LiteralPath $fp) { Remove-Item -LiteralPath $fp -Force }
            Move-Item -LiteralPath $tmp -Destination $fp -Force
            $yaz[$nm] = $true; $k0++
        } while (150 * $k0 -lt $recs.Count)
        # önceki seferden kalan fazla dosyalar silinir
        foreach ($f in (Get-ChildItem -LiteralPath $od -Filter '*.json' -File)) { if (-not $yaz.ContainsKey($f.Name)) { Remove-Item -LiteralPath $f.FullName -Force } }
        $res.Yeni = $n
    } catch { $res.Hata = $_.Exception.Message }
    $res.Sn = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
    return $res
}
# 132: takım kimliği olmayan (131'den önce kaydedilmiş) site analizleri: Flashscore maçlarıyla (biten: basket_flash_maclar.csv, oynanacak:
# basket_flash_fikstur.csv) saat (±60 dk) ve iki takımın adıyla eşleştirilir (tek aday kalmalı). Bulunan kimlik kayda da yazılır.
# 136: eşleştirme C#'ta (BasketHucre.Hucre.Coz; aynı kural, saat dilimine göre dizinli). PowerShell'deki tarama kayıt başına 3 günün bütün maçlarına
# bakıyordu; 700+ site kaydı ve arşivdeki site maçlarıyla kayıtlar ekranı eski bilgisayarda dakikalarca boş kalıyordu.
function global:Resolve-BHucreIds($row) {
    try {
        $r = [BasketHucre.Hucre]::Coz([string]$global:BHucreDataDir, [string]$row.Time, [string]$row.Home, [string]$row.Away)
        if ($null -eq $r -or @($r).Count -ne 3) { return $false }
        Set-BProp $row 'FlashId' ([string]$r[0]); Set-BProp $row 'HomeId' ([string]$r[1]); Set-BProp $row 'AwayId' ([string]$r[2])
        return $true
    } catch { return $false }
}
# bir maçın karneleri (denetimde ek yoksa ya da takımlar bulunamazsa $null)
function global:Get-BHucreF($row) {
    try {
        if (-not ('BasketHucre.Hucre' -as [type])) { return $null }
        $s = [BasketHucre.Hucre]::Aktif; if ($null -eq $s -or $s.Ekler.Count -eq 0) { return $null }
        if ([BasketHucre.Hucre]::MacSayisi -eq 0 -and $global:BHucreDataDir) { [void][BasketHucre.Hucre]::Load([string]$global:BHucreDataDir) }
        $pp = $row.PSObject.Properties
        if ([string]$row.Code -match '^\d+$' -and (-not $pp['HomeId'] -or -not [string]$row.HomeId)) { if (Resolve-BHucreIds $row) { $pp = $row.PSObject.Properties } }
        $f = [BasketHucre.Hucre]::Feat([string]$row.Code, $(if ($pp['HomeId']) { [string]$row.HomeId } else { '' }), $(if ($pp['AwayId']) { [string]$row.AwayId } else { '' }), [string]$row.Time)
        if ($null -eq $f -or -not $f.Ok) { return $null }
        return $f
    } catch { return $null }
}

# 108. düzeltme (Claude): PROGRAMIN TOPLAM SAYI TAHMİNİ + PUAN GÜCÜ, Alt / Üst yüzdesine (NBA dışı) katılır.
#   Toplam tahmini = 88,66 + 0,442 · (iç saha / dış saha son 7 maç toplamı) + 12,59 · (rakibe göre ayarlı puan gücü toplamı - 158,48) / 23,28; sapma 17,48.
#   Puan gücü: 2023-07'den beri 85.548 maç sırayla; her maçtan sonra takımın hücumu ve savunması hatanın 0,08'i kadar düzeltilir (basket_guc_tablosu.csv, arka planda).
#   Çizgi yüzdesi: Üst = σ(-0,0466 + 1,1467 · logit(paysız Üst) + 0,2513 · logit(Normal((tahmin - çizgi) / sapma))), Alt = 100 - Üst.
#   Görülmemiş günler (3 kesim; seçim / katsayı yalnız öncesinden): aynı sayıda en güçlü aday bugünkü hesap %65,3 / %65,3 / %66,1 → %68,5 / %69,0 / %74,2;
#   OYNA (%60+) 642 / 461 / 236 → 2.075 / 1.496 / 779, tuttu %65,3 / %65,3 / %66,1 → %64,3 / %65,8 / %68,0. MS ve NBA'de katkı tutarlı değil: bugünkü gibi (yalnız oran).
#   Yalnız başlamamış maçta hesaplanır (geçmiş maçta tablo maçın kendisini de içerir); analiz kaydına yazılır, kayıttan açılınca aynı sayı.
$global:BProgModel = @{ w0 = 88.6615; w1 = 0.44214; w2 = 12.59253; mu = 158.4806; sd = 23.2804; s = 17.4846 }
$global:BProgKarisim = @(-0.04658, 1.14666, 0.2513)
$global:BGucCode = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
namespace BasketGuc {
    // 108. düzeltme: rakibe göre ayarlı puan gücü. Her maçtan sonra: hücum (O) ve savunma zaafı (D) hatanın 0,08'i kadar,
    // lig ortalaması ve ev avantajı 0,02'si kadar düzeltilir. Dosyaya her takımın son durumu ve son ligi yazılır.
    public static class Tablo {
        private class Mac { public long T; public int Ord; public string H; public string A; public string L; public double P1; public double P2; }
        public static string Build(string[] paths, string outPath, string minDate) {
            CultureInfo inv = CultureInfo.InvariantCulture;
            DateTime min = DateTime.ParseExact(minDate, "yyyy-MM-dd", inv);
            Dictionary<string, Mac> byId = new Dictionary<string, Mac>();
            int ord = 0;
            for (int f = 0; f < paths.Length; f++) {
                string p = paths[f];
                if (string.IsNullOrEmpty(p) || !File.Exists(p)) continue;
                HashSet<string> own = new HashSet<string>();
                using (FileStream fs = new FileStream(p, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (StreamReader sr = new StreamReader(fs, Encoding.UTF8)) {
                    string head = sr.ReadLine();
                    if (head == null) continue;
                    string[] hc = head.TrimStart('﻿').Split(';');
                    Dictionary<string, int> ix = new Dictionary<string, int>();
                    for (int i = 0; i < hc.Length; i++) ix[hc[i]] = i;
                    string idc = ix.ContainsKey("mac_id") ? "mac_id" : "id";
                    string[] need = new string[] { idc, "zaman", "ev_id", "dep_id", "skor_ev", "skor_dep" };
                    bool ok = true; int mx = 0;
                    foreach (string n in need) { if (!ix.ContainsKey(n)) { ok = false; break; } mx = Math.Max(mx, ix[n]); }
                    if (!ok) continue;
                    int iId = ix[idc], iZ = ix["zaman"], iH = ix["ev_id"], iA = ix["dep_id"], iS1 = ix["skor_ev"], iS2 = ix["skor_dep"];
                    int iLig = ix.ContainsKey("lig") ? ix["lig"] : -1, iUl = ix.ContainsKey("ulke") ? ix["ulke"] : -1;
                    string line;
                    while ((line = sr.ReadLine()) != null) {
                        string[] c = line.Split(';');
                        if (c.Length <= mx) continue;
                        string id = c[iId];
                        if (id.Length == 0) continue;
                        // ilk dosya öncelikli (aynı maçın son satırı); sonraki dosyalardan yalnız yeni maç
                        if (f > 0 && byId.ContainsKey(id) && !own.Contains(id)) continue;
                        if (f > 0 && own.Contains(id)) continue;
                        DateTime t;
                        if (!DateTime.TryParseExact(c[iZ], "yyyy-MM-dd HH:mm", inv, DateTimeStyles.None, out t)) continue;
                        double p1, p2;
                        if (!double.TryParse(c[iS1], NumberStyles.Float, inv, out p1) || !double.TryParse(c[iS2], NumberStyles.Float, inv, out p2)) continue;
                        if (p1 + p2 <= 40 || t < min || c[iH].Length == 0 || c[iA].Length == 0) continue;
                        string lig = (iLig >= 0 && iLig < c.Length) ? c[iLig] : "";
                        string ul = (iUl >= 0 && iUl < c.Length) ? c[iUl] : "";
                        Mac m = new Mac();
                        m.T = (long)(t - new DateTime(1970, 1, 1)).TotalSeconds; m.H = c[iH]; m.A = c[iA]; m.L = ul + "|" + lig; m.P1 = p1; m.P2 = p2;
                        m.Ord = ord++;   // sıra eşitliğinde dosyadaki (son) yeri
                        byId[id] = m;
                        if (f > 0) own.Add(id);
                    }
                }
            }
            List<Mac> ms = new List<Mac>(byId.Values);
            ms.Sort(delegate (Mac x, Mac y) { int r = x.T.CompareTo(y.T); return r != 0 ? r : x.Ord.CompareTo(y.Ord); });
            const double k = 0.08, kl = 0.02;
            Dictionary<string, double> O = new Dictionary<string, double>(), D = new Dictionary<string, double>(), MU = new Dictionary<string, double>(), HA = new Dictionary<string, double>();
            Dictionary<string, string> LAST = new Dictionary<string, string>();
            Dictionary<string, long> LT = new Dictionary<string, long>();
            Dictionary<string, int> NG = new Dictionary<string, int>();
            foreach (Mac m in ms) {
                if (!MU.ContainsKey(m.L)) { MU[m.L] = (m.P1 + m.P2) / 2.0; HA[m.L] = 3.0; }
                double oh, da, oa, dh;
                O.TryGetValue(m.H, out oh); D.TryGetValue(m.A, out da); O.TryGetValue(m.A, out oa); D.TryGetValue(m.H, out dh);
                double ph = MU[m.L] + HA[m.L] / 2.0 + oh + da, pa = MU[m.L] - HA[m.L] / 2.0 + oa + dh;
                double eh = m.P1 - ph, ea = m.P2 - pa;
                O[m.H] = oh + k * eh; D[m.A] = da + k * eh; O[m.A] = oa + k * ea; D[m.H] = dh + k * ea;
                MU[m.L] = MU[m.L] + kl * (eh + ea) / 2.0; HA[m.L] = HA[m.L] + kl * (eh - ea);
                LAST[m.H] = m.L; LAST[m.A] = m.L; LT[m.H] = m.T; LT[m.A] = m.T;
                int n0; NG.TryGetValue(m.H, out n0); NG[m.H] = n0 + 1; NG.TryGetValue(m.A, out n0); NG[m.A] = n0 + 1;
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("tur;anahtar;a;b;c;d\n");
            foreach (KeyValuePair<string, double> kv in MU) sb.Append("L;" + kv.Key.Replace(";", ",") + ";" + kv.Value.ToString("R", inv) + ";" + HA[kv.Key].ToString("R", inv) + ";;\n");
            foreach (KeyValuePair<string, double> kv in O) sb.Append("T;" + kv.Key + ";" + kv.Value.ToString("R", inv) + ";" + D[kv.Key].ToString("R", inv) + ";" + LAST[kv.Key].Replace(";", ",") + ";" + LT[kv.Key].ToString(inv) + "," + NG[kv.Key].ToString(inv) + "\n");
            string tmp = outPath + ".tmp";
            File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
            if (File.Exists(outPath)) File.Delete(outPath);
            File.Move(tmp, outPath);
            return ms.Count.ToString(inv) + ";" + O.Count.ToString(inv) + ";" + MU.Count.ToString(inv);
        }
    }
}
'@
function global:Build-BGucTablosu([string]$dataDir) {
    if (-not ('BasketGuc.Tablo' -as [type])) { Add-Type -TypeDefinition $global:BGucCode }
    return [BasketGuc.Tablo]::Build(@((Join-Path $dataDir 'basket_mac_sonuclari.csv'), (Join-Path $dataDir 'basket_flash_maclar.csv')), (Join-Path $dataDir 'basket_guc_tablosu.csv'), '2023-07-01')
}
function global:Read-BGucTablosu([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return $null }
    $t = New-Object 'System.Collections.Generic.Dictionary[string,object]'; $l = New-Object 'System.Collections.Generic.Dictionary[string,double]'
    foreach ($line in [IO.File]::ReadAllLines($path, [Text.Encoding]::UTF8)) {
        $c = $line.Split(';'); if ($c.Count -lt 5) { continue }
        if ($c[0] -eq 'L') { $l[$c[1]] = [double]::Parse($c[2], $global:BInv) }
        elseif ($c[0] -eq 'T') { $t[$c[1]] = @([double]::Parse($c[2], $global:BInv), [double]::Parse($c[3], $global:BInv), $c[4]) }
    }
    if ($t.Count -eq 0) { return $null }
    return @{ T = $t; L = $l; Saat = (Get-Item -LiteralPath $path).LastWriteTime }
}
# iç / dış son 7 maç toplamı + puan gücü -> programın toplam tahmini (takım ya da lig tabloda yoksa $null)
function global:Get-BProgToplam($guc, [string]$homeId, [string]$awayId, [double]$icDis) {
    if ($null -eq $guc -or -not $homeId -or -not $awayId) { return $null }
    $h = $null; $a = $null
    if ($guc.T.ContainsKey($homeId)) { $h = $guc.T[$homeId] }
    if ($guc.T.ContainsKey($awayId)) { $a = $guc.T[$awayId] }
    $lk = $(if ($null -ne $h) { [string]$h[2] } elseif ($null -ne $a) { [string]$a[2] } else { '' })
    if (-not $lk -or -not $guc.L.ContainsKey($lk)) { return $null }
    $oh = 0.0; $dh = 0.0; $oa = 0.0; $da = 0.0
    if ($null -ne $h) { $oh = [double]$h[0]; $dh = [double]$h[1] }
    if ($null -ne $a) { $oa = [double]$a[0]; $da = [double]$a[1] }
    $guc2 = 2.0 * $guc.L[$lk] + $oh + $da + $oa + $dh
    $M = $global:BProgModel
    return [double]$M.w0 + [double]$M.w1 * $icDis + [double]$M.w2 * ($guc2 - [double]$M.mu) / [double]$M.sd
}
function global:Get-BNormCdf([double]$x) {
    # Abramowitz-Stegun 7.1.26 (hata < 1,5e-7)
    $z = [Math]::Abs($x) / [Math]::Sqrt(2.0); $t = 1.0 / (1.0 + 0.3275911 * $z)
    $y = 1.0 - (((((1.061405429 * $t - 1.453152027) * $t) + 1.421413741) * $t - 0.284496736) * $t + 0.254829592) * $t * [Math]::Exp(-$z * $z)
    if ($x -ge 0) { return 0.5 * (1.0 + $y) } else { return 0.5 * (1.0 - $y) }
}

function global:Test-BNba([string]$league) { return ([string]$league).Trim() -match '^(USA:\s*)?NBA$' }

function global:Set-BProp($o, [string]$name, $value) {
    if ($null -eq $o) { return }
    $p = $o.PSObject.Properties[$name]
    if ($p) { $p.Value = $value } else { $o.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new($name, $value)) }
}

function global:Get-BOranYuzde([string]$kind, [bool]$nba, $odds, $other) {
    $o = Read-BNumber $odds; $x = Read-BNumber $other
    if ($null -eq $o -or $null -eq $x -or $o -le 1.0 -or $x -le 1.0) { return $null }
    $fair = (1.0 / $o) / ((1.0 / $o) + (1.0 / $x))
    $fair = [Math]::Min(0.98, [Math]::Max(0.02, $fair))
    $key = if ($kind -eq 'MS') { 'MS' } elseif ($nba) { 'NBA ' + $kind } else { $kind }
    $k = $global:BOranKatsayi[$key]
    $z = $k[0] + $k[1] * [Math]::Log($fair / (1.0 - $fair))
    return [pscustomobject]@{ P = 1.0 / (1.0 + [Math]::Exp(-$z)); Fair = $fair; Odds = $o }
}

# Kayıtlar ile tek maç aynı hesaptan karar verir (74. düzeltme kuralı): canlı analiz de eski kayıt da buradan geçer.
# -SadeceKarar: binlerce eski kayıtta yalnız karar hesaplanır (çizgi yüzdeleri maç açılınca yazılır); hesap aynı.
function global:Set-BKarar($row, [switch]$SadeceKarar) {
    if ($null -eq $row) { return }
    $tr = [Globalization.CultureInfo]::GetCultureInfo('tr-TR')
    $inv = [Globalization.CultureInfo]::InvariantCulture
    $style = [Globalization.NumberStyles]::Float
    $nba = Test-BNba ([string]$row.League)
    $nesine = [string]$row.Code -match '^\d+$'   # site kodu sayı; Flashscore kodlu eski kayıtların oranı Flashscore'dan
    $maxFair = 1.0 / ($global:BEnDusukOran * $global:BNesinePayi)   # Flashscore oranında 1,30 kuralının site karşılığı
    $actual = Read-BNumber $row.Actual
    $ka = $global:BOranKatsayi[$(if ($nba) { 'NBA Alt' } else { 'Alt' })]
    $ku = $global:BOranKatsayi[$(if ($nba) { 'NBA Üst' } else { 'Üst' })]
    $km = $global:BOranKatsayi['MS']
    # 108: programın toplam tahmini (varsa, NBA dışı) Alt / Üst yüzdesine katılır
    $progT = Read-BNumber $row.ProgToplam; $progS = Read-BNumber $row.ProgSapma
    $prog = (-not $nba -and $null -ne $progT -and $null -ne $progS -and $progS -gt 0)
    $kk = $global:BProgKarisim
    $bf = Get-BHucreF $row   # 131: hücre denetiminin ekleri (takım karnesi, iç / dış, form, dinlenme)
    $bestP = -1.0; $bestText = ''; $bestOdds = $null; $bestHit = $null
    foreach ($l in @($row.Lines)) {
        if ($null -eq $l) { continue }
        $lineText = [string]$l.Line
        if (-not $lineText) { continue }
        $u = 0.0; $o = 0.0
        if (-not [double]::TryParse(([string]$l.UnderOdds).Replace(',', '.'), $style, $inv, [ref]$u) -or
            -not [double]::TryParse(([string]$l.OverOdds).Replace(',', '.'), $style, $inv, [ref]$o) -or $u -le 1.0 -or $o -le 1.0) {
            if (-not $SadeceKarar) { Set-BProp $l 'Under' ''; Set-BProp $l 'Over' '' }
            continue
        }
        $fu = (1.0 / $u) / ((1.0 / $u) + (1.0 / $o))
        $fu = [Math]::Min(0.98, [Math]::Max(0.02, $fu))
        $lg = [Math]::Log($fu / (1.0 - $fu))
        $line = 0.0
        $hasLine = [double]::TryParse($lineText.Replace(',', '.'), $style, $inv, [ref]$line)
        if ($prog -and $hasLine) {
            $pp = [Math]::Min(0.98, [Math]::Max(0.02, (Get-BNormCdf (($progT - $line) / $progS))))
            $po = 1.0 / (1.0 + [Math]::Exp(-([double]$kk[0] - [double]$kk[1] * $lg + [double]$kk[2] * [Math]::Log($pp / (1.0 - $pp)))))
            $pu = 1.0 - $po
        } else {
            $pu = 1.0 / (1.0 + [Math]::Exp(-($ka[0] + $ka[1] * $lg)))
            $po = 1.0 / (1.0 + [Math]::Exp(-($ku[0] - $ku[1] * $lg)))
        }
        if ($null -ne $bf -and $hasLine) {
            $dl = [BasketHucre.Hucre]::Delta($bf, $line)
            $pu = 1.0 / (1.0 + [Math]::Exp(-([Math]::Log($pu / (1.0 - $pu)) - $dl)))
            $po = 1.0 / (1.0 + [Math]::Exp(-([Math]::Log($po / (1.0 - $po)) + $dl)))
        }
        if (-not $SadeceKarar) {
            Set-BProp $l 'Under' (100 * $pu).ToString('0.0', $tr)
            Set-BProp $l 'Over' (100 * $po).ToString('0.0', $tr)
        }
        $okU = if ($nesine) { $u -ge $global:BEnDusukOran } else { $fu -le $maxFair }
        $okO = if ($nesine) { $o -ge $global:BEnDusukOran } else { (1.0 - $fu) -le $maxFair }
        if ($okU -and $pu -gt $bestP) {
            $bestP = $pu; $bestText = "$lineText Alt"; $bestOdds = $u
            $bestHit = if ($null -ne $actual -and $hasLine -and $actual -ne $line) { $actual -lt $line } else { $null }
        }
        if ($okO -and $po -gt $bestP) {
            $bestP = $po; $bestText = "$lineText Üst"; $bestOdds = $o
            $bestHit = if ($null -ne $actual -and $hasLine -and $actual -ne $line) { $actual -gt $line } else { $null }
        }
    }
    # 109. düzeltme (kullanıcı, 15 Kasım): baskette MS bahsi yok. Maç sonucu yüzdesi hesaplanmaz, aday olmaz (eski kayıtta da).
    Set-BProp $row 'HomeWinProbability' $null
    Set-BProp $row 'AwayWinProbability' $null
    $props = $row.PSObject.Properties
    if ($null -eq $props['KararSonuc']) {
        foreach ($n in @('Candidate','CandidateProbability','CandidateOdds','Edge','Karar','KararText','KararSonuc')) {
            if ($null -eq $props[$n]) { $props.Add([System.Management.Automation.PSNoteProperty]::new($n, $null)) }
        }
    }
    if ($bestP -lt 0) {
        $row.Candidate = ''; $row.CandidateProbability = $null; $row.CandidateOdds = $null
        $row.Karar = ''; $row.KararText = ''; $row.KararSonuc = ''
        return
    }
    $play = $bestP -ge $global:BOynaSiniri
    $pctText = '%' + (100 * $bestP).ToString('0', $tr)
    $row.Candidate = $bestText
    $row.CandidateProbability = $bestP
    $row.CandidateOdds = $bestOdds
    $row.Edge = 0.0
    $row.Karar = if ($play) { 'OYNA' } else { 'OYNAMA' }
    $row.KararText = if ($play) { "OYNA · $bestText $pctText" } else { "OYNAMA · en iyi $pctText" }
    $row.KararSonuc = if (-not $play -or $null -eq $bestHit) { '' } elseif ($bestHit) { 'Tuttu' } else { 'Tutmadı' }
}

function global:Get-BSelectedBulletin([int]$offset, [int]$days, [string[]]$codes, [string]$providerId) {
    $now = [DateTimeOffset]::UtcNow
    $today = $now.ToOffset($global:BTz).Date
    $start = [DateTimeOffset]::new($today.AddDays($offset), $global:BTz).ToUnixTimeSeconds()
    $end = [DateTimeOffset]::new($today.AddDays($offset + $days), $global:BTz).ToUnixTimeSeconds()
    Get-BUpcomingBulletin ([Math]::Max($now.ToUnixTimeSeconds(), $start)) $end $codes $providerId | Sort-Object Kick
}

function global:Get-BSavedBulletin([string[]]$codes, [string]$backupPath, [bool]$pastOnly) {
    $found = @{}
    $now = ([DateTimeOffset]::UtcNow).ToUnixTimeSeconds()
    $paths = @((Join-Path $Shared.DataDir 'basket_nesine_oranlar.csv'), $backupPath)
    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        foreach ($r in (Import-Csv -LiteralPath $path -Delimiter ';' -Encoding UTF8)) {
            if ($codes -notcontains [string]$r.kod) { continue }
            $kick = 0L
            $at = [datetime]::MinValue
            if (-not [long]::TryParse([string]$r.ko,[ref]$kick) -or
                -not [datetime]::TryParseExact([string]$r.kayit,'yyyy-MM-dd HH:mm',$global:BInv,[Globalization.DateTimeStyles]::None,[ref]$at)) { continue }
            $kickDate = [DateTimeOffset]::FromUnixTimeSeconds($kick).ToOffset($global:BTz).DateTime
            if ($at -ge $kickDate -or ($pastOnly -and $kick -gt $now)) { continue }

            $markets = @(foreach ($entry in ($r.bahisler -split '\|')) {
                $parts = $entry -split ':',3
                if ($parts.Count -ne 3 -or $parts[0] -notin @('149','142')) { continue }
                $outcomes = @(foreach ($item in ($parts[2] -split '/')) {
                    $pair = $item -split '=',2
                    if ($pair.Count -eq 2) { @{ N = $pair[0]; O = $pair[1] } }
                })
                @{ MTID = $parts[0]; SOV = $parts[1]; OCA = $outcomes }
            })
            $lines = @(Get-BUpcomingLines @{ MA = $markets })
            $winner = Get-BWinnerOdds @{ MA = $markets }
            $quality = if (@($lines | Where-Object { $null -ne $_.Under }).Count) { 2 } elseif ($lines.Count) { 1 } else { 0 }
            $existing = $found[$r.kod]
            if ($null -ne $existing -and
                ($existing.LineQuality -gt $quality -or
                 ($existing.LineQuality -eq $quality -and $existing.CachedAt -ge $at))) { continue }
            $found[$r.kod] = [pscustomobject]@{
                Code = [string]$r.kod; Kick = $kick; Home = [string]$r.ev; Away = [string]$r.dep
                League = [string]$r.lig; Lines = $lines; CachedAt = $at; LineQuality = $quality
                WinnerHome = $(if ($winner) { $winner.Home }); WinnerAway = $(if ($winner) { $winner.Away })
            }
        }
    }
    $found.Values
}

function global:Get-BSavedResult($match) {
    $path = Join-Path $Shared.DataDir 'basket_nesine_sonuclar.csv'
    if (-not (Test-Path -LiteralPath $path)) { return }
    foreach ($r in (Import-Csv -LiteralPath $path -Delimiter ';' -Encoding UTF8)) {
        if ([string]$r.kod -ne $match.Code -or [string]$r.durum -notin @('MS','UZT')) { continue }
        $kick = 0L; $homeScore = 0; $awayScore = 0
        if ([long]::TryParse([string]$r.ko,[ref]$kick) -and [Math]::Abs($kick - $match.Kick) -le 5400 -and
            [int]::TryParse([string]$r.skor_ev,[ref]$homeScore) -and [int]::TryParse([string]$r.skor_dep,[ref]$awayScore)) {
            return ($homeScore + $awayScore)
        }
    }
}

function global:New-BPastMatch([string]$code, [long]$kick, [string]$homeName, [string]$awayName, [string]$league, $actual, $homeScore = $null, $awayScore = $null) {
    if ($kick -le 0 -or $kick -gt ([DateTimeOffset]::UtcNow).ToUnixTimeSeconds() -or -not $homeName -or -not $awayName) { return }
    [pscustomobject]@{
        Code = $code; Kick = $kick; Home = $homeName; Away = $awayName; League = $league
        Lines = @(); IsPast = $true; Actual = $actual; WinnerHome = $null; WinnerAway = $null
        ActualHome = $(if ($null -ne $actual) { Read-BNumber $homeScore }); ActualAway = $(if ($null -ne $actual) { Read-BNumber $awayScore })
    }
}

function global:Get-BPastScore([string]$homeScore, [string]$awayScore) {
    $h = 0; $a = 0
    if ([int]::TryParse($homeScore,[ref]$h) -and [int]::TryParse($awayScore,[ref]$a) -and $h -ge 0 -and $a -ge 0 -and ($h + $a) -gt 0) {
        return ($h + $a)
    }
}

function global:Get-BPastMatches([string[]]$codes, [string]$archivePath, [string]$requestedDay, [string]$providerId, [hashtable]$references) {
    $known = @{}
    $local = Join-Path $Shared.DataDir 'basket_nesine_sonuclar.csv'
    foreach ($path in @($local, $archivePath)) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        foreach ($r in (Import-Csv -LiteralPath $path -Delimiter ';' -Encoding UTF8)) {
            $id = [string]$r.kod
            if ($codes -notcontains $id -or $known.ContainsKey($id) -or [string]$r.durum -notin @('MS','UZT')) { continue }
            $kick = 0L
            if (-not [long]::TryParse([string]$r.ko,[ref]$kick)) { continue }
            $matchDay = if ($references -and $references[$id].Day) { $references[$id].Day } else { $requestedDay }
            if ($matchDay -and $kick -gt 0 -and
                [DateTimeOffset]::FromUnixTimeSeconds($kick).ToOffset($global:BTz).ToString('yyyyMMdd', $global:BInv) -ne $matchDay) { continue }
            $m = New-BPastMatch $id $kick ([string]$r.ev) ([string]$r.dep) ([string]$r.lig) (Get-BPastScore $r.skor_ev $r.skor_dep) $r.skor_ev $r.skor_dep
            if ($null -ne $m) { $known[$id] = $m }
        }
    }
    $missing = @($codes | Where-Object { -not $known.ContainsKey($_) })
    if ($missing.Count -gt 0 -and $requestedDay) {
        $date = [datetime]::MinValue
        if ([datetime]::TryParseExact($requestedDay,'yyyyMMdd',$global:BInv,[Globalization.DateTimeStyles]::None,[ref]$date) -and
            $date -le ([DateTimeOffset]::UtcNow).ToOffset($global:BTz).Date) {
            try {
                $endpoint = 'https://ls.nesine.com/api/v2/LiveScore/GetUnliveMatches?sportType=2&date=' + $date.ToString('yyyy-MM-dd',$global:BInv)
                $result = ConvertFrom-BJson (Invoke-BGet $endpoint 'https://www.nesine.com/iddaa/canli-skor/basketbol' @{ Origin = 'https://www.nesine.com' })
                if ($result -isnot [System.Collections.IDictionary] -or $null -eq $result['d']) { throw 'Site skor yanıtı okunamadı.' }
                foreach ($r in @($result['d'])) {
                    $id = if ($references) {
                        foreach ($code in $missing) {
                            $matchCode = Find-BNesineCode $r @($code) $references[$code].ProviderId 'LSBRID'
                            if ($matchCode) { $matchCode; break }
                        }
                    } else { Find-BNesineCode $r $missing $providerId 'LSBRID' }
                    if (-not $id) { continue }
                    $time = [DateTimeOffset]::MinValue
                    $kick = 0L
                    if ([DateTimeOffset]::TryParse([string]$r['matchDate'],$global:BInv,[Globalization.DateTimeStyles]::None,[ref]$time)) {
                        $kick = $time.ToUnixTimeSeconds()
                    } else {
                        $ms = 0L
                        if ([long]::TryParse([string]$r['MDE'],[ref]$ms)) { $kick = [long][Math]::Floor($ms / 1000.0) }
                    }
                    $actual = $null; $homePoints = $null; $awayPoints = $null
                    if ([string]$r['S'] -eq '5' -or [string]$r['ST'] -in @('MS','UZT')) {
                        foreach ($pair in @(@('HS','AS'),@('HSC','ASC'),@('H','A'))) {
                            $actual = Get-BPastScore ([string]$r[$pair[0]]) ([string]$r[$pair[1]])
                            if ($null -ne $actual) { $homePoints = [string]$r[$pair[0]]; $awayPoints = [string]$r[$pair[1]]; break }
                        }
                        if ($null -eq $actual) {
                            foreach ($period in @($r['ES'])) {
                                if ($period -is [System.Collections.IDictionary] -and [string]$period['T'] -in @('19','1')) {
                                    $total = Get-BPastScore ([string]$period['H']) ([string]$period['A'])
                                    if ($null -ne $total) {
                                        $actual = $total; $homePoints = [string]$period['H']; $awayPoints = [string]$period['A']
                                        if ([string]$period['T'] -eq '19') { break }
                                    }
                                }
                            }
                        }
                    }
                    $m = New-BPastMatch $id $kick ([string]$r['HT']) ([string]$r['AT']) ([string]$r['L']) $actual $homePoints $awayPoints
                    if ($null -ne $m) { $known[$id] = $m }
                }
            } catch {
                Write-BLog ('Geçmiş maç sonucu sorgusu başarısız: ' + $_.Exception.Message)
                if ($codes.Count -eq 1) { throw 'Site skor servisine erişilemedi.' }
            }
        }
    }
    $known.Values
}

# The Nesine score archive can identify both teams even without a Flashscore fixture.
function global:Read-BNesineHistory([string]$scoreArchive, [string]$quoteArchive) {
    $scores = @{}
    $leagueRows = @{}
    $teamRows = @{}
    $names = @{}
    foreach ($path in @((Join-Path $Shared.DataDir 'basket_nesine_sonuclar.csv'), $scoreArchive)) {
        if (-not $path -or -not (Test-Path -LiteralPath $path)) { continue }
        foreach ($r in (Import-Csv -LiteralPath $path -Delimiter ';' -Encoding UTF8)) {
            if (-not $r.kod -or $scores.ContainsKey($r.kod) -or $r.durum -notin @('MS','UZT')) { continue }
            $total = Get-BPastScore $r.skor_ev $r.skor_dep
            $date = [datetime]::MinValue; $kick = 0L
            if ($null -eq $total -or -not $r.lig -or -not $r.ev -or -not $r.dep -or
                -not [datetime]::TryParseExact($r.zaman,'yyyy-MM-dd HH:mm',$global:BInv,[Globalization.DateTimeStyles]::None,[ref]$date) -or
                -not [long]::TryParse($r.ko,[ref]$kick)) { continue }
            $league = Convert-BTeamName $r.lig
            $homeTeam = Convert-BTeamName $r.ev
            $away = Convert-BTeamName $r.dep
            $scores[$r.kod] = @{ Kick = $kick; League = $league; Home = $homeTeam; Away = $away }
            $row = [pscustomobject]@{ Date = $date; Total = $total }
            if (-not $leagueRows.ContainsKey($league)) { $leagueRows[$league] = New-Object 'System.Collections.Generic.List[object]' }
            $leagueRows[$league].Add($row)
            foreach ($key in @("$league|$homeTeam","$league|$away") | Select-Object -Unique) {
                if (-not $teamRows.ContainsKey($key)) { $teamRows[$key] = New-Object 'System.Collections.Generic.List[object]' }
                $teamRows[$key].Add($row)
            }
        }
    }
    foreach ($path in @((Join-Path $Shared.DataDir 'basket_nesine_oranlar.csv'), $quoteArchive)) {
        if (-not $path -or -not (Test-Path -LiteralPath $path)) { continue }
        foreach ($r in (Import-Csv -LiteralPath $path -Delimiter ';' -Encoding UTF8)) {
            $score = $scores[[string]$r.kod]
            $kick = 0L
            if ($null -eq $score -or -not [long]::TryParse($r.ko,[ref]$kick) -or [Math]::Abs($kick - $score.Kick) -gt 5400) { continue }
            foreach ($pair in @(@($r.ev,$score.Home),@($r.dep,$score.Away))) {
                if (-not $pair[0]) { continue }
                $key = $score.League + '|' + (Convert-BTeamName $pair[0])
                if (-not $names.ContainsKey($key)) { $names[$key] = $pair[1] }
                elseif ($names[$key] -ne $pair[1]) { $names[$key] = '' }
            }
        }
    }
    return @{ Leagues = $leagueRows; Teams = $teamRows; Names = $names }
}

function global:Get-BNesineHistoryEstimate($match, $index, [datetime]$cut) {
    $league = Convert-BTeamName $match.League
    $leagueRows = @($index.Leagues[$league] | Where-Object Date -LT $cut)
    if ($leagueRows.Count -lt 10) { return }
    $homeTeam = Convert-BTeamName $match.Home
    $away = Convert-BTeamName $match.Away
    if ($index.Names["$league|$homeTeam"]) { $homeTeam = $index.Names["$league|$homeTeam"] }
    if ($index.Names["$league|$away"]) { $away = $index.Names["$league|$away"] }
    if (-not $homeTeam -or -not $away -or $homeTeam -eq $away) { return }
    $homeRows = @($index.Teams["$league|$homeTeam"] | Where-Object Date -LT $cut | Sort-Object Date -Descending | Select-Object -First 5)
    $awayRows = @($index.Teams["$league|$away"] | Where-Object Date -LT $cut | Sort-Object Date -Descending | Select-Object -First 5)
    if ($homeRows.Count -lt 2 -or $awayRows.Count -lt 2) { return }
    $leagueMean = ($leagueRows | Measure-Object Total -Average).Average
    $homeMean = (($homeRows | Measure-Object Total -Sum).Sum + 3 * $leagueMean) / ($homeRows.Count + 3)
    $awayMean = (($awayRows | Measure-Object Total -Sum).Sum + 3 * $leagueMean) / ($awayRows.Count + 3)
    [pscustomobject]@{ Total = ($homeMean + $awayMean) / 2.0; HomeCount = $homeRows.Count; AwayCount = $awayRows.Count }
}

function global:Get-BForecasts([string]$modelPath, [string]$seedPath, [string[]]$codes, [int]$offset, [int]$days, [string]$backupPath, [bool]$pastOnly, [string]$scoreArchive, [string]$requestedDay, [string]$providerId, [hashtable]$references) {
    $ErrorActionPreference = 'Stop'
    $model = ConvertFrom-BJson ([IO.File]::ReadAllText($modelPath, [Text.Encoding]::UTF8))
    [double[]]$errors = $model['errors']
    $aliases = $model['aliases']
    if ($errors.Length -lt 100 -or $null -eq $aliases) { throw 'Kalibrasyon dosyası okunamadı.' }
    $gamesToAnalyze = @()
    $saved = @()
    if ($codes.Count -gt 0) { $saved = @(Get-BSavedBulletin $codes $backupPath $pastOnly) }
    $now = ([DateTimeOffset]::UtcNow).ToUnixTimeSeconds()
    if ($requestedDay) {
        $saved = @($saved | Where-Object {
            [DateTimeOffset]::FromUnixTimeSeconds($_.Kick).ToOffset($global:BTz).ToString('yyyyMMdd', $global:BInv) -eq $requestedDay
        })
    }
    $startedBulletin = @()
    $scoreError = $null
    $bulletinError = $null
    $needsBulletin = -not $pastOnly -and -not ($codes.Count -eq 1 -and $saved.Count -eq 1 -and $saved[0].Kick -le $now)
    if ($needsBulletin) {
        try {
            $bulletin = @(Get-BSelectedBulletin $offset $days $codes $providerId)
            $gamesToAnalyze = @($bulletin | Where-Object { -not $_.IsPast })
            $startedBulletin = @($bulletin | Where-Object IsPast)
        } catch {
            if ($saved.Count -eq 0 -and $codes.Count -eq 0) { throw }
            $bulletinError = $_
        }
    }
    $found = @{}
    foreach ($m in $gamesToAnalyze) { $found[$m.Code] = $true }
    $missing = @($codes | Where-Object { -not $found.ContainsKey($_) })
    if ($missing.Count -gt 0) {
        $pastMatches = @()
        try {
            $pastMatches = @(Get-BPastMatches $missing $scoreArchive $requestedDay $providerId $references)
            $undatedCodes = @($missing | Where-Object { $pastMatches.Code -notcontains $_ })
            if ($references) {
                $datedGroups = @($undatedCodes | Where-Object { $references.ContainsKey($_) -and $references[$_].Day } |
                    Group-Object -Property { $references[$_].Day })
                foreach ($group in $datedGroups) {
                    try { $pastMatches += @(Get-BPastMatches $group.Group $scoreArchive $group.Name '' $references) }
                    catch { $scoreError = $_ }
                }
            }
        }
        catch { $scoreError = $_ }
        if ($pastOnly -and $providerId -and $pastMatches.Count -eq 0 -and $saved.Count -eq 0) {
            try { $startedBulletin = @(Get-BSelectedBulletin $offset $days $missing $providerId | Where-Object IsPast) }
            catch { $bulletinError = $_ }
        }
        foreach ($past in $pastMatches) {
            $snapshot = $saved | Where-Object { $_.Code -eq $past.Code -and [Math]::Abs($_.Kick - $past.Kick) -le 5400 } | Select-Object -First 1
            if ($null -ne $snapshot) {
                $past.Lines = $snapshot.Lines
                $past.WinnerHome = $snapshot.WinnerHome; $past.WinnerAway = $snapshot.WinnerAway
                $past | Add-Member -NotePropertyName CachedAt -NotePropertyValue $snapshot.CachedAt
            }
            $gamesToAnalyze += $past
            $found[$past.Code] = $true
        }
    }
    $gamesToAnalyze += @($saved | Where-Object { -not $found.ContainsKey($_.Code) })
    $gamesToAnalyze += @($startedBulletin | Where-Object { -not $found.ContainsKey($_.Code) -and $saved.Code -notcontains $_.Code })
    $resolvedCodes = @($gamesToAnalyze | ForEach-Object Code)
    if ($codes.Count -gt 1 -or $references) {
        foreach ($code in ($codes | Select-Object -Unique)) {
            if ($resolvedCodes -contains $code) { continue }
            $message = 'Maç kaydı bulunamadı.'
            if ($scoreError) { $message = 'Maç kaydı bulunamadı. Skor servisi yanıt vermedi.' }
            elseif ($bulletinError) { $message = 'Maç kaydı bulunamadı. Bülten servisi yanıt vermedi.' }
            Write-BLog "$code · $message"
            [pscustomobject]@{ Code = $code; Expected = ''; Actual = ''; Status = $message; Lines = @() }
        }
    }
    if ($gamesToAnalyze.Count -eq 0) {
        if ($references -or $codes.Count -gt 1) { return }
        if ($scoreError) { throw $scoreError }
        if ($bulletinError) { throw 'Site bülten servisine erişilemedi.' }
        return
    }
    $today = ([DateTimeOffset]::UtcNow).ToOffset($global:BTz).Date
    $dayOffsets = @(foreach ($g in $gamesToAnalyze) {
        if (($g.CachedAt -or $g.IsPast) -and $aliases.ContainsKey((Convert-BTeamName $g.Home)) -and $aliases.ContainsKey((Convert-BTeamName $g.Away))) { continue }
        $day = [DateTimeOffset]::FromUnixTimeSeconds($g.Kick).ToOffset($global:BTz).Date
        $d = ($day - $today).Days
        if ($d -lt -7 -or $d -gt 8) { continue }
        $d
        if ($d -ge -6) { $d - 1 }
    })
    $fixtures = @(foreach ($offset in ($dayOffsets | Sort-Object -Unique)) {
        try { $day = Get-BFlashDay $offset }
        catch {
            Write-BLog ("Flashscore fikstürü alınamadı (gün $offset). " + $_.Exception.Message)
            continue
        }
        foreach ($f in $day) {
            $kick = 0L
            if (-not $f['PX'] -or -not $f['PY'] -or -not [long]::TryParse([string]$f['AD'], [ref]$kick)) { continue }
            [pscustomobject]@{
                Id = [string]$f['AA']; Kick = $kick; HomeId = [string]$f['PX']; AwayId = [string]$f['PY']
                Home = (Convert-BTeamName $f['AE']); Away = (Convert-BTeamName $f['AF']); HomeRaw = [string]$f['AE']; AwayRaw = [string]$f['AF']
            }
        }
    })
    $fixtures = @($fixtures | Group-Object -Property Id -CaseSensitive | ForEach-Object { $_.Group[0] })
    $wanted = New-Object 'System.Collections.Generic.HashSet[string]'
    $global:BKelimeEsles = 0
    foreach ($m in $gamesToAnalyze) {
        $f = Find-BForecastFixture $m $fixtures $aliases
        if ($null -eq $f) {
            $homeName = Convert-BTeamName $m.Home
            $awayName = Convert-BTeamName $m.Away
            if ($aliases.ContainsKey($homeName) -and $aliases.ContainsKey($awayName) -and $aliases[$homeName] -cne $aliases[$awayName]) {
                $f = [pscustomobject]@{ Id = ''; HomeId = [string]$aliases[$homeName]; AwayId = [string]$aliases[$awayName] }
            }
        }
        $m | Add-Member -NotePropertyName Fixture -NotePropertyValue $f
        if ($null -ne $f) {
            [void]$wanted.Add($f.HomeId + '|ev')
            [void]$wanted.Add($f.AwayId + '|dep')
        }
    }
    if ($global:BKelimeEsles -gt 0) { try { Write-BLog ('Flashscore eşleşmesi: ' + $global:BKelimeEsles + ' maç takım adının kelimesiyle bulundu (113. düzeltme)') } catch {} }
    $history = Read-BForecastHistory $wanted $seedPath
    $guc = $null; try { $guc = Read-BGucTablosu (Join-Path $Shared.DataDir 'basket_guc_tablosu.csv') } catch { $guc = $null }
    $tr = [Globalization.CultureInfo]::GetCultureInfo('tr-TR')
    $historyServiceAvailable = $true
    $nesineHistory = $null
    foreach ($m in $gamesToAnalyze) {
        $started = $m.Kick -le ([DateTimeOffset]::UtcNow).ToUnixTimeSeconds()
        $actual = if ($m.IsPast) { $m.Actual } elseif ($started) { Get-BSavedResult $m }
        $status = ''; $totalText = ''; $modelView = ''; $limited = $false; $bestText = ''; $bestEdge = 0.0; $bestProbability = $null; $bestOdds = $null; $lineRows = @(); $projectedHome = $null; $projectedAway = $null; $projectedScore = $null; $scoreTexts = @(); $scoreRows = @(); $homeWinPct = 0.0; $awayWinPct = 0.0
        $homeScored = $null; $homeAllowed = $null; $awayScored = $null; $awayAllowed = $null; $homeSampleCount = 0; $awaySampleCount = 0
        $progT = $null
        $kickDate = [DateTimeOffset]::FromUnixTimeSeconds($m.Kick).ToOffset($global:BTz).DateTime
        $cut = $kickDate.AddHours(-3)
        $analysisCut = ([DateTimeOffset]::UtcNow).ToOffset($global:BTz).DateTime.AddHours(-3)
        if ($analysisCut -lt $cut) { $cut = $analysisCut }
        if ($m.CachedAt -and $m.Lines.Count -gt 0 -and $m.CachedAt -lt $cut) { $cut = $m.CachedAt }
        if ($null -eq $m.Fixture) { $status = 'Takımlar Flashscore geçmişiyle eşleşmedi.' }
        else {
          # 114. düzeltme: bir maçın hesabı hata verirse yalnız o maç "hesap yapılamadı" olur, bütün analiz durmaz
          try {
            $hv = @($history[$m.Fixture.HomeId + '|ev'] | Where-Object Date -LT $cut | Sort-Object Date -Descending | Select-Object -First 7)
            $av = @($history[$m.Fixture.AwayId + '|dep'] | Where-Object Date -LT $cut | Sort-Object Date -Descending | Select-Object -First 7)
            if (($hv.Count -lt 5 -or $av.Count -lt 5) -and $m.Fixture.Id -and $historyServiceAvailable) {
                try {
                    $recent = @(Get-BFixtureHistory $m.Fixture.Id $cut)
                    $homeId = $m.Fixture.HomeId
                    $awayId = $m.Fixture.AwayId
                    # 114. düzeltme: Flashscore'dan o an çekilen maçlar da takımın attığı / yediği sayıyla aynı biçime çevrilir
                    $hRecent = @($recent | Where-Object { $_.HomeId -ceq $homeId } | ForEach-Object { [pscustomobject]@{ Id = $_.Id; Date = $_.Date; Total = $_.Total; TeamScore = $_.HomeScore; OppScore = $_.AwayScore } })
                    $aRecent = @($recent | Where-Object { $_.AwayId -ceq $awayId } | ForEach-Object { [pscustomobject]@{ Id = $_.Id; Date = $_.Date; Total = $_.Total; TeamScore = $_.AwayScore; OppScore = $_.HomeScore } })
                    $hv = @($hv + $hRecent |
                        Group-Object -Property Id -CaseSensitive | ForEach-Object { $_.Group[0] } |
                        Sort-Object Date -Descending | Select-Object -First 7)
                    $av = @($av + $aRecent |
                        Group-Object -Property Id -CaseSensitive | ForEach-Object { $_.Group[0] } |
                        Sort-Object Date -Descending | Select-Object -First 7)
                } catch {
                    $historyServiceAvailable = $false
                    Write-BLog ('Flashscore takım geçmişi alınamadı. ' + $_.Exception.Message)
                }
            }
            $homeSampleCount = $hv.Count; $awaySampleCount = $av.Count
            $limited = $hv.Count -lt 5 -or $av.Count -lt 5
            if ($hv.Count -lt 3 -or $av.Count -lt 3) { $status = "İç/dış veri yetersiz ($($hv.Count)/$($av.Count)). Yorum için iki tarafta da en az 3 maç gerekli." }
            else {
                $total = (($hv | Measure-Object Total -Average).Average + ($av | Measure-Object Total -Average).Average) / 2.0
                # 108: başlamamış maçta toplam tahmini puan gücüyle (ekranda ve Alt / Üst yüzdesinde aynı sayı)
                $icDis = $total
                if (-not $started) { try { $progT = Get-BProgToplam $guc $m.Fixture.HomeId $m.Fixture.AwayId $icDis } catch { $progT = $null } }
                if ($null -ne $progT) { $total = $progT }
                $totalText = $total.ToString('0.00', $tr)
                $status = "İç saha $($hv.Count) maç · Dış saha $($av.Count) maç" + $(if ($null -ne $progT) { ' · puan gücü' } else { '' })
                if ($limited) { $status += ' · Sınırlı veri' }
                $medianTotal = ((Get-BMedian $hv.Total) + (Get-BMedian $av.Total)) / 2.0
                $homeScored = ($hv | Measure-Object TeamScore -Average).Average
                $homeAllowed = ($hv | Measure-Object OppScore -Average).Average
                $awayScored = ($av | Measure-Object TeamScore -Average).Average
                $awayAllowed = ($av | Measure-Object OppScore -Average).Average
                $projectedHome = ($homeScored + $awayAllowed) / 2.0
                $projectedAway = ($awayScored + $homeAllowed) / 2.0
                if (($projectedHome + $projectedAway) -gt 0) {
                    $scoreScale = $total / ($projectedHome + $projectedAway)   # 108: tahmini skorun toplamı da aynı toplam tahmini
                    $projectedHome *= $scoreScale; $projectedAway *= $scoreScale
                }
                $scoreCandidates = New-Object System.Collections.ArrayList
                $homeWins = 0; $awayWins = 0; $ties = 0
                foreach ($homeGame in $hv) {
                    foreach ($awayGame in $av) {
                        $sampleHome = $projectedHome + (($homeGame.TeamScore - $homeScored) + ($awayGame.OppScore - $awayAllowed)) / 2.0
                        $sampleAway = $projectedAway + (($awayGame.TeamScore - $awayScored) + ($homeGame.OppScore - $homeAllowed)) / 2.0
                        [void]$scoreCandidates.Add([pscustomobject]@{ Home=[int][Math]::Round($sampleHome); Away=[int][Math]::Round($sampleAway) })
                        if ($sampleHome -gt $sampleAway) { $homeWins++ } elseif ($sampleAway -gt $sampleHome) { $awayWins++ } else { $ties++ }
                    }
                }
                $sampleCount = [Math]::Max(1, $hv.Count * $av.Count)
                $homeWinPct = 100.0 * ($homeWins + 0.5 * $ties) / $sampleCount
                $awayWinPct = 100.0 * ($awayWins + 0.5 * $ties) / $sampleCount
                $scoreGroups = @($scoreCandidates | Group-Object { "$($_.Home)-$($_.Away)" } | Sort-Object Count -Descending)
                $scoreTexts = @($scoreGroups | Select-Object -First 3 | ForEach-Object { $_.Name })
                $scoreRows = @($scoreGroups | Select-Object -First 3 | ForEach-Object {
                    [pscustomobject]@{ Score = $_.Name; Probability = (100.0 * $_.Count / $sampleCount) }
                })
                $projectedScore = [pscustomobject]@{ Home=[int][Math]::Round($projectedHome); Away=[int][Math]::Round($projectedAway) }
                # 78. düzeltme: çizgi yüzdeleri ve aday artık takım modelinden değil Nesine oranından (Set-BKarar)
            }
          } catch {
            $status = 'Takım geçmişiyle hesap yapılamadı: ' + $_.Exception.Message
            $totalText = ''; $progT = $null; $projectedHome = $null; $projectedAway = $null; $projectedScore = $null
            $homeScored = $null; $homeAllowed = $null; $awayScored = $null; $awayAllowed = $null; $scoreTexts = @(); $scoreRows = @(); $lineRows = @()
            Write-BLog ("$($m.Code) · $($m.Home) / $($m.Away) · " + $status)
          }
        }
        if (-not $totalText) {
            if ($null -eq $nesineHistory) { $nesineHistory = Read-BNesineHistory $scoreArchive $backupPath }
            $fallback = Get-BNesineHistoryEstimate $m $nesineHistory $cut
            if ($null -ne $fallback) {
                $limited = $true
                $total = $fallback.Total
                $totalText = $total.ToString('0.00', $tr)
                $status = "Sınırlı veri · site aynı lig · Takım geçmişi $($fallback.HomeCount)/$($fallback.AwayCount)"
            } else { $status += ' site geçmişi de yetersiz.' }
        }
        if ($totalText) {
            if ($m.Lines.Count) {
                $center = $m.Lines[[int][Math]::Floor(($m.Lines.Count - 1) / 2.0)].Line
                $gap = $total - $center
                $trend = if ($gap -gt 3.0) { 'Üst eğilimi' } elseif ($gap -lt -3.0) { 'Alt eğilimi' } else { 'Çizgiye yakın' }
                $modelView = "$($center.ToString('0.0', $tr)) · $trend"
            } else { $modelView = 'Toplam tahmini · Çizgi yok' }
        }
        if ($lineRows.Count -eq 0 -and $m.Lines.Count -gt 0) {
            $lineRows = @(foreach ($l in $m.Lines) {
                [pscustomobject]@{
                    Line = $l.Line.ToString('0.0', $tr); Under = ''; Over = ''
                    UnderOdds = $(if ($null -ne $l.Under) { $l.Under.ToString('0.00', $tr) })
                    OverOdds = $(if ($null -ne $l.Over) { $l.Over.ToString('0.00', $tr) })
                }
            })
        }
        if (@($m.Lines | Where-Object { $null -ne $_.Under }).Count -eq 0 -and $null -eq $m.WinnerHome) { $status += ' · site oranı yok' }
        if (-not $totalText) { Write-BLog ("$($m.Code) · $($m.Home) / $($m.Away) · $status") }
        if ($m.CachedAt -and $m.Lines.Count -gt 0) { $status = 'Kayıtlı maç öncesi çizgiler · ' + $status }
        if ($started -and $null -eq $actual) { $status += ' · Skor kaydı bekleniyor' }
        $out = [pscustomobject]@{
            Time = Format-BTime $m.Kick; Code = $m.Code; Home = $m.Home; Away = $m.Away; League = $m.League
            Expected = $totalText; ModelView = $modelView; LimitedHistory = [bool]($totalText -and $limited)
            ProjectedHome = $(if ($null -ne $projectedHome) { $projectedHome.ToString('0.0',$tr) }); ProjectedAway = $(if ($null -ne $projectedAway) { $projectedAway.ToString('0.0',$tr) })
            HomeRecentFor = $(if ($null -ne $homeScored) { $homeScored.ToString('0.0',$tr) }); HomeRecentAgainst = $(if ($null -ne $homeAllowed) { $homeAllowed.ToString('0.0',$tr) })
            AwayRecentFor = $(if ($null -ne $awayScored) { $awayScored.ToString('0.0',$tr) }); AwayRecentAgainst = $(if ($null -ne $awayAllowed) { $awayAllowed.ToString('0.0',$tr) })
            HomeSampleCount = $homeSampleCount; AwaySampleCount = $awaySampleCount
            ProjectedScore = $projectedScore; LikelyScores = $scoreTexts; LikelyScoreRows = $scoreRows
            HomeWinProbability = $null; AwayWinProbability = $null   # 78: maç sonucu yüzdesi yalnız site oranından (takım modeli %53 tuttu)
            WinnerHome = $(if ($null -ne $m.WinnerHome) { ([double]$m.WinnerHome).ToString('0.00',$tr) }); WinnerAway = $(if ($null -ne $m.WinnerAway) { ([double]$m.WinnerAway).ToString('0.00',$tr) })
            Actual = $actual; ActualHome = $m.ActualHome; ActualAway = $m.ActualAway
            Candidate = ''; CandidateProbability = $null; CandidateOdds = $null; Edge = 0.0; Karar = ''; KararText = ''; KararSonuc = ''
            Status = $status; Mode = $(if ($started) { 'Geçmiş maç' } else { 'Maç öncesi' }); Lines = $lineRows
            ProgToplam = $(if ($null -ne $progT) { [Math]::Round([double]$progT, 3) } else { $null }); ProgSapma = $(if ($null -ne $progT) { [double]$global:BProgModel.s } else { $null })   # 110: boşken kayda {} yazılmasın
            FlashId = $(if ($null -ne $m.Fixture) { [string]$m.Fixture.Id } else { '' }); HomeId = $(if ($null -ne $m.Fixture) { [string]$m.Fixture.HomeId } else { '' }); AwayId = $(if ($null -ne $m.Fixture) { [string]$m.Fixture.AwayId } else { '' })   # 131: hücre denetimi için
        }
        Set-BKarar $out
        $out
    }
}
# 131: iş parçacığında (kayıt okuma, analiz) hücre denetimi verisi yüklenir; arayüzde veri ilk gerektiğinde
try { if ($Shared -and $Shared.DataDir) { [void](Initialize-BHucre ([string]$Shared.DataDir) -Veri) } else { [void](Initialize-BHucre '') } } catch {}
