﻿param(
    [switch]$Konsol,
    $HostContainer,
    $OwnerWindow
)
# =====================================================================================================
#  BASKET ANALİZ MERKEZİ · 3. sürüm (veri toplama, sınırsız tarama)
#  Futbol programından (Maç Analiz Merkezi) tamamen ayrı. Kayıtlar: Belgeler\BasketAnalizMerkezi_Veri
#  Bu sürüm yalnız VERİ TOPLAR (Nesine basketbol bülteni ve skorları, Flashscore maçları, takım geçmişi, oranlar).
#  Yöntem (takım karnesi + benzer karneli takımların maçları) bu verilerle geçmiş maçlarda denenecek; tutarsa tahmin ekranları gelecek.
# =====================================================================================================
$ErrorActionPreference = 'Continue'
try { Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase } catch {}
try { Add-Type -AssemblyName System.Web.Extensions } catch {}
$script:AppDir = $PSScriptRoot
$script:DataDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'BasketAnalizMerkezi_Veri'
try { if (-not (Test-Path -LiteralPath $script:DataDir)) { New-Item -ItemType Directory -Path $script:DataDir -Force | Out-Null } } catch { $script:DataDir = $script:AppDir }
# Paket geçmişlerini ilk açılışta Belgeler klasörüne kopyalar; mevcut dosyaların üstüne yazmaz.
$script:SeedDir = Join-Path $script:AppDir 'Veri_Aktar'
$script:SeedStamp = Join-Path $script:DataDir 'basket_veri_aktarimi_v2.txt'
if ((Test-Path -LiteralPath $script:SeedDir -PathType Container) -and -not (Test-Path -LiteralPath $script:SeedStamp)) {
    $seedOk = $true
    try {
        foreach ($seed in (Get-ChildItem -LiteralPath $script:SeedDir -File -Recurse)) {
            $relative = $seed.FullName.Substring($script:SeedDir.Length).TrimStart([char[]]@(92,47))
            $destination = Join-Path $script:DataDir $relative
            $parent = Split-Path -Parent $destination
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
            if (-not (Test-Path -LiteralPath $destination)) {
                Copy-Item -LiteralPath $seed.FullName -Destination $destination -ErrorAction Stop
            } elseif ([IO.Path]::GetExtension($seed.Name) -ieq '.csv') {
                # Var olan basketbol CSV geçmişini korur, paketteki eksik satırları bir kez ekler.
                $seenRows = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
                $destReader = [IO.StreamReader]::new($destination, [Text.Encoding]::UTF8)
                $sourceReader = [IO.StreamReader]::new($seed.FullName, [Text.Encoding]::UTF8)
                try {
                    $destHeader = $destReader.ReadLine(); $sourceHeader = $sourceReader.ReadLine()
                    if ($destHeader -ceq $sourceHeader) {
                        while ($null -ne ($row = $destReader.ReadLine())) { [void]$seenRows.Add($row) }
                        $destReader.Dispose()
                        $missingRows = New-Object System.Text.StringBuilder
                        while ($null -ne ($row = $sourceReader.ReadLine())) {
                            if ($seenRows.Add($row)) { [void]$missingRows.Append($row).Append("`r`n") }
                        }
                        if ($missingRows.Length -gt 0) { [IO.File]::AppendAllText($destination, $missingRows.ToString(), [Text.UTF8Encoding]::new($false)) }
                    }
                } finally { $destReader.Dispose(); $sourceReader.Dispose() }
            }
        }
        [IO.File]::WriteAllText($script:SeedStamp, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), [Text.UTF8Encoding]::new($false))
    } catch { $seedOk = $false }
}
$script:Version = 'Basketbol · Tek maç ve Kupon · v12 + 140. düzeltme'
$script:TrC = [System.Globalization.CultureInfo]::GetCultureInfo('tr-TR')
$script:BasketShared = [hashtable]::Synchronized(@{
    DataDir = $script:DataDir; LogPath = (Join-Path $script:DataDir 'basket_log.txt')
    Lines = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
    Stop = $false; Busy = $false; Phase = ''; Req = 0; MaxReq = 0; SliceMin = 60; Delay = 1500; Deep = $true; LastRun = $null; Counts = $null
    More = $false; PauseUntil = $null; PauseMin = 0; QueueLeft = 0   # MaxReq 0 = sınır yok
})
$WorkerCode = @'
# ================== ARKA PLAN İŞÇİSİ (veri toplama) ==================
# Bu metin ayrı bir iş parçacığında çalışır; ekran donmaz. Hiçbir dosyadan satır silinmez, yalnız eklenir.
function global:Write-BLog([string]$m) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m
    try { [System.IO.File]::AppendAllText($Shared.LogPath, $line + "`r`n", (New-Object System.Text.UTF8Encoding $false)) } catch {}
    try { [void]$Shared.Lines.Add($line) } catch {}
}
function global:Invoke-BGet([string]$url, [string]$referer, [hashtable]$headers) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
    $req.Accept = '*/*'
    if ($referer) { $req.Referer = $referer }
    if ($null -ne $headers) { foreach ($k in $headers.Keys) { $req.Headers.Add($k, [string]$headers[$k]) } }
    $req.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $req.Timeout = 60000; $req.ReadWriteTimeout = 60000
    $resp = $req.GetResponse()
    try { $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8); $txt = $sr.ReadToEnd(); $sr.Close() } finally { $resp.Close() }
    return $txt
}
function global:ConvertFrom-BJson([string]$txt) {
    if (-not ('System.Web.Script.Serialization.JavaScriptSerializer' -as [type])) { Add-Type -AssemblyName System.Web.Extensions }
    $ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue
    return , $ser.DeserializeObject($txt)
}
$global:BTz = [TimeSpan]::FromHours(3)
$global:BInv = [System.Globalization.CultureInfo]::InvariantCulture
function global:Format-BTime([long]$sec) { return [DateTimeOffset]::FromUnixTimeSeconds($sec).ToOffset($global:BTz).ToString('yyyy-MM-dd HH:mm') }
function global:Get-BClean($v) { return ([string]$v -replace '[;\r\n]+', ' ').Trim().TrimStart('*').Trim() }
# CSV'ye ekleme (dosya yoksa başlıkla açılır; BOM'lu UTF-8)
function global:Add-BRows([string]$name, [string[]]$cols, $lines) {
    $p = Join-Path $Shared.DataDir $name
    if (@($lines).Count -eq 0) { return 0 }
    if (-not (Test-Path -LiteralPath $p)) { [System.IO.File]::WriteAllText($p, ($cols -join ';') + "`r`n", (New-Object System.Text.UTF8Encoding $true)) }
    $sb = New-Object System.Text.StringBuilder; foreach ($l in $lines) { [void]$sb.Append([string]$l + "`r`n") }
    [System.IO.File]::AppendAllText($p, $sb.ToString(), (New-Object System.Text.UTF8Encoding $false))
    return @($lines).Count
}
# bir dosyanın ilk sütunlarından anahtar kümesi (aynı satırı ikinci kez yazmamak için)
function global:Get-BKeys([string]$name, [int[]]$idx) {
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    $p = Join-Path $Shared.DataDir $name
    if (Test-Path -LiteralPath $p) {
        $fs = New-Object System.IO.FileStream($p, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        try {
            $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8); [void]$sr.ReadLine()   # her dosyanın ilk satırı başlık
            $mx = ($idx | Measure-Object -Maximum).Maximum
            while ($null -ne ($ln = $sr.ReadLine())) { $c = $ln.Split(';'); if ($c.Count -le $mx) { continue }; [void]$set.Add((@($idx | ForEach-Object { $c[$_] }) -join '|')) }
        } finally { $fs.Close() }
    }
    return , $set
}
function global:Add-BDone([string]$key) {
    $p = Join-Path $Shared.DataDir 'basket_h2h_yapilan.txt'
    if (-not (Test-Path -LiteralPath $p)) { [System.IO.File]::WriteAllText($p, "anahtar`r`n", (New-Object System.Text.UTF8Encoding $true)) }
    [System.IO.File]::AppendAllText($p, $key + "`r`n", (New-Object System.Text.UTF8Encoding $false))
}
function global:Save-BSample([string]$name, [string]$txt, [double]$hours) {
    try {
        $p = Join-Path $Shared.DataDir $name
        if (-not (Test-Path -LiteralPath $p) -or ((Get-Date) - (Get-Item -LiteralPath $p).LastWriteTime).TotalHours -gt $hours) { [System.IO.File]::WriteAllText($p, $txt, (New-Object System.Text.UTF8Encoding $false)) }
    } catch {}
}

# ---------- 1) NESİNE BÜLTENİ: basketbol maçlarının BÜTÜN bahisleri ----------
# Bülten: sg.EA = maçlar (C kod, ESD başlama ms, HN / AN takımlar, LC lig, TYPE spor, MA bahisler: MTID, SOV çizgi, OCA sonuçlar N / O).
# Spor kodu ilk açılışta bülten içinden kesinleştirilir (basketbol ligi adları ve oranların yapısı); bulunamazsa 2 kullanılır ve günlüğe yazılır.
$global:BNesUrl = 'https://cdnbulten.nesine.com/api/bulten/getprebultenfull'
function global:Get-BNesType($ea, $lg) {
    $cnt = @{}; $bk = @{}
    foreach ($e in $ea) {
        if (-not ($e -is [System.Collections.IDictionary])) { continue }
        $t = [string]$e['TYPE']; if (-not $cnt.ContainsKey($t)) { $cnt[$t] = 0; $bk[$t] = 0 }; $cnt[$t]++
        $ln = ''; if ($e.ContainsKey('LC') -and $lg.ContainsKey([string]$e['LC'])) { $ln = [string]$lg[[string]$e['LC']] }
        if ($ln -match '(?i)basket|nba|euroleague|eurocup|bsl|acb|basketbol|fiba|wnba|ncaa|vtb|lnb|bbl|aba') { $bk[$t]++ }
    }
    Write-BLog ('Bültendeki spor kodları: ' + ((@($cnt.Keys | Sort-Object) | ForEach-Object { $_ + '=' + $cnt[$_] + ' maç (basketbol adlı lig ' + $bk[$_] + ')' }) -join ' · '))
    $best = $null; foreach ($t in $bk.Keys) { if ($t -ne '1' -and $bk[$t] -gt 0 -and ($null -eq $best -or $bk[$t] -gt $bk[$best])) { $best = $t } }
    if ($null -eq $best) { $best = '2' }
    return $best
}
function global:Save-BNesine {
    $txt = Invoke-BGet $global:BNesUrl 'https://www.nesine.com/' $null
    $raw = ConvertFrom-BJson $txt
    $sg = $raw['sg']; $ea = @($sg['EA'])
    $lg = @{}; try { foreach ($l in @($sg['LA'])) { if ($l -is [System.Collections.IDictionary] -and $l.ContainsKey('LID')) { $lg[[string]$l['LID']] = [string]$l['N'] } } } catch {}
    if (-not $global:BNesTypeSet) { $global:BNesType = Get-BNesType $ea $lg; $global:BNesTypeSet = $true; Write-BLog ('Basketbol spor kodu: ' + $global:BNesType) }
    $done = Get-BKeys 'basket_nesine_oranlar.csv' @(0, 2)
    $now = [DateTimeOffset]::UtcNow; $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm'
    $rows = New-Object System.Collections.ArrayList; $n = 0; $smp = $null
    foreach ($e in $ea) {
        if (-not ($e -is [System.Collections.IDictionary]) -or [string]$e['TYPE'] -ne $global:BNesType) { continue }
        if (-not $e.ContainsKey('C') -or -not $e.ContainsKey('ESD')) { continue }
        $n++
        if ($null -eq $smp) { $smp = New-Object System.Collections.ArrayList }; if ($smp.Count -lt 5) { [void]$smp.Add($e) }
        $ko = [DateTimeOffset]::FromUnixTimeMilliseconds([long]$e['ESD'])
        if ($ko -lt $now) { continue }
        $asama = $(if (($ko - $now).TotalHours -le 3) { 'son' } else { 'ilk' })
        $code = [string]$e['C']
        $ma = @(foreach ($m in @($e['MA'])) {
            if (-not ($m -is [System.Collections.IDictionary])) { continue }
            $sov = ''; if ($m.ContainsKey('SOV')) { $sov = [string]$m['SOV'] }
            # 133: periyot sayı Alt / Üst (MTID 659): periyot SOV2'de, çizgi SOV3'te; SOV hep 0 geliyordu (çizgi kaybolurdu). Yazılan: periyot*1000 + çizgi (1043.5 = 1. periyot 43,5)
            if ([string]$m['MTID'] -eq '659' -and $m.ContainsKey('SOV2') -and $m.ContainsKey('SOV3')) { try { $sov = ([double]$m['SOV2'] * 1000 + [double]$m['SOV3']).ToString([System.Globalization.CultureInfo]::InvariantCulture) } catch {} }
            $oc = @(foreach ($o in @($m['OCA'])) { if ($o -is [System.Collections.IDictionary]) { [string]$o['N'] + '=' + [string]$o['O'] } }) -join '/'
            [string]$m['MTID'] + ':' + $sov + ':' + $oc
        }) -join '|'
        # 87. düzeltme: başlamasına 3 saat kalan maçın oranı HER turda tazelenir (bülten tek istek, ek yük yok).
        # Oran değişmediyse yeni satır yazılmaz (bir program açılışı içinde); okuyan herkes bir kodun EN SON satırını kullanır.
        if ($asama -eq 'son') {
            if ($null -eq $global:BNesSonMa) { $global:BNesSonMa = @{} }
            if ($done.Contains($code + '|son') -and [string]$global:BNesSonMa[$code] -eq $ma) { continue }
            $global:BNesSonMa[$code] = $ma
        }
        elseif ($done.Contains($code + '|' + $asama)) { continue }
        $ln = ''; if ($e.ContainsKey('LC') -and $lg.ContainsKey([string]$e['LC'])) { $ln = $lg[[string]$e['LC']] }
        $mbs = ''; foreach ($k in @('MBS', 'MB')) { if ($e.ContainsKey($k)) { $mbs = [string]$e[$k]; break } }
        [void]$rows.Add((@($code, [string]$ko.ToUnixTimeSeconds(), $asama, $stamp, (Get-BClean $ln), (Get-BClean $e['HN']), (Get-BClean $e['AN']), $mbs, $ma) -join ';'))
        [void]$done.Add($code + '|' + $asama)
    }
    if ($null -ne $smp) { try { if (-not ('System.Web.Script.Serialization.JavaScriptSerializer' -as [type])) { Add-Type -AssemblyName System.Web.Extensions }; $ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $ser.MaxJsonLength = [int]::MaxValue; Save-BSample 'basket_nesine_ornek.json' ($ser.Serialize($smp)) 20 } catch {} }
    $w = Add-BRows 'basket_nesine_oranlar.csv' @('kod', 'ko', 'asama', 'kayit', 'lig', 'ev', 'dep', 'mbs', 'bahisler') $rows
    Write-BLog ('Bülten: ' + $n + ' basketbol maçı, ' + $w + ' yeni oran satırı')
    return $w
}

# ---------- 2) NESİNE CANLI SKOR: son 7 günün biten basketbol maçları (çeyrek skorları ham olarak) ----------
function global:Save-BNesineDone([int]$days) {
    $have = Get-BKeys 'basket_nesine_sonuclar.csv' @(0)
    $tot = 0; $first = $true
    # 83. düzeltme: d=0 (bugün) da sorulur. NBA maçları TR sabahı bittiği için "bugün" tarihinde kalıyordu ve skorları ertesi güne kadar gelmiyordu.
    for ($d = 0; $d -le $days; $d++) {
        if ($Shared.Stop) { break }
        $date = [DateTimeOffset]::UtcNow.ToOffset($global:BTz).AddDays(-$d).ToString('yyyy-MM-dd')
        $st = if ($global:BNesType) { $global:BNesType } else { '2' }
        $txt = $null
        try { $txt = Invoke-BGet ('https://ls.nesine.com/api/v2/LiveScore/GetUnliveMatches?sportType=' + $st + '&date=' + $date) 'https://www.nesine.com/iddaa/canli-skor/basketbol' @{ Origin = 'https://www.nesine.com' } }
        catch { Write-BLog ('Canlı skor ' + $date + ' alınamadı: ' + $_.Exception.Message); continue }
        if ($first) { Save-BSample 'basket_nesine_sonuc_ornek.json' ($txt.Substring(0, [Math]::Min(60000, $txt.Length))) 20; $first = $false }
        $o = ConvertFrom-BJson $txt
        $rows = New-Object System.Collections.ArrayList
        foreach ($m in @($o['d'])) {
            if (-not ($m -is [System.Collections.IDictionary])) { continue }
            $code = [string]$m['C']; if (-not $code -or $code -eq '0' -or $have.Contains($code)) { continue }
            $fin = ([string]$m['S'] -eq '5') -or (@('MS', 'UZT') -contains [string]$m['ST'])
            if (-not $fin) { continue }
            $ko = $null
            try { $ko = [DateTimeOffset]::Parse([string]$m['matchDate'], $global:BInv).ToUnixTimeSeconds() } catch {}
            if ($null -eq $ko) { try { $ko = [long]([long]$m['MDE'] / 1000) } catch {} }
            if ($null -eq $ko) { continue }
            $es = @(); $best = $null
            foreach ($e in @($m['ES'])) {
                if (-not ($e -is [System.Collections.IDictionary])) { continue }
                $t = -1; try { $t = [int]$e['T'] } catch {}
                $es += ([string]$t + ':' + [string]$e['H'] + '-' + [string]$e['A'])
                if ($null -eq $best -or $t -gt $best[0]) { $best = @($t, [string]$e['H'], [string]$e['A']) }
            }
            $hs = ''; $as = ''
            foreach ($k in @(@('HS', 'AS'), @('HSC', 'ASC'), @('H', 'A'))) { if ($m.ContainsKey($k[0]) -and $m.ContainsKey($k[1]) -and [string]$m[$k[0]] -match '^\d+$') { $hs = [string]$m[$k[0]]; $as = [string]$m[$k[1]]; break } }
            if (-not $hs -and $null -ne $best) { $hs = $best[1]; $as = $best[2] }
            [void]$rows.Add((@($code, [string]$ko, (Format-BTime $ko), (Get-BClean $m['L']), (Get-BClean $m['HT']), (Get-BClean $m['AT']), [string]$m['ST'], $hs, $as, ($es -join '|'), (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';'))
            [void]$have.Add($code)
        }
        $tot += (Add-BRows 'basket_nesine_sonuclar.csv' @('kod', 'ko', 'zaman', 'lig', 'ev', 'dep', 'durum', 'skor_ev', 'skor_dep', 'periyotlar', 'kayit') $rows)
    }
    Write-BLog ('Canlı skor: ' + $tot + ' yeni biten maç')
    return $tot
}

# ---------- 3) FLASHSCORE ----------
$global:BFlashSign = 'SW9D1eZo'
$global:BFlashSport = 3   # basketbol
function global:Invoke-BFlash([string]$url) {
    $dl = [int]$Shared.Delay; if ($dl -gt 0) { Start-Sleep -Milliseconds $dl }
    $Shared.Req++
    return (Invoke-BGet $url 'https://www.flashscore.com/' @{ 'x-fsign' = $global:BFlashSign; Origin = 'https://www.flashscore.com' })
}
function global:ConvertFrom-BFeed([string]$txt) {
    $list = New-Object System.Collections.ArrayList
    $fs = [char]0xAC; $kv = [char]0xF7
    foreach ($sec in $txt.Split('~')) {
        $h = @{}
        foreach ($part in $sec.Split($fs)) { $i = $part.IndexOf($kv); if ($i -gt 0) { $h[$part.Substring(0, $i)] = $part.Substring($i + 1) } }
        if ($h.Count -gt 0) { [void]$list.Add($h) }
    }
    return , $list
}
# günün listesi: lig başlığı (ZA "ÜLKE: Lig") ardından maçlar (AA kimlik, AD başlama, AE / AF takımlar, PX / PY takım kimlikleri, AB durum 3 = bitti, AG / AH skor, B* çeyrekler)
function global:Get-BFlashDay([int]$off) {
    $txt = Invoke-BFlash ('https://www.flashscore.com/x/feed/f_' + $global:BFlashSport + '_' + $off + '_2_en_1')
    if ($off -eq 0) { Save-BSample 'basket_flash_gun_ornek.txt' ($txt.Substring(0, [Math]::Min(60000, $txt.Length))) 20 }
    $list = New-Object System.Collections.ArrayList; $lig = ''; $ulke = ''
    foreach ($h in (ConvertFrom-BFeed $txt)) {
        if ($h.ContainsKey('ZA')) { $lig = [string]$h['ZA']; $ulke = $(if ($h.ContainsKey('ZY')) { [string]$h['ZY'] } else { '' }) }
        if ($h.ContainsKey('AA') -and $h.ContainsKey('AE') -and $h.ContainsKey('AF')) { $h['_lig'] = $lig; $h['_ulke'] = $ulke; [void]$list.Add($h) }
    }
    return , $list
}
function global:Save-BFlashDays([int[]]$offs) {
    $have = Get-BKeys 'basket_flash_maclar.csv' @(0)
    $up = New-Object System.Collections.ArrayList; $upSeen = @{}; $tot = 0
    foreach ($off in $offs) {
        if ($Shared.Stop) { break }
        $evs = $null; try { $evs = Get-BFlashDay $off } catch { Write-BLog ('Flashscore gün ' + $off + ' alınamadı: ' + $_.Exception.Message); continue }
        $rows = New-Object System.Collections.ArrayList
        foreach ($h in $evs) {
            $id = [string]$h['AA']; $st = [string]$h['AB']
            if ($st -eq '1') { if (-not $upSeen.ContainsKey($id)) { $upSeen[$id] = 1; [void]$up.Add($h) }; continue }
            if ($st -ne '3' -or $have.Contains($id)) { continue }
            $ko = 0L; try { $ko = [long]$h['AD'] } catch {}
            $per = @(foreach ($k in @($h.Keys | Where-Object { $_ -match '^B[A-Z]$' } | Sort-Object)) { $k + '=' + [string]$h[$k] }) -join ','
            [void]$rows.Add((@($id, $(if ($ko -gt 0) { Format-BTime $ko } else { '' }), (Get-BClean $h['_lig']), (Get-BClean $h['_ulke']), [string]$h['PX'], [string]$h['PY'], (Get-BClean $h['AE']), (Get-BClean $h['AF']), [string]$h['AG'], [string]$h['AH'], $per, (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';'))
            [void]$have.Add($id)
        }
        $tot += (Add-BRows 'basket_flash_maclar.csv' @('id', 'zaman', 'lig', 'ulke', 'ev_id', 'dep_id', 'ev', 'dep', 'skor_ev', 'skor_dep', 'ceyrekler', 'kayit') $rows)
    }
    Write-BLog ('Flashscore günlük listeler: ' + $tot + ' yeni biten maç, ' + $up.Count + ' oynanacak maç')
    return , $up
}
# iki takımın geçmiş maçları (df_hh): KP maç, KC zaman, KF lig, KH ülke, UQ / UO ev / dep kimliği, KJ / KK adlar, KU / KT skor (KX / KY normal süre)
function global:Save-BH2h([string]$eid) {
    $txt = Invoke-BFlash ('https://www.flashscore.com/x/feed/df_hh_1_' + $eid)
    Save-BSample 'basket_flash_gecmis_ornek.txt' ($txt.Substring(0, [Math]::Min(40000, $txt.Length))) 20
    if ($null -eq $global:BResSeen) { $global:BResSeen = Get-BKeys 'basket_mac_sonuclari.csv' @(0) }
    $rows = New-Object System.Collections.ArrayList; $newIds = New-Object System.Collections.ArrayList
    foreach ($r in (ConvertFrom-BFeed $txt)) {
        if (-not $r.ContainsKey('KP') -or -not $r.ContainsKey('KU') -or -not $r.ContainsKey('KT')) { continue }
        $mid = [string]$r['KP']; if (-not $mid -or $global:BResSeen.Contains($mid)) { continue }
        if ([string]$r['KU'] -notmatch '^\d+$' -or [string]$r['KT'] -notmatch '^\d+$') { continue }
        $kc = 0L; try { $kc = [long]$r['KC'] } catch {}
        $nx = ''; $ny = ''; if ($r.ContainsKey('KX') -and $r.ContainsKey('KY')) { $nx = [string]$r['KX']; $ny = [string]$r['KY'] }
        [void]$rows.Add((@($mid, $(if ($kc -gt 0) { Format-BTime $kc } else { '' }), [string]$r['UQ'], [string]$r['UO'], (Get-BClean $r['KJ']), (Get-BClean $r['KK']), [string]$r['KU'], [string]$r['KT'], $nx, $ny, (Get-BClean $r['KF']), (Get-BClean $r['KH']), (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';'))
        [void]$global:BResSeen.Add($mid)
        [void]$newIds.Add(@($mid, [string]$r['UQ'], [string]$r['UO'], [string]$kc))
    }
    [void](Add-BRows 'basket_mac_sonuclari.csv' @('mac_id', 'zaman', 'ev_id', 'dep_id', 'ev', 'dep', 'skor_ev', 'skor_dep', 'normal_ev', 'normal_dep', 'lig', 'ulke', 'kayit') $rows)
    # geçmişe doğru tarama kuyruğu: yeni bulunan maçlar (oranları ve onların geçmişi sonra alınır)
    $q = @(foreach ($x in $newIds) { $x -join ';' })
    if ($q.Count -gt 0) { [System.IO.File]::AppendAllText((Join-Path $Shared.DataDir 'basket_kuyruk.txt'), (($q -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding $false)) }
    return $rows.Count
}
# oranlar: bahis türü × kapsam × çizgi × seçim için bürolar arası ORTANCA (median) oran ve açılış
function global:Get-BMedian($a) { $s = @($a | Sort-Object); if ($s.Count -eq 0) { return $null }; $m = [int][Math]::Floor($s.Count / 2); if ($s.Count % 2 -eq 1) { return [double]$s[$m] }; return ([double]$s[$m - 1] + [double]$s[$m]) / 2.0 }
function global:Save-BOdds([string]$eid, [string]$asama, [string]$homeId, [string]$awayId) {
    $txt = Invoke-BFlash ('https://global.ds.lsapp.eu/odds/pq_graphql?_hash=oce&eventId=' + $eid + '&projectId=2&geoIpCode=TR&geoIpSubdivisionCode=TR34')
    Save-BSample 'basket_flash_oran_ornek.json' $txt 20
    $j = ConvertFrom-BJson $txt
    $fo = $null; try { $fo = $j['data']['findOddsByEventId'] } catch {}
    $acc = @{}; $nb = @{}
    # 3. sürüm: oranlardaki takım kimliği (eventParticipantId) maça özel; ev / deplasman eşlemesi maç sonucu (HOME_AWAY / HOME_DRAW_AWAY)
    # bahsindeki sıradan: ilk takım ev, ikinci deplasman. Handikapta her çizgi tek takımlı geldiği için önceden hepsi "EV?" yazılıyordu.
    $pH = ''; $pA = ''
    if ($null -ne $fo) {
        foreach ($it in @($fo['odds'])) {
            if (-not ($it -is [System.Collections.IDictionary])) { continue }
            if (@('HOME_AWAY', 'HOME_DRAW_AWAY') -notcontains [string]$it['bettingType']) { continue }
            $ps = @(@($it['odds']) | Where-Object { $_ -is [System.Collections.IDictionary] -and [string]$_['eventParticipantId'] } | ForEach-Object { [string]$_['eventParticipantId'] })
            if ($ps.Count -ge 2 -and $ps[0] -ne $ps[1]) { $pH = $ps[0]; $pA = $ps[1]; break }
        }
    }
    if ($null -ne $fo) {
        foreach ($it in @($fo['odds'])) {
            if (-not ($it -is [System.Collections.IDictionary])) { continue }
            $bt = [string]$it['bettingType']; $sc = [string]$it['bettingScope']; if (-not $sc) { $sc = 'FULL_TIME' }
            $items = @($it['odds'] | Where-Object { $_ -is [System.Collections.IDictionary] })
            $pos = 0; $lastLine = $null
            foreach ($o in $items) {
                $v = 0.0; if (-not [double]::TryParse([string]$o['value'], [System.Globalization.NumberStyles]::Float, $global:BInv, [ref]$v) -or $v -le 1.0) { continue }
                $op = 0.0; [void][double]::TryParse([string]$o['opening'], [System.Globalization.NumberStyles]::Float, $global:BInv, [ref]$op)
                $line = ''; $hc = $o['handicap']; if ($hc -is [System.Collections.IDictionary]) { $line = [string]$hc['value'] }
                if ($line -ne $lastLine) { $pos = 0; $lastLine = $line }
                $sel = [string]$o['selection']
                if (-not $sel) {
                    $partId = [string]$o['eventParticipantId']
                    if ($partId -and $pH -and $partId -eq $pH) { $sel = 'EV' } elseif ($partId -and $pA -and $partId -eq $pA) { $sel = 'DEP' }
                    elseif ($partId -and $homeId -and $partId -eq $homeId) { $sel = 'EV' } elseif ($partId -and $awayId -and $partId -eq $awayId) { $sel = 'DEP' }
                    elseif ($partId) { $sel = $(if ($pos -eq 0) { 'EV?' } elseif ($pos -eq 1) { 'DEP?' } else { 'X?' }) }
                    else { $sel = $(if ($bt -eq 'HOME_DRAW_AWAY' -and $pos -eq 2) { 'X' } else { 'S' + $pos }) }
                }
                if ([string]$o['winner']) { $sel = [string]$o['winner'] }
                $pos++
                $k = $bt + ';' + $sc + ';' + $line + ';' + $sel
                if (-not $acc.ContainsKey($k)) { $acc[$k] = @{ v = (New-Object System.Collections.ArrayList); o = (New-Object System.Collections.ArrayList); r = [string]$o['result'] } }
                [void]$acc[$k].v.Add($v); if ($op -gt 1.0) { [void]$acc[$k].o.Add($op) }
                $nb[[string]$it['bookmakerId']] = 1
            }
        }
    }
    # maç başına TEK satır (dosya küçük kalsın): tur@kapsam=çizgi:seçim:oran:açılış:büro:sonuç ... | sonraki tür
    # Açılış değeri geldiğinde güncel oranla aynı olsa da saklanır.
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm'
    $grp = [ordered]@{}
    foreach ($k in ($acc.Keys | Sort-Object)) {
        $p4 = $k.Split(';'); $g = $p4[0] + '@' + $p4[1]
        $a = $acc[$k]; $mv = Get-BMedian $a.v; $mo = Get-BMedian $a.o
        $vs = $mv.ToString('0.00', $global:BInv); $os = $(if ($null -ne $mo) { $mo.ToString('0.00', $global:BInv) } else { '' })
        $rs = [string]$a.r; if ($rs -eq 'NONE') { $rs = '' }
        if (-not $grp.Contains($g)) { $grp[$g] = New-Object System.Collections.ArrayList }
        [void]$grp[$g].Add((@($p4[2], $p4[3], $vs, $os, [string]$a.v.Count, $rs) -join ':'))
    }
    $data = $(if ($grp.Count -eq 0) { 'YOK' } else { (@(foreach ($g in $grp.Keys) { $g + '=' + ($grp[$g] -join ' ') }) -join '|') })
    [void](Add-BRows 'basket_flash_oranlar.csv' @('id', 'asama', 'kayit', 'oranlar') @((@($eid, $asama, $stamp, $data) -join ';')))
    return $acc.Count
}

# ---------- 79. düzeltme: BİTEN MAÇLARIN İSTATİSTİĞİ (tempo / sayı verimliliği / üçlük denemesi için) ----------
# Flashscore maç istatistiği (df_st): SE bölüm (Match / çeyrekler), SG ad, SH ev, SI deplasman. Yalnız maçın tamamı bölümü saklanır.
# Satır: id;kayit;istatistik  ·  istatistik = ad=ev/dep|ad=ev/dep ...  (istatistik yoksa YOK; tekrar sorulmaz)
function global:Save-BStats([string]$eid) {
    $txt = Invoke-BFlash ('https://www.flashscore.com/x/feed/df_st_1_' + $eid)
    Save-BSample 'basket_flash_ist_ornek.txt' ($txt.Substring(0, [Math]::Min(30000, $txt.Length))) 24
    $sections = [ordered]@{}; $sec = ''
    $clean = { param($v) (([string]$v) -replace '[;|=/\r\n]', ' ').Trim() }
    foreach ($r in (ConvertFrom-BFeed $txt)) {
        if ($r.ContainsKey('SE')) { $sec = ([string]$r['SE']).Trim() }
        $name = ([string]$r['SG']).Trim()
        if (-not $name -or -not $r.ContainsKey('SH') -or -not $r.ContainsKey('SI')) { continue }
        if (-not $sections.Contains($sec)) { $sections[$sec] = New-Object System.Collections.ArrayList }
        [void]$sections[$sec].Add((& $clean $name) + '=' + (& $clean $r['SH']) + '/' + (& $clean $r['SI']))
    }
    $pick = $null
    foreach ($k in $sections.Keys) { if ($k -match '^(Match|Maç)$') { $pick = $sections[$k]; break } }
    if ($null -eq $pick -and $sections.Count -gt 0) { $pick = @($sections.Values)[0] }
    $data = if ($null -eq $pick -or $pick.Count -eq 0) { 'YOK' } else { $pick -join '|' }
    [void](Add-BRows 'basket_flash_istatistik.csv' @('id', 'kayit', 'istatistik') @((@($eid, (Get-Date -Format 'yyyy-MM-dd HH:mm'), $data) -join ';')))
    return ($data -ne 'YOK')
}
# Sıra: 15 Eylül'den bu yana biten maçlar, en yeniden eskiye (oranı alınmış maçlar ve takımlarının önceki maçları).
function global:Invoke-BStatsRun {
    $Shared.Busy = $true; $Shared.Phase = 'maç istatistikleri'; $Shared.Req = 0
    try {
        Write-BLog '— maç istatistikleri toplanıyor (en yeni maçtan geriye) —'
        $done = Get-BKeys 'basket_flash_istatistik.csv' @(0)
        $when = @{}
        foreach ($name in @('basket_flash_maclar.csv', 'basket_mac_sonuclari.csv')) {
            $p = Join-Path $Shared.DataDir $name
            if (-not (Test-Path -LiteralPath $p)) { continue }
            $fs = New-Object System.IO.FileStream($p, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            try {
                $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8); [void]$sr.ReadLine()
                while ($null -ne ($ln = $sr.ReadLine())) {
                    $c = $ln.Split(';'); if ($c.Count -lt 2) { continue }
                    $id = $c[0]; $z = $c[1]
                    if (-not $id -or $z -lt '2026-09-15' -or $done.Contains($id) -or $when.ContainsKey($id)) { continue }
                    $when[$id] = $z
                }
            } finally { $fs.Close() }
        }
        $now = (Get-Date).AddHours(-3).ToString('yyyy-MM-dd HH:mm')
        $todo = @($when.Keys | Where-Object { $when[$_] -le $now } | Sort-Object { $when[$_] } -Descending)
        $left = $todo.Count; $Shared.QueueLeft = $left; $got = 0; $empty = 0; $fail = 0; $n = 0
        Write-BLog ('istatistik kuyruğu: ' + $left + ' maç')
        foreach ($id in $todo) {
            if ($Shared.Stop) { Write-BLog 'istatistik toplama durduruldu (kaldığı yerden devam eder)'; break }
            try {
                if (Save-BStats $id) { $got++ } else { $empty++ }
                $fail = 0
            } catch {
                $fail++; Write-BLog ('istatistik alınamadı ' + $id + ': ' + $_.Exception.Message)
                if ($fail -ge 5) { Write-BLog 'üst üste 5 hata: Flashscore cevap vermiyor, istatistik toplama durdu. Sonra yeniden dene.'; break }
                continue
            }
            $n++; $left--; $Shared.QueueLeft = $left
            if ($n -eq 40 -and $got -eq 0) { Write-BLog 'ilk 40 maçta hiç istatistik gelmedi: Flashscore bu maçlar için istatistik vermiyor olabilir, durdu. basket_flash_ist_ornek.txt dosyasını gönder.'; break }
            if ($n % 100 -eq 0) { Write-BLog ('istatistik: ' + $n + ' maç (' + $got + ' dolu, ' + $empty + ' boş) · kuyrukta ' + $left) }
        }
        Write-BLog ('— istatistik bitti: ' + $got + ' dolu, ' + $empty + ' boş · ' + $Shared.Req + ' Flashscore isteği —')
    } catch { Write-BLog ('İstatistik hatası: ' + $_.Exception.Message) }
    finally { $Shared.Busy = $false; $Shared.Phase = ''; $Shared.QueueLeft = 0 }
}

# ---------- SAYAÇLAR ----------
function global:Get-BCount([string]$name, [int]$col) {
    $p = Join-Path $Shared.DataDir $name; if (-not (Test-Path -LiteralPath $p)) { return 0 }
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    $fs = New-Object System.IO.FileStream($p, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try { $sr = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8); [void]$sr.ReadLine(); while ($null -ne ($ln = $sr.ReadLine())) { $i = $ln.IndexOf(';'); [void]$set.Add($(if ($col -eq 0 -and $i -gt 0) { $ln.Substring(0, $i) } else { $ln.Split(';')[$col] })) } } finally { $fs.Close() }
    return $set.Count
}
function global:Update-BCounts {
    $c = @{}
    $c['nes'] = Get-BCount 'basket_nesine_oranlar.csv' 0
    $c['nesbit'] = Get-BCount 'basket_nesine_sonuclar.csv' 0
    $c['flash'] = Get-BCount 'basket_flash_maclar.csv' 0
    $c['arsiv'] = Get-BCount 'basket_mac_sonuclari.csv' 0
    $od = Get-BKeys 'basket_flash_oranlar.csv' @(0); $c['oran'] = $od.Count
    $qp = Join-Path $Shared.DataDir 'basket_kuyruk.txt'; $qn = 0
    if (Test-Path -LiteralPath $qp) { $qs = New-Object 'System.Collections.Generic.HashSet[string]'; foreach ($ln in [System.IO.File]::ReadAllLines($qp)) { $i = $ln.IndexOf(';'); if ($i -gt 0) { $k = $ln.Substring(0, $i); if (-not $od.Contains($k)) { [void]$qs.Add($k) } } }; $qn = $qs.Count }
    $c['kuyruk'] = $qn
    $Shared.Counts = $c
}

# ---------- BİR TUR ----------
# MaxReq 0 = sınırsız
function global:Test-BLimit { return ([int]$Shared.MaxReq -gt 0 -and [int]$Shared.Req -ge [int]$Shared.MaxReq) }
# ---------- 130. düzeltme: SİTE TAKIM MAÇLARI (periyot / takım karnesi için) ----------
# Sitenin maç başlığı (HeadToHead/{kod}/Header: iki takımın kimliği) ve takımın maç listesi (Team/{id}/Matches: 2025 başından beri her maç, skor satırlarıyla).
# Skor satırları ham saklanır (TY/OBI=ev-dep): çeyreklerin hangi satır olduğu ilk örnekle kesinleşir (basket_nesine_takim_ornek.json). Takım 2 günde bir yenilenir.
# Ayrıca oyuncu / hoca için örnekler: sitenin maç kadrosu (Lineups) ve Flashscore'un maç kadrosu (df_li) birer kez kaydedilir.
function global:Save-BTakimPeriyot($up) {
    $dir = $Shared.DataDir; $inv = $global:BInv; $u8 = [System.Text.Encoding]::UTF8
    $api = 'https://apistats.nesine.com/api/v3/'; $ref = 'https://www.nesine.com/'
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    # 1) son 14 gün ve önümüzdeki 2 günün site maç kodları
    $codes = @{}
    foreach ($fn in @('basket_nesine_oranlar.csv', 'basket_nesine_sonuclar.csv')) {
        $p = Join-Path $dir $fn; if (-not (Test-Path -LiteralPath $p)) { continue }
        $fs = New-Object System.IO.FileStream($p, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        try { $sr = New-Object System.IO.StreamReader($fs, $u8); [void]$sr.ReadLine()
            while ($null -ne ($ln = $sr.ReadLine())) { $c = $ln.Split(';'); if ($c.Count -lt 2 -or $c[0] -notmatch '^\d+$') { continue }; $ko = 0L; if ([long]::TryParse($c[1], [ref]$ko) -and $ko -ge $now - 14 * 86400 -and $ko -le $now + 2 * 86400) { $codes[$c[0]] = $ko } }
        } finally { $fs.Close() }
    }
    $mapDone = Get-BKeys 'basket_nesine_takim.csv' @(0)
    $rows = New-Object System.Collections.ArrayList; $nh = 0; $sampleKod = ''
    foreach ($k in @($codes.Keys | Sort-Object { $codes[$_] } -Descending)) {
        if ($Shared.Stop -or $nh -ge 400) { break }
        if ($mapDone.Contains($k)) { continue }
        $nh++
        try {
            $txt = Invoke-BGet ($api + 'HeadToHead/' + $k + '/Header') $ref $null
            if ($nh -eq 1) { Save-BSample 'basket_nesine_header_ornek.json' $txt 72 }
            $d = (ConvertFrom-BJson $txt)['d']; $ht = $null; $at = $null; $tour = $null
            if ($d -is [System.Collections.IDictionary]) { $ht = @($d['HT'])[0]; $at = @($d['AT'])[0]; $tour = $d['TOUR'] }
            $hid = ''; $aid = ''; $hn = ''; $an = ''; $lg = ''; $sea = ''
            if ($ht -is [System.Collections.IDictionary]) { $hid = [string]$ht['TID']; $hn = Get-BClean $ht['N'] }
            if ($at -is [System.Collections.IDictionary]) { $aid = [string]$at['TID']; $an = Get-BClean $at['N'] }
            if ($tour -is [System.Collections.IDictionary]) { $lg = [string]$tour['TID']; $sea = Get-BClean $tour['SEA'] }
            [void]$rows.Add((@($k, $hid, $aid, $hn, $an, $lg, $sea, (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';'))
            [void]$mapDone.Add($k); if (-not $sampleKod -and $hid) { $sampleKod = $k }
        } catch { Write-BLog ('site maç başlığı alınamadı ' + $k + ': ' + $_.Exception.Message) }
        Start-Sleep -Milliseconds 300
    }
    [void](Add-BRows 'basket_nesine_takim.csv' @('kod', 'ev_tid', 'dep_tid', 'ev', 'dep', 'lig_tid', 'sezon', 'kayit') $rows)
    # örnek: sitenin maç kadrosu (oyuncu / hoca bilgisi var mı)
    if ($sampleKod) { try { Save-BSample 'basket_nesine_kadro_ornek.json' (Invoke-BGet ($api + 'HeadToHead/' + $sampleKod + '/Lineups') $ref $null) 72 } catch {} }
    # örnek: Flashscore maç kadrosu (oyuncu / hoca)
    foreach ($h in @($up)) { $id = [string]$h['AA']; if ($id) { try { Save-BSample 'basket_flash_kadro_ornek.txt' (Invoke-BFlash ('https://www.flashscore.com/x/feed/df_li_1_' + $id)) 72 } catch {}; break } }
    # 2) takımlar (eşlemedeki bütün takımlar; en son maçı olan önce), 2 günde bir
    $tm = @{}
    $p = Join-Path $dir 'basket_nesine_takim.csv'
    if (Test-Path -LiteralPath $p) { foreach ($ln in [System.IO.File]::ReadAllLines($p, $u8)) { $c = $ln.Split(';'); if ($c.Count -ge 3 -and $c[0] -match '^\d+$') { $ko = $(if ($codes.ContainsKey($c[0])) { $codes[$c[0]] } else { 0L }); foreach ($t in @($c[1], $c[2])) { if ($t -match '^\d+$' -and (-not $tm.ContainsKey($t) -or $tm[$t] -lt $ko)) { $tm[$t] = $ko } } } } }
    $last = @{}; $yp = Join-Path $dir 'basket_takim_yapilan.csv'
    if (Test-Path -LiteralPath $yp) { foreach ($ln in [System.IO.File]::ReadAllLines($yp, $u8)) { $c = $ln.Split(';'); if ($c.Count -ge 2 -and $c[0] -match '^\d+$') { $last[$c[0]] = $c[1] } } }
    $lim = (Get-Date).AddDays(-2).ToString('yyyy-MM-dd HH:mm', $inv)
    $todo = @($tm.Keys | Where-Object { -not $last.ContainsKey($_) -or [string]::CompareOrdinal([string]$last[$_], $lim) -lt 0 } | Sort-Object { $tm[$_] } -Descending)
    $seen = Get-BKeys 'basket_takim_maclari.csv' @(0)
    $nt = 0; $nm = 0; $nq = 0; $done = New-Object System.Collections.ArrayList; $fail = 0
    $enUS = [System.Globalization.CultureInfo]::GetCultureInfo('en-US')
    foreach ($t in $todo) {
        if ($Shared.Stop -or $nt -ge 300) { break }
        $nt++
        $txt = $null
        try { $txt = Invoke-BGet ($api + 'Team/' + $t + '/Matches') $ref $null; $fail = 0 } catch { $fail++; Write-BLog ('site takım maçları alınamadı ' + $t + ': ' + $_.Exception.Message); if ($fail -ge 5) { Write-BLog 'site takım maçları: üst üste 5 hata, bu turda bırakıldı'; break }; continue }
        if ($nt -eq 1) { Save-BSample 'basket_nesine_takim_ornek.json' $txt 72 }
        $mr = New-Object System.Collections.ArrayList
        try {
            $j = ConvertFrom-BJson $txt; $d = $j['d']
            foreach ($tml in @($d['TML'])) { if (-not ($tml -is [System.Collections.IDictionary])) { continue }
                foreach ($bl in @($tml['TT'])) { if (-not ($bl -is [System.Collections.IDictionary]) -or [string]$bl['FT'] -ne '5') { continue }
                    foreach ($tms in @($bl['TMS'])) { if (-not ($tms -is [System.Collections.IDictionary])) { continue }
                        foreach ($m in @($tms['ML'])) {
                            if (-not ($m -is [System.Collections.IDictionary])) { continue }
                            $mid = [string]$m['MID']; if (-not $mid -or $seen.Contains($mid)) { continue }
                            $ht = $m['HT']; $at = $m['AT']; $lg = $m['LG']
                            if (-not ($ht -is [System.Collections.IDictionary]) -or -not ($at -is [System.Collections.IDictionary])) { continue }
                            $sc = @(foreach ($s in @($m['SC'])) { if ($s -is [System.Collections.IDictionary]) { [string]$s['TY'] + '/' + [string]$s['OBI'] + '=' + [string]$s['HTS'] + '-' + [string]$s['ATS'] } }) -join '|'
                            if (-not $sc) { continue }   # oynanmamış
                            $dt = [DateTime]::MinValue; if (-not [DateTime]::TryParse([string]$m['MD'], $enUS, [System.Globalization.DateTimeStyles]::AllowWhiteSpaces, [ref]$dt)) { continue }
                            [void]$mr.Add((@($mid, [string]$m['BID'], $dt.ToString('yyyy-MM-dd HH:mm', $inv), [string]$ht['TID'], [string]$at['TID'], (Get-BClean $ht['N']), (Get-BClean $at['N']), $(if ($lg -is [System.Collections.IDictionary]) { [string]$lg['TID'] } else { '' }), (Get-BClean $m['SEA']), $sc, (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';'))
                            [void]$seen.Add($mid); $nm++; if (@($sc.Split('|')).Count -ge 5) { $nq++ }
                        } } } }
        } catch { Write-BLog ('site takım maçları okunamadı ' + $t + ': ' + $_.Exception.Message) }
        [void](Add-BRows 'basket_takim_maclari.csv' @('mid', 'bid', 'tarih', 'ev_tid', 'dep_tid', 'ev', 'dep', 'lig_tid', 'sezon', 'skorlar', 'kayit') $mr)
        [void]$done.Add($t + ';' + (Get-Date -Format 'yyyy-MM-dd HH:mm'))
        Start-Sleep -Milliseconds 300
    }
    [void](Add-BRows 'basket_takim_yapilan.csv' @('tid', 'tarih') $done)
    Write-BLog ('site takım maçları: ' + $nh + ' maç başlığı, ' + $nt + ' takım (sırada ' + [Math]::Max(0, $todo.Count - $nt) + '), ' + $nm + ' yeni maç, beş ve daha çok skor satırlı (çeyrekli olabilir) ' + $nq)
    if ($nt -ge 10 -and $nm -gt 0 -and $nq -eq 0) { Write-BLog 'site takım maçlarında çeyrek skoru görünmüyor: basket_nesine_takim_ornek.json dosyasını gönder' }
}
function global:Invoke-BCycle {
    $Shared.Busy = $true; $Shared.Phase = 'başladı'; $Shared.Req = 0; $slice = (Get-Date).AddMinutes([double]$(if ($Shared.SliceMin) { $Shared.SliceMin } else { 60 }))
    try {
        Write-BLog '— toplama turu başladı —'
        $Shared.Phase = 'Bülten'; try { [void](Save-BNesine) } catch { Write-BLog ('Bülten alınamadı: ' + $_.Exception.Message) }
        if ($Shared.Stop) { return }
        $Shared.Phase = 'Site biten maçlar'; try { [void](Save-BNesineDone 7) } catch { Write-BLog ('Canlı skor hatası: ' + $_.Exception.Message) }
        if ($Shared.Stop) { return }
        $Shared.Phase = 'Flashscore günlük listeler'
        $up = @(); try { $up = Save-BFlashDays @(-7, -6, -5, -4, -3, -2, -1, 0, 1) } catch { Write-BLog ('Flashscore liste hatası: ' + $_.Exception.Message) }
        # 132: oynanacak Flashscore maçları (kimlik, saat, takım kimlikleri, adlar): kaydedilmiş site analizleri takım kimliğini buradan bulur (hücre denetimi)
        try {
            $fxSeen = Get-BKeys 'basket_flash_fikstur.csv' @(0); $fx = New-Object System.Collections.ArrayList
            foreach ($h in @($up)) { $id = [string]$h['AA']; $ko = 0L; try { $ko = [long]$h['AD'] } catch {}; if (-not $id -or $fxSeen.Contains($id) -or $ko -le 0 -or -not $h['PX'] -or -not $h['PY']) { continue }; [void]$fx.Add((@($id, (Format-BTime $ko), [string]$h['PX'], [string]$h['PY'], (Get-BClean $h['AE']), (Get-BClean $h['AF']), (Get-BClean $h['_lig']), (Get-Date -Format 'yyyy-MM-dd HH:mm')) -join ';')); [void]$fxSeen.Add($id) }
            [void](Add-BRows 'basket_flash_fikstur.csv' @('id', 'zaman', 'ev_id', 'dep_id', 'ev', 'dep', 'lig', 'kayit') $fx)
        } catch { Write-BLog ('fikstür yazılamadı: ' + $_.Exception.Message) }
        # oynanacak maçlar: takım geçmişi (günde bir) + oranlar (ilk görüldüğünde ve başlamasına 3 saat kala)
        $Shared.Phase = 'oynanacak maçlar'
        $hhDone = Get-BKeys 'basket_h2h_yapilan.txt' @(0)
        $odDone = Get-BKeys 'basket_flash_oranlar.csv' @(0, 1)
        $today = (Get-Date -Format 'yyyy-MM-dd'); $nUp = 0; $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        foreach ($h in $up) {
            if ($Shared.Stop -or (Test-BLimit)) { break }
            $id = [string]$h['AA']; $ko = 0L; try { $ko = [long]$h['AD'] } catch {}
            if (-not $hhDone.Contains($id + '@' + $today)) {
                try { [void](Save-BH2h $id); [void]$hhDone.Add($id + '@' + $today); Add-BDone ($id + '@' + $today) } catch { Write-BLog ('geçmiş alınamadı ' + $id + ': ' + $_.Exception.Message) }
            }
            $as = $(if ($ko -gt 0 -and ($ko - $now) -le 3 * 3600) { 'son' } else { 'ilk' })
            if (-not $odDone.Contains($id + '|' + $as)) { try { [void](Save-BOdds $id $as ([string]$h['PX']) ([string]$h['PY'])); [void]$odDone.Add($id + '|' + $as); $nUp++ } catch { Write-BLog ('oran alınamadı ' + $id + ': ' + $_.Exception.Message) } }
        }
        Write-BLog ('oynanacak maçlar: ' + $up.Count + ' maç, ' + $nUp + ' maçın oranı alındı')
        # 130: site takım maçları (periyot / takım karnesi) ve oyuncu / hoca örnekleri
        $Shared.Phase = 'site takım maçları'; try { Save-BTakimPeriyot $up } catch { Write-BLog ('site takım maçları hatası: ' + $_.Exception.Message) }
        if ($Shared.Stop) { return }
        # geçmişe doğru tarama (yavaş, sınırlı): kuyruktaki en yeni maçlardan başlar; her maçın oranı ve iki takımının daha eski maçları
        $Shared.Phase = 'geçmiş tarama'; $Shared.More = $false
        $qp = Join-Path $Shared.DataDir 'basket_kuyruk.txt'; $qn = 0; $fail = 0; $why = ''; $lastCnt = Get-Date; $left = 0
        $paused = ($null -ne $Shared.PauseUntil -and (Get-Date) -lt [datetime]$Shared.PauseUntil)
        if ($paused) { Write-BLog ('geçmiş tarama bekliyor: Flashscore cevap vermediği için ' + ([datetime]$Shared.PauseUntil).ToString('HH:mm') + ' sonrasına ertelendi') }
        # sınır yok: kuyruk bitene kadar (ya da Durdur'a basılana kadar) devam eder; her saat başı tur yenilenir (bülten, yeni maçlar, maç öncesi oranlar)
        while ($Shared.Deep -and -not $paused -and -not $Shared.Stop -and (Test-Path -LiteralPath $qp)) {
            $qs = @{}
            foreach ($ln in [System.IO.File]::ReadAllLines($qp, [System.Text.Encoding]::UTF8)) { $c = $ln.Split(';'); if ($c.Count -ge 4 -and $c[0]) { $qs[$c[0]] = $c } }
            $todo = @($qs.Values | Where-Object { -not $odDone.Contains($_[0] + '|gecmis') } | Sort-Object { $v = 0L; [void][long]::TryParse([string]$_[3], [ref]$v); $v } -Descending)
            $left = $todo.Count; $Shared.QueueLeft = $left
            if ($left -eq 0) { break }
            $pass = 0
            foreach ($c in $todo) {
                if ($Shared.Stop) { $why = 'durdu'; break }
                if ((Get-Date) -ge $slice) { $why = 'yenile'; break }
                if (Test-BLimit) { $why = 'yenile'; break }
                try {
                    [void](Save-BOdds $c[0] 'gecmis' $c[1] $c[2]); [void]$odDone.Add($c[0] + '|gecmis'); $qn++; $pass++; $fail = 0; $Shared.PauseMin = 0
                } catch {
                    $fail++; Write-BLog ('geçmiş oran alınamadı ' + $c[0] + ': ' + $_.Exception.Message)
                    if ($fail -ge 5) {
                        $pm = [int]$Shared.PauseMin; $pm = $(if ($pm -le 0) { 30 } else { [Math]::Min(240, 2 * $pm) }); $Shared.PauseMin = $pm
                        $Shared.PauseUntil = (Get-Date).AddMinutes($pm)
                        Write-BLog ('üst üste 5 hata: Flashscore cevap vermiyor, geçmiş tarama ' + $pm + ' dakika ara veriyor'); $why = 'hata'; break
                    }
                    continue
                }
                if (-not $hhDone.Contains($c[0] + '@gecmis')) {
                    try { [void](Save-BH2h $c[0]); [void]$hhDone.Add($c[0] + '@gecmis'); Add-BDone ($c[0] + '@gecmis') } catch {}
                }
                $left--; $Shared.QueueLeft = $left
                if ($qn % 250 -eq 0) { Write-BLog ('geçmiş tarama sürüyor: bu turda ' + $qn + ' maç') }
                if (((Get-Date) - $lastCnt).TotalMinutes -ge 10) { try { Update-BCounts } catch {}; $lastCnt = Get-Date }
            }
            if ($why -or $pass -eq 0) { break }
            # bu geçişteki maçlar bitti; takım geçmişlerinden kuyruğa yeni eklenenlerle devam
        }
        $Shared.More = ($why -eq 'yenile')
        if ($Shared.Deep -and -not $paused) { Write-BLog ('geçmiş tarama: bu turda ' + $qn + ' maç' + $(if ($why -eq 'yenile') { ' · yeni bilgiler için tur yenileniyor, tarama hemen devam edecek' } elseif ($why -eq 'durdu') { ' · durduruldu' } else { '' }) + ' (kuyrukta ' + [Math]::Max(0, $left) + ' maç)') }
        Write-BLog ('— tur bitti: ' + $Shared.Req + ' Flashscore isteği —')
        try { Update-BCounts } catch {}
    } catch { Write-BLog ('Tur hatası: ' + $_.Exception.Message) }
    finally { $Shared.Busy = $false; $Shared.Phase = ''; $Shared.LastRun = Get-Date }
}
'@
# ================== EKRAN ==================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Basket Analiz Merkezi" Height="720" Width="1260" MinHeight="560" MinWidth="1020"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="13" Foreground="#F3F6FA" Background="#0B1220"
        TextOptions.TextFormattingMode="Display" UseLayoutRounding="True" SnapsToDevicePixels="True">
  <Window.Resources>
    <Style x:Key="Card" TargetType="Border">
      <Setter Property="Background" Value="#111B2E"/><Setter Property="BorderBrush" Value="#22314D"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="CornerRadius" Value="12"/><Setter Property="Padding" Value="14"/>
    </Style>
    <Style x:Key="SectionTitle" TargetType="TextBlock">
      <Setter Property="FontSize" Value="15"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Foreground" Value="#F3F6FA"/><Setter Property="Margin" Value="0,0,0,10"/>
    </Style>
    <Style x:Key="Muted" TargetType="TextBlock">
      <Setter Property="FontSize" Value="12"/><Setter Property="Foreground" Value="#B9C6D8"/><Setter Property="TextWrapping" Value="Wrap"/>
    </Style>
    <Style x:Key="Num" TargetType="TextBlock">
      <Setter Property="FontFamily" Value="Bahnschrift, Segoe UI"/><Setter Property="Foreground" Value="#F3F6FA"/>
    </Style>
    <Style TargetType="TabControl">
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TabControl">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="50"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <TabPanel IsItemsHost="True" Margin="250,0,0,0" VerticalAlignment="Bottom" HorizontalAlignment="Left" Background="Transparent"/>
          <ContentPresenter x:Name="PART_SelectedContentHost" Grid.Row="1" ContentSource="SelectedContent"/>
        </Grid>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style TargetType="TabItem">
      <Setter Property="Foreground" Value="#9FB0C8"/><Setter Property="FontSize" Value="13.5"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TabItem">
        <Border x:Name="Bd" Background="Transparent" BorderBrush="Transparent" BorderThickness="0,0,0,2" Padding="13,0,13,14" Margin="0,0,2,0">
          <ContentPresenter ContentSource="Header" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
          <Trigger Property="IsSelected" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#22C55E"/><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style TargetType="Button" x:Key="PrimaryButton">
      <Setter Property="Foreground" Value="#052E16"/><Setter Property="Background" Value="#22C55E"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="FontSize" Value="14"/><Setter Property="Padding" Value="20,9"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button">
        <Border x:Name="Bd" CornerRadius="10" Background="{TemplateBinding Background}" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="#4ADE80"/></Trigger>
          <Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Background" Value="#16A34A"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.45"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style TargetType="Button" x:Key="SecondaryButton">
      <Setter Property="Background" Value="Transparent"/><Setter Property="Foreground" Value="#F3F6FA"/><Setter Property="BorderBrush" Value="#3A4D6E"/>
      <Setter Property="FontWeight" Value="SemiBold"/><Setter Property="FontSize" Value="12.5"/><Setter Property="Padding" Value="12,6"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button">
        <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="8" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#6B83A8"/><Setter TargetName="Bd" Property="Background" Value="#1A2742"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.4"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Segment" TargetType="RadioButton">
      <Setter Property="Foreground" Value="#9FB0C8"/><Setter Property="FontSize" Value="12.5"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Padding" Value="13,6"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RadioButton">
        <Border x:Name="Bd" Background="Transparent" CornerRadius="7" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
          <Trigger Property="IsChecked" Value="True"><Setter TargetName="Bd" Property="Background" Value="#22345A"/><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.4"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="LineTab" TargetType="RadioButton">
      <Setter Property="Foreground" Value="#8EA0BC"/><Setter Property="FontSize" Value="12.5"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Padding" Value="12,7,12,8"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RadioButton">
        <Border x:Name="Bd" Background="Transparent" BorderBrush="Transparent" BorderThickness="0,0,0,2" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
          <Trigger Property="IsChecked" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#22C55E"/><Setter Property="Foreground" Value="#FFFFFF"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="SegBox" TargetType="Border">
      <Setter Property="Background" Value="#0A1120"/><Setter Property="BorderBrush" Value="#22314D"/><Setter Property="BorderThickness" Value="1"/><Setter Property="CornerRadius" Value="10"/><Setter Property="Padding" Value="3"/>
    </Style>
    <Style TargetType="TextBox">
      <Setter Property="Background" Value="#0A1120"/><Setter Property="Foreground" Value="#F3F6FA"/><Setter Property="BorderBrush" Value="#2C3E5F"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="12,6"/><Setter Property="FontSize" Value="13"/><Setter Property="CaretBrush" Value="#FFFFFF"/><Setter Property="SelectionBrush" Value="#60A5FA"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TextBox">
        <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="10">
          <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="{TemplateBinding VerticalContentAlignment}"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#4A5F84"/></Trigger>
          <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#E2E8F0"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="SbPage" TargetType="RepeatButton">
      <Setter Property="Focusable" Value="False"/><Setter Property="IsTabStop" Value="False"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RepeatButton"><Border Background="Transparent"/></ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="SbThumb" TargetType="Thumb">
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Thumb">
        <Border x:Name="Th" CornerRadius="4" Background="#33476A" Margin="2"/>
        <ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Th" Property="Background" Value="#4E6590"/></Trigger></ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style TargetType="ScrollBar">
      <Setter Property="Background" Value="Transparent"/><Setter Property="Width" Value="11"/><Setter Property="MinWidth" Value="11"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ScrollBar">
        <Grid Background="Transparent">
          <Track x:Name="PART_Track" IsDirectionReversed="True">
            <Track.DecreaseRepeatButton><RepeatButton Style="{StaticResource SbPage}" Command="ScrollBar.PageUpCommand"/></Track.DecreaseRepeatButton>
            <Track.Thumb><Thumb Style="{StaticResource SbThumb}"/></Track.Thumb>
            <Track.IncreaseRepeatButton><RepeatButton Style="{StaticResource SbPage}" Command="ScrollBar.PageDownCommand"/></Track.IncreaseRepeatButton>
          </Track>
        </Grid>
      </ControlTemplate></Setter.Value></Setter>
      <Style.Triggers>
        <Trigger Property="Orientation" Value="Horizontal">
          <Setter Property="Width" Value="Auto"/><Setter Property="MinWidth" Value="0"/><Setter Property="Height" Value="11"/><Setter Property="MinHeight" Value="11"/>
          <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ScrollBar">
            <Grid Background="Transparent">
              <Track x:Name="PART_Track" IsDirectionReversed="False">
                <Track.DecreaseRepeatButton><RepeatButton Style="{StaticResource SbPage}" Command="ScrollBar.PageLeftCommand"/></Track.DecreaseRepeatButton>
                <Track.Thumb><Thumb Style="{StaticResource SbThumb}"/></Track.Thumb>
                <Track.IncreaseRepeatButton><RepeatButton Style="{StaticResource SbPage}" Command="ScrollBar.PageRightCommand"/></Track.IncreaseRepeatButton>
              </Track>
            </Grid>
          </ControlTemplate></Setter.Value></Setter>
        </Trigger>
      </Style.Triggers>
    </Style>
    <Style TargetType="DataGrid">
      <Setter Property="Background" Value="#111B2E"/><Setter Property="Foreground" Value="#F3F6FA"/><Setter Property="BorderBrush" Value="#22314D"/><Setter Property="RowBackground" Value="#111B2E"/>
      <Setter Property="AlternatingRowBackground" Value="#0E1728"/><Setter Property="GridLinesVisibility" Value="Horizontal"/><Setter Property="HorizontalGridLinesBrush" Value="#1A2740"/>
      <Setter Property="HeadersVisibility" Value="Column"/><Setter Property="CanUserAddRows" Value="False"/><Setter Property="AutoGenerateColumns" Value="True"/><Setter Property="RowHeight" Value="30"/><Setter Property="VerticalGridLinesBrush" Value="Transparent"/>
    </Style>
    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="#111B2E"/><Setter Property="Foreground" Value="#8EA0BC"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="FontSize" Value="11.5"/><Setter Property="Padding" Value="10,8"/>
      <Setter Property="BorderBrush" Value="#22314D"/><Setter Property="BorderThickness" Value="0,0,0,1"/>
    </Style>
  </Window.Resources>
  <Grid>
    <Grid.RowDefinitions><RowDefinition Height="50"/><RowDefinition Height="*"/><RowDefinition Height="28"/></Grid.RowDefinitions>
    <Border x:Name="BasketTopBar" Background="#0A101C" BorderBrush="#1F2B44" BorderThickness="0,0,0,1">
      <Grid Margin="20,0,18,0">
        <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Border Width="26" Height="26" CornerRadius="13" Background="#FFFFFF"><TextBlock Text="🏀" FontSize="15" FontFamily="Segoe UI Emoji" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
          <TextBlock Text="Basket Analiz " FontSize="16" FontWeight="Bold" Margin="10,0,0,0" VerticalAlignment="Center"/>
          <TextBlock Text="Merkezi" FontSize="16" FontWeight="Bold" Foreground="#22C55E" VerticalAlignment="Center"/>
          
        </StackPanel>
        <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center"><Ellipse x:Name="StatusDot" Width="8" Height="8" Fill="#64748B" VerticalAlignment="Center"/><TextBlock x:Name="StatusText" Text="Bekliyor" FontSize="12" Foreground="#9FB0C8" Margin="8,0,0,0" VerticalAlignment="Center"/></StackPanel>
      </Grid>
    </Border>
<TabControl x:Name="MainTabs" Grid.Row="0" Grid.RowSpan="2" Background="Transparent" BorderThickness="0">
  <TabItem Header="Tek maç">
    <Grid Margin="20,12,20,12">
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
      <Grid>
        <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <Border Style="{StaticResource SegBox}">
          <StackPanel Orientation="Horizontal">
            <RadioButton x:Name="ModePre" Content="Maç öncesi" GroupName="BasketMode" Style="{StaticResource Segment}" IsChecked="True"/>
            <RadioButton x:Name="ModePast" Content="Geçmiş maç" GroupName="BasketMode" Style="{StaticResource Segment}"/>
          </StackPanel>
        </Border>
        <Grid Grid.Column="1" Margin="10,0">
          <TextBox x:Name="UrlBox" MinHeight="38" VerticalContentAlignment="Center"/>
          <TextBlock x:Name="UrlHint" Text="Maç bağlantısını veya maç kodunu gir" Foreground="#8093AD" Margin="12,0" VerticalAlignment="Center" IsHitTestVisible="False"/>
        </Grid>
        <StackPanel Grid.Column="2" Orientation="Horizontal">
          <Button x:Name="OpenBasketNesine" Content="Siteye git  ↗" Style="{StaticResource SecondaryButton}" MinHeight="38" Margin="0,0,8,0"/>
          <Button x:Name="RefreshButton" Style="{StaticResource PrimaryButton}" Content="ANALİZ ET  ▶" MinWidth="150" MinHeight="38"/>
        </StackPanel>
      </Grid>
      <TextBlock x:Name="WorkStatus" Grid.Row="1" Margin="4,8,0,10" Style="{StaticResource Muted}"/>
      <ScrollViewer Grid.Row="2" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="330"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <StackPanel Margin="0,0,12,0">
            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock x:Name="MatchLeague" Style="{StaticResource Muted}" TextWrapping="Wrap"/>
                <TextBlock x:Name="MatchTitle" FontSize="24" FontWeight="Bold" TextWrapping="Wrap" Margin="0,5,0,8"/>
                <TextBlock x:Name="MatchResult" FontSize="14" FontWeight="SemiBold" TextWrapping="Wrap"/>
                <TextBlock x:Name="MatchLikelyScore" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,5,0,0"/>
                <TextBlock x:Name="MatchModelView" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,5,0,0"/>
              </StackPanel>
            </Border>
            <Border x:Name="CandidateCard" Style="{StaticResource Card}" Background="#123522" Margin="0,10,0,0">
              <StackPanel>
                <TextBlock x:Name="CandidateBadge" Text="MAÇ TAHMİNİ" FontSize="11" FontWeight="Bold" Foreground="#86EFAC"/>
                <TextBlock x:Name="MatchDecision" Text="Veri bekleniyor" FontSize="19" FontWeight="Bold" TextWrapping="Wrap" Margin="0,7,0,0"/>
                <TextBlock x:Name="CandidateProbabilityText" Text="—" FontSize="31" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,6,0,0"/>
                <TextBlock x:Name="CandidateOddsText" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,2,0,0"/>
                <TextBlock x:Name="MatchTotal" FontSize="15" TextWrapping="Wrap" Margin="0,9,0,0"/>
                <TextBlock x:Name="MatchActual" FontSize="14" TextWrapping="Wrap" Margin="0,5,0,0"/>
              </StackPanel>
            </Border>
            <Border Style="{StaticResource Card}" Margin="0,10,0,0">
              <StackPanel>
                <TextBlock Text="TAKIM KARŞILAŞTIRMASI" Style="{StaticResource SectionTitle}"/>
                <TextBlock x:Name="MatchFormSummary" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,0,0,8"/>
                <StackPanel x:Name="TeamStats"/>
              </StackPanel>
            </Border>
          </StackPanel>
          <StackPanel Grid.Column="1">
            <Border Style="{StaticResource Card}">
              <StackPanel>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                  <TextBlock Text="BÜTÜN BAHİSLER" Style="{StaticResource SectionTitle}" Margin="0"/>
                  <TextBlock Grid.Column="1" Text="Basketbol · maç önü / geçmiş" Style="{StaticResource Muted}" VerticalAlignment="Center"/>
                </Grid>
                <Border BorderBrush="#22314D" BorderThickness="0,1,0,0" Padding="0,8,0,3"><TextBlock Text="TOPLAM SAYI · ALT / ÜST" FontSize="10.5" FontWeight="Bold" Foreground="#8EA0BC"/></Border>
                <StackPanel x:Name="MarketTotalRows"/>
                <Border Visibility="Collapsed" BorderBrush="#22314D" BorderThickness="0,1,0,0" Padding="0,8,0,3" Margin="0,7,0,0"><TextBlock Text="MAÇ SONUCU · KAZANAN" FontSize="10.5" FontWeight="Bold" Foreground="#8EA0BC"/></Border>
                <StackPanel x:Name="MarketWinnerRows" Visibility="Collapsed"/>
                <Border BorderBrush="#22314D" BorderThickness="0,1,0,0" Padding="0,8,0,3" Margin="0,7,0,0"><TextBlock Text="TAKIM SAYILARI" FontSize="10.5" FontWeight="Bold" Foreground="#8EA0BC"/></Border>
                <StackPanel x:Name="MarketTeamRows"/>
                <Border BorderBrush="#22314D" BorderThickness="0,1,0,0" Padding="0,8,0,3" Margin="0,7,0,0"><TextBlock Text="OLASI SKORLAR" FontSize="10.5" FontWeight="Bold" Foreground="#8EA0BC"/></Border>
                <StackPanel x:Name="MarketScoreRows"/>
              </StackPanel>
            </Border>
            <Border Style="{StaticResource Card}" Margin="0,10,0,0">
              <DockPanel>
                <TextBlock DockPanel.Dock="Top" Text="TÜM NESİNE ALT / ÜST ÇİZGİLERİ" Style="{StaticResource SectionTitle}"/>
                <TextBlock DockPanel.Dock="Top" x:Name="LinesNotice" Style="{StaticResource Muted}" TextWrapping="Wrap"/>
                <StackPanel x:Name="ModelLineControls" DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,8,0,8" Visibility="Collapsed">
                  <TextBlock Text="Kendi çizgin" VerticalAlignment="Center" Margin="0,0,8,0"/>
                  <TextBox x:Name="ModelLineInput" Width="90" Margin="0,0,8,0" ToolTip="Örneğin 165,5"/>
                  <Button x:Name="ModelLineButton" Content="Yüzdeyi hesapla" Style="{StaticResource SecondaryButton}"/>
                </StackPanel>
                <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" MaxHeight="330">
                  <StackPanel x:Name="SingleLines"/>
                </ScrollViewer>
              </DockPanel>
            </Border>
          </StackPanel>
        </Grid>
      </ScrollViewer>
    </Grid>
  </TabItem>
  <TabItem Header="Kupon">
    <Grid Margin="20,12,20,12">
      <Grid.ColumnDefinitions><ColumnDefinition Width="330"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
      <StackPanel Margin="0,0,12,0">
        <Border Style="{StaticResource Card}">
          <StackPanel>
            <TextBlock Text="MAÇLARI GETİR" Style="{StaticResource SectionTitle}"/>
            <Border Style="{StaticResource SegBox}">
              <StackPanel Orientation="Horizontal">
                <RadioButton x:Name="ListToday" Content="Bugün" GroupName="BasketDays" Style="{StaticResource Segment}" IsChecked="True"/>
                <RadioButton x:Name="ListTomorrow" Content="Yarın" GroupName="BasketDays" Style="{StaticResource Segment}"/>
                <RadioButton x:Name="ListThree" Content="3 gün" GroupName="BasketDays" Style="{StaticResource Segment}"/>
                <RadioButton x:Name="ListDone" Content="Bitenler" GroupName="BasketDays" Style="{StaticResource Segment}"/>
              </StackPanel>
            </Border>
            <Button x:Name="ListFetch" Content="Maçları getir" Style="{StaticResource SecondaryButton}" Margin="0,10,0,0"/>
            <TextBlock Text="Maç bağlantısı veya kodu" Style="{StaticResource Muted}" Margin="0,12,0,6"/>
            <TextBox x:Name="BatchUrls" Height="70" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" TextWrapping="Wrap"/>
          </StackPanel>
        </Border>
        <Border Style="{StaticResource Card}" Margin="0,10,0,0">
          <StackPanel>
            <TextBlock Text="ANALİZ" Style="{StaticResource SectionTitle}"/>
            <Button x:Name="BatchStart" Style="{StaticResource PrimaryButton}" Content="BAŞLAT  ▶" MinHeight="40"/>
            <TextBlock x:Name="BatchStatus" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,8,0,0"/>
          </StackPanel>
        </Border>
      </StackPanel>
      <DockPanel Grid.Column="1">
        <Button DockPanel.Dock="Bottom" x:Name="BatchOpen" Content="Seçili maçı aç" Style="{StaticResource SecondaryButton}" Margin="0,10,0,0" HorizontalAlignment="Left"/>
        <DataGrid x:Name="BatchGrid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Single"><DataGrid.Columns>
  <DataGridTextColumn Header="Kod" Binding="{Binding Code}" Width="78"/>
  <DataGridTextColumn Header="Başlama" Binding="{Binding Time}" Width="135"/>
  <DataGridTextColumn Header="Lig" Binding="{Binding League}" Width="*"/>
  <DataGridTextColumn Header="Ev" Binding="{Binding Home}" Width="*"/>
  <DataGridTextColumn Header="Deplasman" Binding="{Binding Away}" Width="*"/>
  <DataGridTextColumn Header="Tahmin" Binding="{Binding Expected}" Width="75"/>
  <DataGridTextColumn Header="Model yorumu" Binding="{Binding ModelView}" Width="160"/>
  <DataGridTextColumn Header="Gerçek" Binding="{Binding Actual}" Width="70"/>
  <DataGridTextColumn Header="Karar" Binding="{Binding KararText}" Width="150"/>
  <DataGridTextColumn Header="Durum" Binding="{Binding Status}" Width="180"/>
</DataGrid.Columns></DataGrid>
      </DockPanel>
    </Grid>
  </TabItem>
  <TabItem Header="Kupon önerisi">
    <DockPanel Margin="20,12,20,12">
      <TextBlock x:Name="SuggestionsStatus" DockPanel.Dock="Top" Text="Kupon sekmesinde analiz başlat." Style="{StaticResource Muted}" Margin="0,0,0,10"/>
      <Button x:Name="SuggestionOpen" DockPanel.Dock="Bottom" Content="Seçili maçı aç" Style="{StaticResource SecondaryButton}" HorizontalAlignment="Left" Margin="0,10,0,0"/>
      <DataGrid x:Name="SuggestionGrid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Single"><DataGrid.Columns>
  <DataGridTextColumn Header="Kupon" Binding="{Binding CouponGroup}" Width="65"/>
  <DataGridTextColumn Header="Başlama" Binding="{Binding Time}" Width="135"/>
  <DataGridTextColumn Header="Lig" Binding="{Binding League}" Width="*"/>
  <DataGridTextColumn Header="Ev" Binding="{Binding Home}" Width="*"/>
  <DataGridTextColumn Header="Deplasman" Binding="{Binding Away}" Width="*"/>
  <DataGridTextColumn Header="Tahmin" Binding="{Binding Expected}" Width="75"/>
  <DataGridTextColumn Header="Gerçek" Binding="{Binding Actual}" Width="70"/>
  <DataGridTextColumn Header="Karar" Binding="{Binding KararText}" Width="150"/>
</DataGrid.Columns></DataGrid>
    </DockPanel>
  </TabItem>
  <TabItem Header="Maç tipleri">
    <DockPanel Margin="20,12,20,12">
      <TextBlock DockPanel.Dock="Top" Text="Liglere göre geçmiş toplam sayı" Style="{StaticResource SectionTitle}"/>
      <DataGrid x:Name="LeagueGrid" AutoGenerateColumns="False" IsReadOnly="True">
        <DataGrid.Columns>
          <DataGridTextColumn Header="Lig" Binding="{Binding League}" Width="2*"/>
          <DataGridTextColumn Header="Skorlu maç" Binding="{Binding Count}" Width="*"/>
          <DataGridTextColumn Header="Ortalama toplam sayı" Binding="{Binding Average}" Width="*"/>
        </DataGrid.Columns>
      </DataGrid>
    </DockPanel>
  </TabItem>
  <TabItem Header="Kayıtlar">
    <DockPanel Margin="20,12,20,12">
      <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,0,0,10">
        <TextBlock Text="Takım veya kod ara" Style="{StaticResource Muted}" VerticalAlignment="Center" Margin="0,0,10,0"/>
        <TextBox x:Name="RecordSearch" Width="320" MinHeight="32"/>
        <Button x:Name="ReloadRecords" Content="Yenile" Style="{StaticResource SecondaryButton}" Margin="10,0,0,0"/>
        <ComboBox x:Name="RecordFilter" Width="145" Margin="10,0,0,0" SelectedIndex="0" VerticalAlignment="Center">
          <ComboBoxItem Content="Tüm kayıtlar"/>
          <ComboBoxItem Content="Flashscore testi"/>
          <ComboBoxItem Content="Site testi"/>
          <ComboBoxItem Content="Kaydedilen analizler"/>
        </ComboBox>
      </StackPanel>
      <TextBlock x:Name="RecordSummary" DockPanel.Dock="Top" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,0,0,8"/>
      <TextBlock x:Name="BHucreDurum" DockPanel.Dock="Top" Style="{StaticResource Muted}" TextWrapping="Wrap" Margin="0,0,0,8"/>
      <Button x:Name="RecordOpen" DockPanel.Dock="Bottom" Content="Seçili maçı aç" Style="{StaticResource SecondaryButton}" HorizontalAlignment="Left" Margin="0,10,0,0"/>
      <DataGrid x:Name="RecordGrid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Single"><DataGrid.Columns>
  <DataGridTextColumn Header="Başlama" Binding="{Binding Time}" Width="135"/>
  <DataGridTextColumn Header="Lig" Binding="{Binding League}" Width="*"/>
  <DataGridTextColumn Header="Ev" Binding="{Binding Home}" Width="*"/>
  <DataGridTextColumn Header="Deplasman" Binding="{Binding Away}" Width="*"/>
  <DataGridTextColumn Header="Tahmin" Binding="{Binding Expected}" Width="75"/>
  <DataGridTextColumn Header="Gerçek" Binding="{Binding Actual}" Width="70"/>
  <DataGridTextColumn Header="Karar" Binding="{Binding KararText}" Width="150"/>
  <DataGridTextColumn Header="Kaynak" Binding="{Binding RecordSource}" Width="96"/>
  <DataGridTextColumn Header="Sonuç" Binding="{Binding KararSonuc}" Width="65"/>
  <DataGridTextColumn Header="Durum" Binding="{Binding Status}" Width="200"/>
</DataGrid.Columns></DataGrid>
    </DockPanel>
  </TabItem>
  <TabItem Header="Ayarlar">
        <Grid Margin="20,12,20,12">
      <Grid.ColumnDefinitions><ColumnDefinition Width="380"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
      <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" Margin="0,0,12,0">
        <StackPanel>
          <Border Style="{StaticResource Card}">
            <StackPanel>
              <TextBlock Text="VERİ TOPLAMA" FontSize="11.5" FontWeight="Bold" Foreground="#8EA0BC"/>
              <TextBlock Style="{StaticResource Muted}" Margin="0,6,0,0" Text="Site basketbol bülteni (bütün bahisler ve oranlar), sitede biten maçlar, Flashscore maçları, iki takımın geçmiş maçları ve oranlar toplanır. "/>
            </StackPanel>
          </Border>
          <UniformGrid Columns="2" Margin="0,10,0,0">
            <Border Style="{StaticResource Card}" Margin="0,0,5,10" Padding="12,10"><StackPanel><TextBlock Text="Site oranlı maç" Style="{StaticResource Muted}"/><TextBlock x:Name="CntNes" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
            <Border Style="{StaticResource Card}" Margin="5,0,0,10" Padding="12,10"><StackPanel><TextBlock Text="Sitede biten maç" Style="{StaticResource Muted}"/><TextBlock x:Name="CntNesBit" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
            <Border Style="{StaticResource Card}" Margin="0,0,5,10" Padding="12,10"><StackPanel><TextBlock Text="Flashscore biten maç" Style="{StaticResource Muted}"/><TextBlock x:Name="CntFlash" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
            <Border Style="{StaticResource Card}" Margin="5,0,0,10" Padding="12,10"><StackPanel><TextBlock Text="Geçmiş maç arşivi" Style="{StaticResource Muted}"/><TextBlock x:Name="CntArsiv" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
            <Border Style="{StaticResource Card}" Margin="0,0,5,0" Padding="12,10"><StackPanel><TextBlock Text="Oran sorgulanan maç" Style="{StaticResource Muted}"/><TextBlock x:Name="CntOran" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
            <Border Style="{StaticResource Card}" Margin="5,0,0,0" Padding="12,10"><StackPanel><TextBlock Text="Taramada bekleyen" Style="{StaticResource Muted}"/><TextBlock x:Name="CntKuyruk" Text="—" FontSize="22" FontWeight="SemiBold"/></StackPanel></Border>
          </UniformGrid>
          <Border Style="{StaticResource Card}" Margin="0,10,0,0">
            <StackPanel>
              <Button x:Name="RunButton" Style="{StaticResource PrimaryButton}" Content="ŞİMDİ TOPLA  ▶"/>
              <UniformGrid Columns="2" Margin="0,8,0,0"><Button x:Name="StopButton" Content="Durdur" Style="{StaticResource SecondaryButton}" Margin="0,0,4,0" IsEnabled="False"/><Button x:Name="FolderButton" Content="Kayıt klasörü" Style="{StaticResource SecondaryButton}" Margin="4,0,0,0"/></UniformGrid>
              <!-- 112. düzeltme: kendiliğinden açık; kapalıyken 14 Kasım'dan beri sonuç toplanmamıştı (takım geçmişi eski kalıyordu) -->
              <CheckBox x:Name="AutoBox" Content="Program açıkken durmadan topla" IsChecked="True" Foreground="#DCE6F5" Margin="0,12,0,0"/>
              <CheckBox x:Name="DeepBox" Content="Geçmişe doğru tara (sınırsız, kuyruk bitene kadar)" IsChecked="True" Foreground="#DCE6F5" Margin="0,6,0,0" ToolTip="Bulunan geçmiş maçların oranı ve o takımların daha eski maçları durmadan alınır. Her istek arası 1,5 saniye; Flashscore cevap vermezse kendiliğinden ara verir."/>
              <TextBlock x:Name="NextText" Text="" Style="{StaticResource Muted}" Margin="0,8,0,0"/>
              <Button x:Name="StatsButton" Content="Maç istatistiklerini topla" Style="{StaticResource SecondaryButton}" Margin="0,10,0,0" ToolTip="Biten maçların atış, ribaund, top kaybı istatistikleri (tempo ve üçlük denemesi için). En yeni maçtan geriye gider; Durdur ile kesilir, sonra kaldığı yerden devam eder. Her istek arası 1,5 saniye; 1 saatte yaklaşık 2.000 maç."/>
            </StackPanel>
          </Border>
          <Border Style="{StaticResource Card}" Margin="0,10,0,0">
            <StackPanel>
              <Button x:Name="PackButton" Content="Gönderilecek dosyaları hazırla" Style="{StaticResource SecondaryButton}"/>
              <TextBlock x:Name="PackNote" Text="Masaüstüne BAM_gonder_….zip yapar; bana o zip'i gönder." Style="{StaticResource Muted}" Margin="0,6,0,0"/>
            </StackPanel>
          </Border>
        </StackPanel>
      </ScrollViewer>
      <Border Grid.Column="1" Style="{StaticResource Card}" Padding="0">
        <DockPanel>
          <TextBlock DockPanel.Dock="Top" Text="GÜNLÜK" FontSize="11.5" FontWeight="Bold" Foreground="#8EA0BC" Margin="14,10,14,6"/>
          <TextBox x:Name="LogBox" IsReadOnly="True" Background="#0A1120" Foreground="#C9D4E4" BorderThickness="0" FontFamily="Consolas" FontSize="12" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" Padding="12,8" Margin="1,0,1,1"/>
        </DockPanel>
      </Border>
    </Grid>

  </TabItem>
</TabControl>
    <Border x:Name="BasketFootBar" Grid.Row="2" Background="#0A101C" BorderBrush="#1F2B44" BorderThickness="0,1,0,0"><TextBlock x:Name="FootText" Text="" FontSize="11.5" Foreground="#7F92AF" Margin="20,0,0,0" VerticalAlignment="Center"/></Border>
  </Grid>
</Window>
'@
if ($null -ne $HostContainer) {
    if ($null -eq $OwnerWindow) { throw 'Basketbol için ana pencere bulunamadı.' }
    $xaml = $xaml.Replace('<Window ', '<UserControl ').Replace('</Window>', '</UserControl>').Replace('Window.Resources', 'UserControl.Resources')
    $xaml = $xaml -replace 'Title="Basket Analiz Merkezi" Height="720" Width="1260" MinHeight="560" MinWidth="1020"\s+WindowStartupLocation="CenterScreen"\s+', ''
}
$script:BasketWindow = [System.Windows.Markup.XamlReader]::Parse($xaml)
function Find-BasketControl([string]$n) { return $script:BasketWindow.FindName($n) }
if ($null -ne $HostContainer) {
    # The host already draws the shared title and footer. Collapse the module's
    # duplicate chrome so its tabs and match dashboard line up with football.
    (Find-BasketControl 'BasketTopBar').Visibility = 'Collapsed'
    (Find-BasketControl 'BasketFootBar').Visibility = 'Collapsed'
    $rootGrid = $script:BasketWindow.Content
    $rootGrid.RowDefinitions[0].Height = [System.Windows.GridLength]::new(0)
    $rootGrid.RowDefinitions[2].Height = [System.Windows.GridLength]::new(0)
}
(Find-BasketControl 'FootText').Text = 'Basket Analiz Merkezi · ' + $script:Version + ' · kayıtlar: ' + $script:DataDir

# arka plan iş parçacığı (fonksiyonlar bir kez tanımlanır, her tur aynı yerde çalışır)
$script:Rs = [runspacefactory]::CreateRunspace(); $script:Rs.ApartmentState = 'STA'; $script:Rs.Open()
$script:Rs.SessionStateProxy.SetVariable('Shared', $script:BasketShared)
$ps0 = [powershell]::Create(); $ps0.Runspace = $script:Rs; [void]$ps0.AddScript($WorkerCode); [void]$ps0.Invoke(); $ps0.Dispose()
$script:Job = $null
function Start-BCycle {
    if ($script:BasketShared.Busy -or $null -ne $script:Job -or $null -ne $script:BasketJobs) { return }
    $script:BasketShared.Stop = $false; $script:BasketShared.Deep = [bool](Find-BasketControl 'DeepBox').IsChecked; $script:BasketShared.Busy = $true
    $ps = [powershell]::Create(); $ps.Runspace = $script:Rs; [void]$ps.AddScript('Invoke-BCycle')
    $script:Job = @{ ps = $ps; h = $ps.BeginInvoke() }
}
# 80. düzeltme: toplama sürerken istatistik düğmesine basılırsa sessiz kalmaz; süren toplama durdurulur, biter bitmez istatistik kendiliğinden başlar.
$script:BasketStatsPending = $false
function Start-BStats {
    if ($script:BasketShared.Busy -or $null -ne $script:Job -or $null -ne $script:BasketJobs) {
        $script:BasketStatsPending = $true
        $script:BasketShared.Stop = $true
        [void]$script:BasketShared.Lines.Add((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  istatistik sıraya alındı: süren toplama durduruluyor, biter bitmez istatistik başlayacak')
        return
    }
    $script:BasketStatsPending = $false
    $script:BasketShared.Stop = $false; $script:BasketShared.Busy = $true
    $ps = [powershell]::Create(); $ps.Runspace = $script:Rs; [void]$ps.AddScript('Invoke-BStatsRun')
    $script:Job = @{ ps = $ps; h = $ps.BeginInvoke() }
}
function Start-BCounts { if ($null -ne $script:Job) { return }; $ps = [powershell]::Create(); $ps.Runspace = $script:Rs; [void]$ps.AddScript('try { Update-BCounts } catch {}'); $script:Job = @{ ps = $ps; h = $ps.BeginInvoke() } }
$script:LogShown = 0; $script:Started = Get-Date
# 108. düzeltme: puan gücü tablosu (basket_guc_tablosu.csv) ayrı iş parçacığında: açılıştan 20 sn sonra, sonra 3 saatte bir. Analiz beklemez.
$script:GucJob = $null; $script:GucNext = (Get-Date).AddSeconds(20)
function Start-BGucJob {
    if ($null -ne $script:GucJob) { return }
    $rs = [runspacefactory]::CreateRunspace(); $rs.Open()
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript({
        param($code, $dir)
        try {
            if (-not ('BasketGuc.Tablo' -as [type])) { Add-Type -TypeDefinition $code }
            $sw = [Diagnostics.Stopwatch]::StartNew()
            $r = [BasketGuc.Tablo]::Build(@((Join-Path $dir 'basket_mac_sonuclari.csv'), (Join-Path $dir 'basket_flash_maclar.csv')), (Join-Path $dir 'basket_guc_tablosu.csv'), '2023-07-01')
            'tamam;' + $r + ';' + $sw.ElapsedMilliseconds
        } catch { 'hata;' + $_.Exception.Message }
    }).AddArgument($global:BGucCode).AddArgument($script:DataDir)
    $script:GucJob = @{ ps = $ps; rs = $rs; h = $ps.BeginInvoke() }
}
$script:Tick = New-Object System.Windows.Threading.DispatcherTimer; $script:Tick.Interval = [TimeSpan]::FromSeconds(1)
$script:Tick.Add_Tick({
    try {
        if ($null -ne $script:Job -and $script:Job.h.IsCompleted) { try { [void]$script:Job.ps.EndInvoke($script:Job.h) } catch {}; try { $script:Job.ps.Dispose() } catch {}; $script:Job = $null }
        if ($script:BasketStatsPending -and -not $script:BasketShared.Busy -and $null -eq $script:Job -and $null -eq $script:BasketJobs) { Start-BStats }
        # 131: hücre denetimi
        try {
            Complete-BHucreDenetim
            if ($null -eq $script:BHucreJob -and (Get-Date) -ge $script:BHucreNext) {
                $script:BHucreNext = (Get-Date).AddHours(12)
                $hf = Join-Path $script:DataDir 'basket_hucre.txt'
                # 135: 131'in sonucu (yalnız Flashscore arşivi, site analizleri yok) da yenilenir
                $eskiSonuc = $false; try { $eskiSonuc = (Test-Path -LiteralPath $hf) -and -not ([IO.File]::ReadAllText($hf) -match 'site oranlı') } catch {}
                if (-not (Test-Path -LiteralPath $hf) -or $eskiSonuc -or ((Get-Date) - (Get-Item -LiteralPath $hf).LastWriteTime).TotalHours -ge 12) { Start-BHucreDenetim } else { Show-BHucre }
            }
            # 132: fikstür dosyası değişince (yeni eşleşmeler) de yenilenir
            $fxp = Join-Path $script:DataDir 'basket_flash_fikstur.csv'
            # 134: fikstür her turda değiştiği için ekran her saat yenilenip birkaç saniye donuyordu; yalnız denetim sonucu değişince yenilenir
            if ($script:BHucreYenile -and $null -eq $script:BasketRecJob -and $null -eq $script:BasketJobs) {
                $script:BHucreYenile = $false
                Update-BHucreEkran
                $script:BasketReplay = $null; $script:BasketReplayCodes = $null; Start-BasketRecordLoad -Force
            }
        } catch {}
        # 108: puan gücü tablosu
        if ($null -ne $script:GucJob -and $script:GucJob.h.IsCompleted) {
            $res = ''; try { $res = [string](@($script:GucJob.ps.EndInvoke($script:GucJob.h)) -join '') } catch { $res = 'hata;' + $_.Exception.Message }
            try { $script:GucJob.ps.Dispose(); $script:GucJob.rs.Dispose() } catch {}
            $script:GucJob = $null; $script:GucNext = (Get-Date).AddHours(3)
            $q = $res.Split(';')
            $msg = $(if ($q[0] -eq 'tamam' -and $q.Count -ge 5) { 'Puan gücü tablosu yenilendi: ' + ([int]$q[1]).ToString('N0', $script:TrC) + ' maç · ' + ([int]$q[2]).ToString('N0', $script:TrC) + ' takım · ' + [Math]::Round([int]$q[4] / 1000.0, 1).ToString($script:TrC) + ' sn' } else { 'Puan gücü tablosu yapılamadı: ' + $res })
            [void]$script:BasketShared.Lines.Add((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $msg)
        }
        if ($null -eq $script:GucJob -and (Get-Date) -ge $script:GucNext) { $script:GucNext = (Get-Date).AddHours(3); try { Start-BGucJob } catch { [void]$script:BasketShared.Lines.Add((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  Puan gücü tablosu başlatılamadı: ' + $_.Exception.Message) } }
        # günlük
        $n = $script:BasketShared.Lines.Count
        if ($n -gt $script:LogShown) { $box = Find-BasketControl 'LogBox'; for ($i = $script:LogShown; $i -lt $n; $i++) { $box.AppendText([string]$script:BasketShared.Lines[$i] + "`r`n") }; $script:LogShown = $n; if ($box.Text.Length -gt 300000) { $box.Text = $box.Text.Substring($box.Text.Length - 150000) }; $box.ScrollToEnd() }
        # durum
        $busy = [bool]$script:BasketShared.Busy
        (Find-BasketControl 'StatusDot').Fill = (New-Object System.Windows.Media.BrushConverter).ConvertFromString($(if ($busy) { '#38BDF8' } else { '#22C55E' }))
        (Find-BasketControl 'StatusText').Text = $(if ($busy) { 'Topluyor: ' + $script:BasketShared.Phase + ' · ' + ([int]$script:BasketShared.Req).ToString('N0', $script:TrC) + ' istek' + $(if ([int]$script:BasketShared.QueueLeft -gt 0) { ' · kuyrukta ' + ([int]$script:BasketShared.QueueLeft).ToString('N0', $script:TrC) } else { '' }) } elseif ($null -ne $script:BasketShared.LastRun) { 'Son tur: ' + ([datetime]$script:BasketShared.LastRun).ToString('HH:mm') } else { 'Hazır' })
        (Find-BasketControl 'RunButton').IsEnabled = (-not $busy -and $null -eq $script:Job); (Find-BasketControl 'StopButton').IsEnabled = $busy
        (Find-BasketControl 'StatsButton').IsEnabled = (-not $busy -and $null -eq $script:Job)
        $c = $script:BasketShared.Counts
        if ($null -ne $c) { foreach ($p in @(@('CntNes', 'nes'), @('CntNesBit', 'nesbit'), @('CntFlash', 'flash'), @('CntArsiv', 'arsiv'), @('CntOran', 'oran'), @('CntKuyruk', 'kuyruk'))) { (Find-BasketControl $p[0]).Text = ([int]$c[$p[1]]).ToString('N0', [System.Globalization.CultureInfo]::GetCultureInfo('tr-TR')) } }
        # otomatik tur: açılıştan 10 saniye sonra; tarama sürüyorsa hemen devam, yoksa saatte bir (bülten, yeni maçlar, maç öncesi oranlar)
        $auto = [bool](Find-BasketControl 'AutoBox').IsChecked
        $next = $null
        if ($auto) { $next = $(if ($null -eq $script:BasketShared.LastRun) { $script:Started.AddSeconds(10) } elseif ($script:BasketShared.More) { ([datetime]$script:BasketShared.LastRun).AddSeconds(5) } else { ([datetime]$script:BasketShared.LastRun).AddHours(1) }) }
        (Find-BasketControl 'NextText').Text = $(if ($busy) { 'Toplama sürüyor. Program açık kalsın; kapatırsan kaldığı yerden sonra devam eder.' } elseif ($null -ne $next) { 'Sonraki tur: ' + $next.ToString('HH:mm') } else { 'Otomatik toplama kapalı.' })
        if ($auto -and -not $busy -and $null -eq $script:Job -and $null -eq $script:BasketJobs -and $null -ne $next -and (Get-Date) -ge $next) { Start-BCycle }
    } catch {}
})
$script:BasketJobs = $null
$script:BasketBatchRows = @()
$script:BasketBatchMode = 'Maç öncesi'
$script:BasketOffset = 0
$script:BasketDays = 1
$script:BasketHistory = @()
$script:BasketReplay = $null
$script:BasketReplayCodes = $null
$script:BasketReplaySummary = ''
$script:BasketResultsDir = Join-Path $script:DataDir 'AnalizKayitlari'
# 77. düzeltme: arşiv dosyaları pakette Veri_Aktar içinde de olabilir; program klasörü, Veri_Aktar ve kayıt klasörüne sırayla bakılır
function Get-BasketFilePath([string]$name) {
    foreach ($d in @($script:AppDir, (Join-Path $script:AppDir 'Veri_Aktar'), $script:DataDir)) { $p = Join-Path $d $name; if (Test-Path -LiteralPath $p) { return $p } }
    return (Join-Path $script:AppDir $name)
}
$script:BasketPastPath = Get-BasketFilePath 'Basket_Gecmis_Nesine.json'
$script:BasketSeedPath = Join-Path $script:AppDir 'Basket_Skor_Arsivi.csv'
$script:BasketModelPath = Join-Path $script:AppDir 'Basket_Kalibrasyon.json'
$script:BasketForecastPath = Join-Path $script:AppDir 'Basket_Tahmin.ps1'
$script:BasketForecastWorker = $WorkerCode + [Environment]::NewLine + [IO.File]::ReadAllText($script:BasketForecastPath, [Text.Encoding]::UTF8)
. $script:BasketForecastPath
$global:BInv = [Globalization.CultureInfo]::InvariantCulture
$script:BasketShownMatch = $null

function Get-BasketMatchCode([string]$value) {
    $value = $value.Trim()
    if ($value -match '^\d{5,14}$') { return $value }
    $uri = $null
    if (-not [uri]::TryCreate($value, [UriKind]::Absolute, [ref]$uri)) { return }
    if ($uri.Scheme -notin @('https','http') -or $uri.Host -notin @('nesine.com','www.nesine.com','istatistik.nesine.com')) { return }
    $segments = @($uri.Segments | ForEach-Object { $_.Trim('/') } | Where-Object { $_ -match '^\d{5,14}$' })
    if ($segments.Count -gt 0) { return $segments[-1] }
}

function Get-BasketMatchReference([string]$value) {
    $uri = $null
    if ([uri]::TryCreate($value.Trim(), [UriKind]::Absolute, [ref]$uri) -and
        $uri.AbsolutePath -match '^/Iddaa/Mac-Merkezi/(\d{8})/\d{5,14}/2/?$') {
        $day = $Matches[1]
        $providerId = if ($uri.Fragment -match '(?:^#|&)matchId=(\d{5,14})(?:&|$)') { $Matches[1] }
        return @{ Day = $day; ProviderId = [string]$providerId }
    }
}

function Add-BasketLineRow($panel, [string[]]$values, [bool]$heading) {
    $row = [System.Windows.Controls.Primitives.UniformGrid]::new()
    $row.Columns = $values.Count
    $row.Margin = [System.Windows.Thickness]::new(0,0,0,3)
    if ($heading) { $row.Background = [System.Windows.Media.Brushes]::MidnightBlue }
    else { $row.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#182740') }
    foreach ($value in $values) {
        $text = [System.Windows.Controls.TextBlock]::new()
        $text.Text = $value
        $text.Foreground = [System.Windows.Media.Brushes]::White
        $text.Padding = [System.Windows.Thickness]::new(5,8,5,8)
        $text.TextAlignment = 'Center'
        if ($heading) { $text.FontWeight = 'SemiBold' }
        [void]$row.Children.Add($text)
    }
    [void]$panel.Children.Add($row)
}

function Add-BasketMarketRow($panel, [string]$label, [double]$probability, [string]$detail = '', [string]$decision = '') {
    if ($null -eq $panel -or [double]::IsNaN($probability) -or [double]::IsInfinity($probability)) { return }
    $probability = [Math]::Max(0.0, [Math]::Min(100.0, $probability))
    $grid = [System.Windows.Controls.Grid]::new()
    $grid.Margin = [System.Windows.Thickness]::new(0,3,0,3)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[0].Width = [System.Windows.GridLength]::new(155)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[1].Width = [System.Windows.GridLength]::new(1,[System.Windows.GridUnitType]::Star)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[2].Width = [System.Windows.GridLength]::new(88)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[3].Width = [System.Windows.GridLength]::new(112)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[4].Width = [System.Windows.GridLength]::new(72)

    $name = [System.Windows.Controls.TextBlock]::new()
    $name.Text = $label; $name.FontSize = 12.5; $name.VerticalAlignment = 'Center'; $name.TextTrimming = 'CharacterEllipsis'
    [void]$grid.Children.Add($name)

    $bar = [System.Windows.Controls.ProgressBar]::new()
    $bar.Minimum = 0; $bar.Maximum = 100; $bar.Value = $probability; $bar.Height = 9
    $bar.VerticalAlignment = 'Center'; $bar.Margin = [System.Windows.Thickness]::new(8,0,12,0)
    $bar.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#0A1120')
    $bar.BorderThickness = [System.Windows.Thickness]::new(0)
    $bar.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($(if ($probability -ge 100 * $global:BOynaSiniri) { '#22C55E' } elseif ($probability -ge 45) { '#3B82F6' } else { '#475569' }))   # 81: yeşil = OYNA sınırının üstü; sarı yok
    [System.Windows.Controls.Grid]::SetColumn($bar,1); [void]$grid.Children.Add($bar)

    $pct = [System.Windows.Controls.TextBlock]::new()
    $pct.Text = '%' + $probability.ToString('0.0',$script:TrC); $pct.FontSize = 12.5; $pct.FontWeight = 'SemiBold'
    $pct.HorizontalAlignment = 'Right'; $pct.VerticalAlignment = 'Center'; $pct.Margin = [System.Windows.Thickness]::new(0,0,8,0)
    [System.Windows.Controls.Grid]::SetColumn($pct,2); [void]$grid.Children.Add($pct)

    $note = [System.Windows.Controls.TextBlock]::new()
    $note.Text = $detail
    $note.FontSize = 11.5; $note.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#8EA0BC')
    $note.HorizontalAlignment = 'Right'; $note.VerticalAlignment = 'Center'; $note.TextTrimming = 'CharacterEllipsis'
    [System.Windows.Controls.Grid]::SetColumn($note,3); [void]$grid.Children.Add($note)
    $pick = [System.Windows.Controls.TextBlock]::new()
    $pick.Text = $decision; $pick.FontSize = 10.5; $pick.FontWeight = 'Bold'
    $pick.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#86EFAC')
    $pick.HorizontalAlignment = 'Right'; $pick.VerticalAlignment = 'Center'
    [System.Windows.Controls.Grid]::SetColumn($pick,4); [void]$grid.Children.Add($pick)
    [void]$panel.Children.Add($grid)
}

function Add-BasketInfoRow($panel, [string]$label, [string]$value) {
    if ($null -eq $panel -or -not $value) { return }
    $grid = [System.Windows.Controls.Grid]::new()
    $grid.Margin = [System.Windows.Thickness]::new(0,3,0,3)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[0].Width = [System.Windows.GridLength]::new(116)
    $grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
    $grid.ColumnDefinitions[1].Width = [System.Windows.GridLength]::new(1,[System.Windows.GridUnitType]::Star)
    $left = [System.Windows.Controls.TextBlock]::new(); $left.Text = $label
    $left.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#8EA0BC'); $left.FontSize = 11.5
    $right = [System.Windows.Controls.TextBlock]::new(); $right.Text = $value; $right.FontSize = 12.5; $right.TextWrapping = 'Wrap'
    [System.Windows.Controls.Grid]::SetColumn($right,1)
    [void]$grid.Children.Add($left); [void]$grid.Children.Add($right)
    [void]$panel.Children.Add($grid)
}

function Show-BasketModelLines($match, [string]$inputLine = '') {
    $panel = Find-BasketControl 'SingleLines'
    $notice = Find-BasketControl 'LinesNotice'
    try {
        if ($null -eq $script:BasketDisplayErrors) {
            $model = ConvertFrom-Json ([IO.File]::ReadAllText($script:BasketModelPath,[Text.Encoding]::UTF8))
            $script:BasketDisplayErrors = [double[]]$model.errors
        }
        $culture = [Globalization.CultureInfo]::GetCultureInfo('tr-TR')
        $expected = Read-BNumber $match.Expected
        if ($null -eq $expected -or $script:BasketDisplayErrors.Length -lt 100) { throw 'Model çizgileri hesaplanamadı.' }
        if ($inputLine) {
            $entered = Read-BNumber $inputLine
            if ($null -eq $entered -or $entered -le 0 -or [Math]::Abs(($entered % 1) - 0.5) -gt 0.000001) {
                $notice.Text = '165,5 gibi buçuklu bir sayı çizgisi gir.'
                return
            }
            $values = @($entered)
        } else {
            $center = [Math]::Floor($expected) + 0.5
            $values = @(foreach ($shift in @(-10,-5,0,5,10)) {
                $line = $center + $shift
                if ($line -gt 0) { $line }
            })
        }
        $panel.Children.Clear()
        (Find-BasketControl 'MarketTotalRows').Children.Clear()
        $notice.Text = 'Kayıtlı site çizgisi yok. Aşağıdaki çizgiler modelin karşılaştırma eşikleridir.'
        $actual = Read-BNumber $match.Actual
        if ($null -ne $actual) {
            Add-BasketLineRow $panel @('Tahmini toplam','Gerçek toplam','Tahmin farkı') $true
            Add-BasketLineRow $panel @($expected.ToString('0.00',$culture), $actual.ToString('0.##',$culture),
                ($expected - $actual).ToString('+0.00;-0.00;0.00',$culture)) $false
        }
        Add-BasketLineRow $panel @('Model çizgisi','Alt ihtimali','Üst ihtimali','Gerçek sonuç') $true
        foreach ($line in $values) {
            $under = Get-BUnderProbability $script:BasketDisplayErrors ($line - $expected)
            $actualSide = if ($null -eq $actual) { '—' } elseif ($actual -lt $line) { 'Alt' } else { 'Üst' }
            $altText = '%' + (100 * $under).ToString('0.0',$culture)
            $ustText = '%' + (100 * (1 - $under)).ToString('0.0',$culture)
            Add-BasketLineRow $panel @($line.ToString('0.0',$culture),$altText,$ustText,$actualSide) $false
            Add-BasketMarketRow (Find-BasketControl 'MarketTotalRows') ($line.ToString('0.0',$culture) + ' Alt') (100 * $under) 'Model çizgisi'
            Add-BasketMarketRow (Find-BasketControl 'MarketTotalRows') ($line.ToString('0.0',$culture) + ' Üst') (100 * (1 - $under)) 'Model çizgisi'
        }
    } catch { $notice.Text = $_.Exception.Message }
}

function Set-BasketMatch($row, [string]$message = '') {
    $panel = Find-BasketControl 'SingleLines'
    $notice = Find-BasketControl 'LinesNotice'
    $panel.Children.Clear()
    foreach ($name in @('TeamStats','MarketTotalRows','MarketWinnerRows','MarketTeamRows','MarketScoreRows')) {
        (Find-BasketControl $name).Children.Clear()
    }
    $script:BasketShownMatch = $null
    (Find-BasketControl 'ModelLineControls').Visibility = 'Collapsed'
    (Find-BasketControl 'ModelLineInput').Clear()
    $notice.Text = $message
    (Find-BasketControl 'WorkStatus').Text = $message
    foreach ($name in @('MatchTitle','MatchLeague','MatchDecision','MatchModelView','MatchResult','MatchLikelyScore','MatchTotal','MatchActual','CandidateProbabilityText','CandidateOddsText','MatchFormSummary')) { (Find-BasketControl $name).Text = '' }
    (Find-BasketControl 'CandidateBadge').Text = 'MAÇ TAHMİNİ'
    (Find-BasketControl 'CandidateCard').Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#111B2E')
    if ($null -eq $row) { return }
    (Find-BasketControl 'MatchTitle').Text = "$($row.Home) – $($row.Away)"
    (Find-BasketControl 'MatchLeague').Text = "$($row.Time) · $($row.League)"
    (Find-BasketControl 'WorkStatus').Text = [string]$row.Status
    (Find-BasketControl 'MatchModelView').Text = [string]$row.ModelView
    (Find-BasketControl 'MatchFormSummary').Text = [string]$row.Status
    # 78. düzeltme: karar Nesine oranından (Set-BKarar · Basket_Tahmin.ps1); kayıttan açılan maç da aynı hesaptan geçer
    Set-BKarar $row
    if ($row.Candidate -and $row.Karar) {
        $play = $row.Karar -eq 'OYNA'
        (Find-BasketControl 'CandidateBadge').Text = $(if ($play) { '★ OYNA' } else { 'OYNAMA · %' + [int](100 * $global:BOynaSiniri) + ' altı' })
        (Find-BasketControl 'CandidateCard').Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString($(if ($play) { '#123522' } else { '#1E2B44' }))
        $pickText = [string]$row.Candidate
        if ($pickText -eq 'MS 1') { $pickText = "$($row.Home) kazanır (MS 1)" } elseif ($pickText -eq 'MS 2') { $pickText = "$($row.Away) kazanır (MS 2)" }
        (Find-BasketControl 'MatchDecision').Text = $(if ($play) { $pickText } else { 'En iyi: ' + $pickText })
        if ($null -ne $row.CandidateProbability) {
            (Find-BasketControl 'CandidateProbabilityText').Text = '%' + (100 * [double]$row.CandidateProbability).ToString('0.0',$script:TrC)
        }
        if ($null -ne $row.CandidateOdds) {
            $oddsSource = if ([string]$row.Code -match '^\d+$') { 'Site oranı ' } else { 'Flashscore oranı ' }
            (Find-BasketControl 'CandidateOddsText').Text = $oddsSource + ([double]$row.CandidateOdds).ToString('0.00',$script:TrC) + $(if ($row.KararSonuc) { ' · ' + $row.KararSonuc } else { '' })
        }
    } else {
        (Find-BasketControl 'MatchDecision').Text = 'Oynanacak bahis yok'
        (Find-BasketControl 'CandidateOddsText').Text = 'Site oranı yok ya da hepsi 1,30 altında.'
    }
    if ($null -ne $row.HomeWinProbability -and $null -ne $row.AwayWinProbability) {
        $homePct = (100 * [double]$row.HomeWinProbability).ToString('0.0',$script:TrC)
        $awayPct = (100 * [double]$row.AwayWinProbability).ToString('0.0',$script:TrC)
        (Find-BasketControl 'MatchResult').Text = "Maç sonucu · Ev %$homePct  |  Deplasman %$awayPct"
        $msPlay = $row.Karar -eq 'OYNA'
        Add-BasketMarketRow (Find-BasketControl 'MarketWinnerRows') "$($row.Home) kazanır" (100 * [double]$row.HomeWinProbability) $(if ($row.WinnerHome) { 'Oran ' + [string]$row.WinnerHome } else { '' }) $(if ($msPlay -and $row.Candidate -eq 'MS 1') { '★ OYNA' } else { '' })
        Add-BasketMarketRow (Find-BasketControl 'MarketWinnerRows') "$($row.Away) kazanır" (100 * [double]$row.AwayWinProbability) $(if ($row.WinnerAway) { 'Oran ' + [string]$row.WinnerAway } else { '' }) $(if ($msPlay -and $row.Candidate -eq 'MS 2') { '★ OYNA' } else { '' })
    }   # 109: baskette MS yok (bölüm gizli)
    if ($row.ProjectedScore) {
        $scoreText = if ($row.LikelyScores -and $row.LikelyScores.Count -gt 0) { $row.LikelyScores -join '  /  ' } else { "$($row.ProjectedScore.Home)–$($row.ProjectedScore.Away)" }
        (Find-BasketControl 'MatchLikelyScore').Text = 'Olası skorlar · ' + $scoreText
    }
    if ($row.Expected) { (Find-BasketControl 'MatchTotal').Text = "Tahmini toplam sayı · $($row.Expected)" }
    if ([string]$row.Actual) {
        $actualNumber = Read-BNumber $row.Actual
        $expectedNumber = Read-BNumber $row.Expected
        $differenceText = if ($null -ne $actualNumber -and $null -ne $expectedNumber) { ' · fark ' + ($expectedNumber - $actualNumber).ToString('+0.00;-0.00;0.00',$script:TrC) } else { '' }
        (Find-BasketControl 'MatchActual').Text = "Gerçek toplam sayı · $($row.Actual)$differenceText"
    }

    if ($row.HomeSampleCount -or $row.AwaySampleCount) {
        Add-BasketInfoRow (Find-BasketControl 'TeamStats') 'Ev iç saha' ("$($row.HomeSampleCount) maç · atılan $($row.HomeRecentFor) · yenilen $($row.HomeRecentAgainst)")
        Add-BasketInfoRow (Find-BasketControl 'TeamStats') 'Dep. dış saha' ("$($row.AwaySampleCount) maç · atılan $($row.AwayRecentFor) · yenilen $($row.AwayRecentAgainst)")
    }
    if ($row.ProjectedHome) { Add-BasketInfoRow (Find-BasketControl 'MarketTeamRows') $row.Home ("Tahmini sayı $($row.ProjectedHome) · iç saha ort. $($row.HomeRecentFor) atılan / $($row.HomeRecentAgainst) yenilen") }
    if ($row.ProjectedAway) { Add-BasketInfoRow (Find-BasketControl 'MarketTeamRows') $row.Away ("Tahmini sayı $($row.ProjectedAway) · dış saha ort. $($row.AwayRecentFor) atılan / $($row.AwayRecentAgainst) yenilen") }

    foreach ($score in @($row.LikelyScoreRows | Select-Object -First 3)) {
        if ($null -ne $score -and $null -ne $score.Probability) {
            Add-BasketMarketRow (Find-BasketControl 'MarketScoreRows') ([string]$score.Score) ([double]$score.Probability) 'Simülasyon payı'
        }
    }
    if ((Find-BasketControl 'MarketScoreRows').Children.Count -eq 0) {
        Add-BasketInfoRow (Find-BasketControl 'MarketScoreRows') 'Olası skorlar' 'Yeterli skor örneği bulunamadı.'
    }

    $items = @($row.Lines | Where-Object { $null -ne $_ -and [string]$_.Line })
    if ($items.Count -eq 0) {
        if ($row.Expected -and -not $row.LimitedHistory) {
            $script:BasketShownMatch = $row
            (Find-BasketControl 'ModelLineControls').Visibility = 'Visible'
            Show-BasketModelLines $row
        } else {
            $notice.Text = if ($row.Status) { [string]$row.Status } else { 'Bu maç için yeterli veri bulunamadı.' }
        }
        return
    }
    # 95. düzeltme: Nesine'nin bütün alternatif çizgileri (203,5 ... 248,5) yerine programın tahmini toplamına (yoksa ana çizgiye) en yakın 7 çizgi;
    # OYNA çizgisi her zaman listede. Karar bütün çizgilerden verilir, yalnız ekran sadeleşti.
    if ($items.Count -gt 7) {
        $center = Read-BNumber $row.Expected
        if ($null -eq $center) {
            $mainL = $items | Where-Object { $null -ne (Read-BNumber $_.UnderOdds) -and $null -ne (Read-BNumber $_.OverOdds) } | Sort-Object { [Math]::Abs((Read-BNumber $_.UnderOdds) - (Read-BNumber $_.OverOdds)) } | Select-Object -First 1
            if ($null -ne $mainL) { $center = Read-BNumber $mainL.Line }
        }
        if ($null -ne $center) {
            $near = @($items | Where-Object { $null -ne (Read-BNumber $_.Line) } | Sort-Object { [Math]::Abs((Read-BNumber $_.Line) - $center) } | Select-Object -First 7)
            if ($row.Karar -eq 'OYNA') {
                $candItem = $items | Where-Object { [string]$row.Candidate -eq ([string]$_.Line + ' Alt') -or [string]$row.Candidate -eq ([string]$_.Line + ' Üst') } | Select-Object -First 1
                if ($null -ne $candItem -and $near -notcontains $candItem) { $near += $candItem }
            }
            $items = @($near | Sort-Object { Read-BNumber $_.Line })
        }
    }
    $notice.Text = if ($row.LimitedHistory) { 'İç/dış saha verisi sınırlı; çizgi olasılıkları gösterilmiyor.' } elseif ($row.Expected) { '' } else { [string]$row.Status }
    Add-BasketLineRow $panel @('Çizgi','Alt ihtimali','Alt oranı','Üst ihtimali','Üst oranı','Gerçek') $true
    $actualTotal = Read-BNumber $row.Actual
    foreach ($line in $items) {
        $altText = if ([string]$line.Under) { '%' + $line.Under } else { '—' }
        $ustText = if ([string]$line.Over) { '%' + $line.Over } else { '—' }
        $lineNumber = Read-BNumber $line.Line
        $actualSide = if ($null -eq $actualTotal -or $null -eq $lineNumber) { '—' } elseif ($actualTotal -lt $lineNumber) { 'Alt tuttu' } else { 'Üst tuttu' }
        Add-BasketLineRow $panel @([string]$line.Line,$altText,[string]$line.UnderOdds,$ustText,[string]$line.OverOdds,$actualSide) $false

        if ($null -ne $lineNumber -and [string]$line.Under) {
            $underProbability = Read-BNumber $line.Under
            $overProbability = Read-BNumber $line.Over
            if ($null -ne $underProbability) {
                $decision = if ($row.Karar -eq 'OYNA' -and [string]$row.Candidate -eq "$($line.Line) Alt") { '★ OYNA' } else { '' }
                $detail = if ($line.UnderOdds) { 'Oran ' + [string]$line.UnderOdds } else { '' }
                Add-BasketMarketRow (Find-BasketControl 'MarketTotalRows') "$($line.Line) Alt" $underProbability $detail $decision
            }
            if ($null -ne $overProbability) {
                $decision = if ($row.Karar -eq 'OYNA' -and [string]$row.Candidate -eq "$($line.Line) Üst") { '★ OYNA' } else { '' }
                $detail = if ($line.OverOdds) { 'Oran ' + [string]$line.OverOdds } else { '' }
                Add-BasketMarketRow (Find-BasketControl 'MarketTotalRows') "$($line.Line) Üst" $overProbability $detail $decision
            }
        }
    }
    if ((Find-BasketControl 'MarketTotalRows').Children.Count -eq 0) {
        Add-BasketInfoRow (Find-BasketControl 'MarketTotalRows') 'Toplam sayı' $(if ($row.LimitedHistory) { 'İç/dış saha verisi sınırlı; yüzde gösterilmiyor.' } else { 'Alt/Üst çizgisi oranı bu maçta bulunamadı.' })
    }
}

function Save-BasketAnalysis($rows) {
    if (@($rows | Where-Object Expected).Count -eq 0) { return }
    [void][IO.Directory]::CreateDirectory($script:BasketResultsDir)
    foreach ($r in $rows) {
        if (-not $r.Expected -or [string]$r.Code -notmatch '^\d{5,14}$') { continue }
        $dateKey = [string]$r.Time -replace '[^0-9]',''
        $path = Join-Path $script:BasketResultsDir ("$($r.Code)_$dateKey.json")
        if (Test-Path -LiteralPath $path) { continue } # İlk maç öncesi tahmini sabit kalır.
        $tmp = $path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
        try {
            [IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $r -Depth 7 -Compress), [Text.UTF8Encoding]::new($false))
            try { [IO.File]::Move($tmp, $path) } catch { if (-not (Test-Path -LiteralPath $path)) { throw } }
        } finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force } }
    }
}

# 93. düzeltme: programın verdiği EN SON kararlar tek dosyada (basket_son_karar.csv). Futbol programının Bugün sekmesi, telefon ve Telegram
# bu dosyayı okur: basketbol penceresinde kaç OYNA varsa orada da aynısı görünür (eskiden bülteni ayrıca hesaplıyordu, oran saati farkıyla 16 ↔ 13 oldu).
# Dosya yalnız eklenir; aynı maç yeniden analiz edilince son satır geçerlidir. 3 MB'ı geçerse 3 günden eski maçlar ayıklanır.
function Save-BasketSonKarar($rows) {
    try {
        $p = Join-Path $script:DataDir 'basket_son_karar.csv'
        $inv = [System.Globalization.CultureInfo]::InvariantCulture
        $st = [System.Globalization.NumberStyles]::Float
        $stamp = (Get-Date).ToString('yyyy-MM-dd HH:mm', $inv)
        $sb = New-Object System.Text.StringBuilder
        foreach ($r in @($rows)) {
            if ($null -eq $r -or [string]$r.Mode -ne 'Maç öncesi' -or [string]$r.Code -notmatch '^\d{5,14}$') { continue }
            $t = [DateTimeOffset]::MinValue
            if (-not [DateTimeOffset]::TryParseExact(([string]$r.Time + ' +03:00'), 'yyyy-MM-dd HH:mm zzz', $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t)) { continue }
            $pp = ''; $x = 0.0
            if ($null -ne $r.CandidateProbability -and [double]::TryParse(([string]$r.CandidateProbability).Replace(',', '.'), $st, $inv, [ref]$x)) { $pp = $x.ToString('0.0000', $inv) }
            $oo = ''; $y = 0.0
            if ($null -ne $r.CandidateOdds -and [double]::TryParse(([string]$r.CandidateOdds).Replace(',', '.'), $st, $inv, [ref]$y)) { $oo = $y.ToString('0.00', $inv) }
            $f = @([string]$r.Code, [string]$t.ToUnixTimeSeconds(), [string]$r.Home, [string]$r.Away, [string]$r.League, [string]$r.Karar, [string]$r.Candidate, $pp, $oo, $stamp) | ForEach-Object { ([string]$_ -replace '[;\r\n]+', ' ').Trim() }
            [void]$sb.Append(($f -join ';') + "`r`n")
        }
        if ($sb.Length -eq 0) { return }
        if (-not (Test-Path -LiteralPath $p)) { [IO.File]::WriteAllText($p, "kod;mac_epoch;ev;dep;lig;karar;bahis;yuzde;oran;guncelleme`r`n", (New-Object System.Text.UTF8Encoding $true)) }
        elseif ((Get-Item -LiteralPath $p).Length -gt 3MB) {
            $limit = [DateTimeOffset]::UtcNow.AddDays(-3).ToUnixTimeSeconds()
            $all = [IO.File]::ReadAllLines($p, [Text.Encoding]::UTF8)
            $keep = New-Object System.Collections.ArrayList; [void]$keep.Add($all[0].TrimStart([char]0xFEFF))
            for ($i = 1; $i -lt $all.Count; $i++) { $c = $all[$i].Split(';'); $e = 0L; if ($c.Count -ge 10 -and [long]::TryParse($c[1], [ref]$e) -and $e -ge $limit) { [void]$keep.Add($all[$i]) } }
            [IO.File]::WriteAllText($p, (($keep -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding $true))
        }
        [IO.File]::AppendAllText($p, $sb.ToString(), (New-Object System.Text.UTF8Encoding $false))
    } catch {}
}

function Initialize-BasketReplay {
    if ($null -ne $script:BasketReplay) { return }
    $folder = Get-BasketFilePath 'Basket_Arsiv_Testi'
    $script:BasketReplayCodes = New-Object 'System.Collections.Generic.HashSet[string]'
    $script:BasketReplay = @(if (Test-Path -LiteralPath $folder) {
        foreach ($file in (Get-ChildItem -LiteralPath $folder -Filter '*.json' -File | Sort-Object Name)) {
            foreach ($r in (ConvertFrom-Json ([IO.File]::ReadAllText($file.FullName, [Text.Encoding]::UTF8)))) {
                [void]$script:BasketReplayCodes.Add([string]$r.Code)
                # 115: Add-Member yerine doğrudan özellik (7.677 satırda birkaç kat hızlı; ekran donmasın)
                if ($null -eq $r.PSObject.Properties['RecordSource']) { $r.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new('RecordSource', $r.ReplaySource)) } else { $r.RecordSource = $r.ReplaySource }
                $r
            }
        }
    })
    # 78. düzeltme: arşivdeki maçlara da yeni karar (eski adaylar dosyada kalır, ekranda yeni karar).
    # 7.677 maçı her açılışta hesaplamak birkaç saniye sürdüğü için Basket_Arsiv_Karar.csv'de hazır gelir; listede olmayan maç burada hesaplanır.
    $cache = @{}
    $cachePath = Get-BasketFilePath 'Basket_Arsiv_Karar.csv'
    # 136: hücre denetiminin ekleri girince sürüm değişiyor, paketteki hazır liste tutmuyordu; 7.677 maç her açılışta yeniden hesaplanıyordu.
    # Artık hesaplanan kararlar kayıt klasöründe (basket_arsiv_karar_hucre.csv) o sürümle saklanır; aynı ekler kaldıkça sonraki açılışlar beklemez.
    $cachePath2 = Join-Path $script:DataDir 'basket_arsiv_karar_hucre.csv'
    foreach ($cp in @($cachePath, $cachePath2)) {
        if (-not (Test-Path -LiteralPath $cp)) { continue }
        # sütunlar: anahtar;surum;karar;karar_yazi;aday;yuzde;oran;sonuc
        try {
            foreach ($line in [IO.File]::ReadAllLines($cp, [Text.Encoding]::UTF8)) {
                $c = $line.Split(';')
                if ($c.Count -eq 8 -and $c[1] -eq $global:BKararSurum) { $cache[$c[0]] = $c }
            }
        } catch {}
    }
    $inv = [Globalization.CultureInfo]::InvariantCulture
    $yeniHesap = 0
    foreach ($r in $script:BasketReplay) {
        $c = $cache[$r.ReplaySource + '|' + $r.Code + '|' + $r.Time]
        if ($null -eq $c) { Set-BKarar $r -SadeceKarar; $yeniHesap++; continue }
        $props = $r.PSObject.Properties
        if ($null -eq $props['KararSonuc']) {
            foreach ($n in @('Candidate','CandidateProbability','CandidateOdds','Edge','Karar','KararText','KararSonuc')) {
                if ($null -eq $props[$n]) { $props.Add([System.Management.Automation.PSNoteProperty]::new($n, $null)) }
            }
        }
        $r.Candidate = $c[4]; $r.Edge = 0.0; $r.Karar = $c[2]; $r.KararText = $c[3]; $r.KararSonuc = $c[7]
        $r.CandidateProbability = if ($c[5]) { [double]::Parse($c[5], $inv) } else { $null }
        $r.CandidateOdds = if ($c[6]) { [double]::Parse($c[6], $inv) } else { $null }
    }
    if ($yeniHesap -gt 0 -and [string]$global:BKararSurum -ne '109') {
        try {
            $sb = New-Object System.Text.StringBuilder
            [void]$sb.AppendLine('anahtar;surum;karar;karar_yazi;aday;yuzde;oran;sonuc')
            foreach ($r in $script:BasketReplay) {
                $pr = if ($null -ne $r.CandidateProbability -and [string]$r.CandidateProbability) { ([double]$r.CandidateProbability).ToString('R', $inv) } else { '' }
                $od = if ($null -ne $r.CandidateOdds -and [string]$r.CandidateOdds) { ([double]$r.CandidateOdds).ToString('R', $inv) } else { '' }
                [void]$sb.Append(([string]$r.ReplaySource + '|' + [string]$r.Code + '|' + [string]$r.Time).Replace(';', ',')).Append(';').Append([string]$global:BKararSurum).Append(';')
                [void]$sb.Append(([string]$r.Karar).Replace(';', ',')).Append(';').Append(([string]$r.KararText).Replace(';', ',')).Append(';').Append(([string]$r.Candidate).Replace(';', ',')).Append(';')
                [void]$sb.Append($pr).Append(';').Append($od).Append(';').AppendLine(([string]$r.KararSonuc).Replace(';', ','))
            }
            $tmp = $cachePath2 + '.tmp'
            [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object System.Text.UTF8Encoding $true))
            if (Test-Path -LiteralPath $cachePath2) { Remove-Item -LiteralPath $cachePath2 -Force }
            Move-Item -LiteralPath $tmp -Destination $cachePath2 -Force
        } catch {}
    }
}

function Get-BasketOynaSummary($rows, [string]$name) {
    $done = @($rows | Where-Object { $_.Karar -eq 'OYNA' -and $_.KararSonuc })
    if ($done.Count -eq 0) { return "$name · biten OYNA yok" }
    $wins = @($done | Where-Object KararSonuc -eq 'Tuttu').Count
    $last = @($done | Sort-Object Time -Descending | Select-Object -First 20)
    $lastWins = @($last | Where-Object KararSonuc -eq 'Tuttu').Count
    return "$name · OYNA $($done.Count) bitti, $wins tuttu (%$([Math]::Round(100.0 * $wins / $done.Count))) · son $($last.Count) maçta $lastWins"
}

function Show-BasketRecordGrid {
    $q = (Find-BasketControl 'RecordSearch').Text.Trim()
    $filter = (Find-BasketControl 'RecordFilter').SelectedIndex
    (Find-BasketControl 'RecordSummary').Text = $script:BasketReplaySummary
    (Find-BasketControl 'RecordGrid').ItemsSource = @($script:BasketHistory | Where-Object {
        ($filter -le 0 -or ($filter -eq 1 -and $_.ReplaySource -eq 'Flashscore') -or
            ($filter -eq 2 -and $_.ReplaySource -eq 'Nesine') -or ($filter -eq 3 -and $_.RecordSource -eq 'Kaydedilen')) -and
        ("$($_.Code) $($_.Home) $($_.Away) $($_.League)").IndexOf($q, [StringComparison]::CurrentCultureIgnoreCase) -ge 0
    })
}

function Get-BasketFinishedRows {
    $seen = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($r in $script:BasketHistory) {
        if ([string]$r.Actual -and $seen.Add([string]$r.Code)) { $r }
    }
}

# 115. düzeltme: kayıtlar ekranı her sekme değişiminde ve her tek maç analizinde baştan okunuyordu (8 bin satır, eski bilgisayarda
# onlarca saniye) ve pencere "Yanıt vermiyor"a düşüyordu. Artık dosyalar değişmediyse yeniden okunmaz; "Yenile" her zaman okur.
$script:BasketRecordStamp = ''
function Get-BasketRecordStamp {
    $parts = New-Object 'System.Collections.Generic.List[string]'
    foreach ($p in @($script:BasketPastPath, (Get-BasketFilePath 'Basket_Gecmis_Flashscore.json'), (Join-Path $script:DataDir 'basket_nesine_sonuclar.csv'), (Get-BasketFilePath 'Basket_Nesine_Skor_Arsivi.csv'))) {
        try { $fi = New-Object System.IO.FileInfo $p; if ($fi.Exists) { $parts.Add([string]$fi.Length + ':' + [string]$fi.LastWriteTimeUtc.Ticks) } else { $parts.Add('-') } } catch { $parts.Add('?') }
    }
    try {
        $n = 0; $mx = 0L
        if (Test-Path -LiteralPath $script:BasketResultsDir) { foreach ($f in [IO.Directory]::EnumerateFiles($script:BasketResultsDir, '*.json')) { $n++; $t = [IO.File]::GetLastWriteTimeUtc($f).Ticks; if ($t -gt $mx) { $mx = $t } } }
        $parts.Add([string]$n + ':' + [string]$mx)
    } catch { $parts.Add('?') }
    return ($parts -join '|')
}
function Read-BasketRecords([switch]$Force) {
    $stamp = ''; try { $stamp = Get-BasketRecordStamp } catch { $stamp = '' }
    if (-not $Force -and $stamp -and $stamp -eq $script:BasketRecordStamp -and @($script:BasketHistory).Count -gt 0) { Show-BasketRecordGrid; return }
    try { Set-UiIs 'basketbol kayıtları okunuyor' } catch {}   # 117: futbol penceresinin takılma günlüğü için (tek başına açılınca yok sayılır)
    Initialize-BasketReplay
    $rows = New-Object 'System.Collections.Generic.List[object]'
    $flashPastPath = Get-BasketFilePath 'Basket_Gecmis_Flashscore.json'
    foreach ($path in @($script:BasketPastPath, $flashPastPath)) {
        if (Test-Path -LiteralPath $path) {
            $past = ConvertFrom-Json ([IO.File]::ReadAllText($path, [Text.Encoding]::UTF8))
            foreach ($r in $past) {
                if ($script:BasketReplayCodes.Contains([string]$r.Code)) { continue }
                if ($null -eq $r.PSObject.Properties['RecordSource']) { $r.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new('RecordSource', 'Eski arşiv')) } else { $r.RecordSource = 'Eski arşiv' }
                $rows.Add($r)
            }
        }
    }
    if (Test-Path -LiteralPath $script:BasketResultsDir) {
        foreach ($file in (Get-ChildItem -LiteralPath $script:BasketResultsDir -Filter '*.json' -File)) {
            try {
                $r = ConvertFrom-Json ([IO.File]::ReadAllText($file.FullName, [Text.Encoding]::UTF8))
                if ($null -eq $r.PSObject.Properties['RecordSource']) { $r.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new('RecordSource', 'Kaydedilen')) } else { $r.RecordSource = 'Kaydedilen' }
                $rows.Add($r)
            } catch {}
        }
    }
    $scores = @{}
    # 78: Nesine skor arşivi de okunur; maç sonucu kararının tuttuğunu görmek için ev ve deplasman sayısı ayrı tutulur
    foreach ($scorePath in @((Join-Path $script:DataDir 'basket_nesine_sonuclar.csv'), (Get-BasketFilePath 'Basket_Nesine_Skor_Arsivi.csv'))) {
        if (-not (Test-Path -LiteralPath $scorePath)) { continue }
        foreach ($r in (Import-Csv -LiteralPath $scorePath -Delimiter ';' -Encoding UTF8)) {
            if ($r.kod -and $r.skor_ev -match '^\d+$' -and $r.skor_dep -match '^\d+$' -and -not $scores.ContainsKey($r.kod)) { $scores[$r.kod] = $r }
        }
    }
    foreach ($r in $rows) {
        $score = $scores[[string]$r.Code]
        if ($null -eq $score) { continue }
        $savedTime = [datetime]::MinValue; $scoreTime = [datetime]::MinValue
        $culture = [Globalization.CultureInfo]::InvariantCulture
        $styles = [Globalization.DateTimeStyles]::None
        if ([datetime]::TryParseExact([string]$r.Time,'yyyy-MM-dd HH:mm',$culture,$styles,[ref]$savedTime) -and
            [datetime]::TryParseExact([string]$score.zaman,'yyyy-MM-dd HH:mm',$culture,$styles,[ref]$scoreTime) -and
            [Math]::Abs(($savedTime - $scoreTime).TotalMinutes) -le 90) {
            if (-not [string]$r.Actual) { $r.Actual = [int]$score.skor_ev + [int]$score.skor_dep }
            Set-BProp $r 'ActualHome' ([int]$score.skor_ev); Set-BProp $r 'ActualAway' ([int]$score.skor_dep)
        }
    }
    foreach ($r in $rows) { Set-BKarar $r }
    $script:BasketHistory = @((@($rows.ToArray()) + $script:BasketReplay) | Sort-Object Time -Descending)
    $unique = @(Get-BasketFinishedRows)
    $script:BasketReplaySummary = (Get-BasketOynaSummary @($unique | Where-Object { [string]$_.Code -match '^\d+$' }) 'Site oranlı') + '  |  ' +
        (Get-BasketOynaSummary @($unique | Where-Object { [string]$_.Code -notmatch '^\d+$' }) 'Flashscore oranlı arşiv')
    Show-BasketRecordGrid
    $leagueRows = @(Get-BasketFinishedRows |
        Group-Object League |
        Sort-Object Count -Descending | ForEach-Object {
            [pscustomobject]@{ League = $_.Name; Count = $_.Count
                Average = [Math]::Round(($_.Group | Measure-Object Actual -Average).Average, 1) }
        })
    (Find-BasketControl 'LeagueGrid').ItemsSource = $leagueRows
    $script:BasketRecordStamp = $stamp
}

function Set-BasketBatch($rows) {
    $script:BasketBatchRows = @($rows)
    (Find-BasketControl 'BatchGrid').ItemsSource = $script:BasketBatchRows
    $withForecast = @($rows | Where-Object Expected).Count
    $withoutForecast = $rows.Count - $withForecast
    $picks = @($rows | Where-Object { $_.Karar -eq 'OYNA' -and $_.Mode -eq 'Maç öncesi' } | Sort-Object CandidateProbability -Descending)
    $limitedCount = @($rows | Where-Object LimitedHistory).Count
    $standardCount = $withForecast - $limitedCount
    (Find-BasketControl 'BatchStatus').Text = "$($rows.Count) maç · $($picks.Count) OYNA · $(@($rows | Where-Object Karar -eq 'OYNAMA').Count) OYNAMA · $(@($rows | Where-Object { -not $_.Karar }).Count) oran yok"
    for ($i = 0; $i -lt $picks.Count; $i++) {
        $picks[$i] | Add-Member -NotePropertyName CouponGroup -NotePropertyValue (1 + [Math]::Floor($i / 20.0)) -Force
    }
    (Find-BasketControl 'SuggestionGrid').ItemsSource = $picks
    (Find-BasketControl 'SuggestionsStatus').Text = "$($picks.Count) OYNA · yüzdesi yüksekten düşüğe, 20'lik kuponlara bölündü"
}

function Show-BasketSelected([string]$gridName) {
    $r = (Find-BasketControl $gridName).SelectedItem
    if ($null -eq $r) { return }
    (Find-BasketControl 'MainTabs').SelectedIndex = 0
    (Find-BasketControl 'UrlBox').Text = [string]$r.Code
    if ($r.Mode -eq 'Geçmiş maç' -or [string]$r.Actual) { (Find-BasketControl 'ModePast').IsChecked = $true }
    else { (Find-BasketControl 'ModePre').IsChecked = $true }
    Set-BasketMatch $r
}

function Set-BasketButtons([bool]$enabled) {
    foreach ($id in @('RefreshButton','ListFetch','BatchStart')) { (Find-BasketControl $id).IsEnabled = $enabled }
}

# 120. düzeltme: KAYITLAR ARKA PLANDA OKUNUR. 117'nin takılma günlüğü gösterdi: basketbol kayıtlarını okumak (7.677 arşiv maçı + 700+ kayıt + skor
# dosyaları) senin bilgisayarında 13-31 saniye pencereyi donduruyordu; toplayıcı dosyaları sürekli güncellediği için 115'teki "değişmediyse okuma"
# çoğu zaman işe yaramıyordu. Artık sekmeye gelince ve "Yenile"de okuma AYRI iş parçacığında yapılır (Read-BasketRecords'un kendisi, aynı sonuç);
# bitince liste ekrana konur. Okunurken eski liste görünür kalır. Tek maç analizi kayıtları beklemez (maç öncesi analizde kayda bakmak gerekmiyor).
$script:BasketRecJob = $null
function Start-BasketRecordLoad([switch]$Force) {
    if ($null -ne $script:BasketRecJob) { return }
    $stamp = ''; try { $stamp = Get-BasketRecordStamp } catch { $stamp = '' }
    if (-not $Force -and $stamp -and $stamp -eq $script:BasketRecordStamp -and @($script:BasketHistory).Count -gt 0) { Show-BasketRecordGrid; return }
    try { (Find-BasketControl 'RecordSummary').Text = 'Kayıtlar okunuyor (arka planda; pencere kullanılabilir)…' + $(if ($script:BasketReplaySummary) { '   ' + $script:BasketReplaySummary } else { '' }) } catch {}
    $rs = $null; $ps = $null
    try {
        $src = [IO.File]::ReadAllText((Join-Path $script:AppDir 'BasketAnalizMerkezi.ps1'), [Text.Encoding]::UTF8)
        $ast = [System.Management.Automation.Language.Parser]::ParseInput($src, [ref]$null, [ref]$null)
        $want = @('Get-BasketFilePath', 'Initialize-BasketReplay', 'Read-BasketRecords', 'Get-BasketRecordStamp', 'Get-BasketFinishedRows', 'Get-BasketOynaSummary')
        $sb = New-Object System.Text.StringBuilder
        [void]$sb.AppendLine('param($p)')
        [void]$sb.AppendLine($script:BasketForecastWorker)
        foreach ($f in $ast.EndBlock.Statements) { if ($f -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $want -contains $f.Name) { [void]$sb.AppendLine($f.Extent.Text) } }
        [void]$sb.AppendLine('function Show-BasketRecordGrid { }')
        [void]$sb.AppendLine('$global:BRecCtl = @{}')
        [void]$sb.AppendLine('function Find-BasketControl($n) { if (-not $global:BRecCtl.ContainsKey($n)) { $global:BRecCtl[$n] = [pscustomobject]@{ Text = ''''; ItemsSource = $null; SelectedIndex = 0 } }; return $global:BRecCtl[$n] }')
        [void]$sb.AppendLine('$script:AppDir = $p.AppDir; $script:DataDir = $p.DataDir; $script:BasketResultsDir = $p.ResultsDir; $script:BasketPastPath = $p.PastPath')
        [void]$sb.AppendLine('$script:BasketReplay = $p.Replay; $script:BasketReplayCodes = $p.ReplayCodes; $script:BasketHistory = @(); $script:BasketRecordStamp = ''''')
        [void]$sb.AppendLine('Read-BasketRecords -Force')
        [void]$sb.AppendLine('return @{ History = $script:BasketHistory; Replay = $script:BasketReplay; ReplayCodes = $script:BasketReplayCodes; Summary = $script:BasketReplaySummary; League = (Find-BasketControl ''LeagueGrid'').ItemsSource }')
        $rs = [runspacefactory]::CreateRunspace(); $rs.Open()
        $rs.SessionStateProxy.SetVariable('Shared', [hashtable]::Synchronized(@{ DataDir = $script:DataDir; Delay = 1500; Req = 0; LogPath = (Join-Path $script:DataDir 'basket_tahmin_log.txt'); Lines = (New-Object System.Collections.ArrayList) }))
        $ps = [powershell]::Create(); $ps.Runspace = $rs
        $prm = @{ AppDir = $script:AppDir; DataDir = $script:DataDir; ResultsDir = $script:BasketResultsDir; PastPath = $script:BasketPastPath; Replay = $script:BasketReplay; ReplayCodes = $script:BasketReplayCodes }
        [void]$ps.AddScript($sb.ToString()).AddArgument($prm)
        $script:BasketRecJob = @{ PS = $ps; RS = $rs; Handle = $ps.BeginInvoke(); Stamp = $stamp }
        $script:BasketRecTimer.Start()
    } catch {
        if ($ps) { try { $ps.Dispose() } catch {} }; if ($rs) { try { $rs.Dispose() } catch {} }
        $script:BasketRecJob = $null
        Read-BasketRecords -Force   # arka plan açılamazsa eskisi gibi
    }
}
$script:BasketRecTimer = New-Object System.Windows.Threading.DispatcherTimer; $script:BasketRecTimer.Interval = [TimeSpan]::FromMilliseconds(400)
$script:BasketRecTimer.Add_Tick({
    $job = $script:BasketRecJob
    if ($null -eq $job) { $script:BasketRecTimer.Stop(); return }
    if (-not $job.Handle.IsCompleted) { return }
    $script:BasketRecTimer.Stop(); $script:BasketRecJob = $null
    try {
        $out = $job.PS.EndInvoke($job.Handle)
        $res = $null; foreach ($o in $out) { if ($null -ne $o -and $o -is [hashtable]) { $res = $o } }   # (hashtable'da .BaseObject anahtar sanılır)
        if ($null -eq $res -or $job.PS.HadErrors -and $null -eq $res) { throw ($(if ($job.PS.Streams.Error.Count -gt 0) { $job.PS.Streams.Error[0].ToString() } else { 'sonuç gelmedi' })) }
        $script:BasketHistory = @($res.History); $script:BasketReplay = $res.Replay; $script:BasketReplayCodes = $res.ReplayCodes; $script:BasketReplaySummary = [string]$res.Summary
        Show-BasketRecordGrid
        (Find-BasketControl 'LeagueGrid').ItemsSource = $res.League
        $script:BasketRecordStamp = [string]$job.Stamp
    } catch {
        try { (Find-BasketControl 'RecordSummary').Text = 'Kayıtlar arka planda okunamadı (' + $_.Exception.Message + '); Yenile ile tekrar dene.' } catch {}
    } finally { try { $job.PS.Dispose() } catch {}; try { $job.RS.Dispose() } catch {} }
})
function Start-BasketJob([string]$kind, [string[]]$codes, [int]$offset, [int]$days, [bool]$pastOnly = $false, [string]$requestedDay = '', [string]$providerId = '', [hashtable]$references = $null) {
    if ($script:BasketJobs) { return }
    if ($script:BasketShared.Busy) { $script:BasketShared.Stop = $true }
    $rs = $null; $ps = $null
    $target = if ($kind -eq 'single') { 'WorkStatus' } else { 'BatchStatus' }
    Set-BasketButtons $false
    (Find-BasketControl $target).Text = 'Maç verisi alınıyor…'
    try {
        $rs = [runspacefactory]::CreateRunspace()
        $rs.Open()
        $rs.SessionStateProxy.SetVariable('Shared', [hashtable]::Synchronized(@{
            DataDir = $script:DataDir; Delay = 1500; Req = 0
            LogPath = (Join-Path $script:DataDir 'basket_tahmin_log.txt')
            Lines = (New-Object System.Collections.ArrayList)
        }))
        $ps = [powershell]::Create()
        $ps.Runspace = $rs
        [void]$ps.AddScript($script:BasketForecastWorker).AddStatement()
        if ($kind -eq 'list') {
            [void]$ps.AddCommand('Get-BSelectedBulletin').AddArgument($offset).AddArgument($days)
        } else {
            [void]$ps.AddCommand('Get-BForecasts').AddArgument($script:BasketModelPath).AddArgument($script:BasketSeedPath).AddArgument($codes).AddArgument($offset).AddArgument($days).AddArgument((Join-Path $script:AppDir 'Basket_Nesine_Oran_Arsivi.csv')).AddArgument($pastOnly).AddArgument((Join-Path $script:AppDir 'Basket_Nesine_Skor_Arsivi.csv')).AddArgument($requestedDay).AddArgument($providerId).AddArgument($references)
        }
        $script:BasketJobs = @{ PowerShell = $ps; Runspace = $rs; Handle = $ps.BeginInvoke(); Kind = $kind; Target = $target }
    } catch {
        if ($ps) { $ps.Dispose() }
        if ($rs) { $rs.Dispose() }
        (Find-BasketControl $target).Text = $_.Exception.Message
        Set-BasketButtons $true
    }
}

function Complete-BasketJob {
    $job = $script:BasketJobs
    if (-not $job -or -not $job.Handle.IsCompleted) { return }
    $script:BasketJobs = $null
    try {
        $rows = @($job.PowerShell.EndInvoke($job.Handle))
        if ($job.PowerShell.HadErrors) { throw ([string]$job.PowerShell.Streams.Error[0]) }
        switch ($job.Kind) {
            'list' {
                $script:BasketBatchRows = @($rows | ForEach-Object {
                    $kick = [DateTimeOffset]::FromUnixTimeSeconds($_.Kick).ToOffset([TimeSpan]::FromHours(3))
                    [pscustomobject]@{Code=$_.Code;Time=$kick.ToString('yyyy-MM-dd HH:mm');Home=$_.Home;Away=$_.Away;League=$_.League;Expected='';Candidate='';Actual='';Mode='Maç öncesi';Status='Analiz bekliyor';Lines=@()}
                })
                (Find-BasketControl 'BatchGrid').ItemsSource = $script:BasketBatchRows
                (Find-BasketControl 'BatchStatus').Text = "$($rows.Count) maç bulundu. Analiz için BAŞLAT."
            }
            'single' {
                if ($rows.Count -eq 0) { Set-BasketMatch $null 'Bu maçın takım ve tarih bilgisi maç kayıtlarında bulunamadı.' }
                else {
                    if ($rows[0].Mode -eq 'Geçmiş maç') { (Find-BasketControl 'ModePast').IsChecked = $true }
                    Set-BasketMatch $rows[0]; Save-BasketAnalysis $rows; Save-BasketSonKarar $rows
                }
            }
            'batch' { Set-BasketBatch $rows; Save-BasketAnalysis $rows; Save-BasketSonKarar $rows }
        }
    } catch {
        (Find-BasketControl $job.Target).Text = 'İşlem tamamlanamadı. ' + $_.Exception.Message
    } finally {
        try { $job.PowerShell.Dispose() } catch {}
        try { $job.Runspace.Close() } catch {}
        try { $job.Runspace.Dispose() } catch {}
        try { Set-BasketButtons $true } catch {}
    }
}

$script:BasketTick = New-Object System.Windows.Threading.DispatcherTimer
$script:BasketTick.Interval = [TimeSpan]::FromMilliseconds(350)
$script:BasketTick.Add_Tick({
    try { Complete-BasketJob }
    catch {
        try { (Find-BasketControl 'WorkStatus').Text = 'Analiz sonucu ekrana yazılamadı; pencere açık kaldı. ' + $_.Exception.Message } catch {}
        try { (Find-BasketControl 'BatchStatus').Text = 'İşlem sonucu ekrana yazılamadı; pencere açık kaldı. ' + $_.Exception.Message } catch {}
        try { Set-BasketButtons $true } catch {}
    }
})
$script:BasketTick.Start()
(Find-BasketControl 'UrlBox').Add_TextChanged({
    (Find-BasketControl 'UrlHint').Visibility = if ((Find-BasketControl 'UrlBox').Text) { 'Collapsed' } else { 'Visible' }
})
(Find-BasketControl 'OpenBasketNesine').Add_Click({
    $value = (Find-BasketControl 'UrlBox').Text.Trim()
    $code = Get-BasketMatchCode $value
    if (-not $code) {
        (Find-BasketControl 'WorkStatus').Text = 'Önce maç bağlantısı veya kodu gir.'
        return
    }
    $target = $null
    $uri = $null
    if ([uri]::TryCreate($value, [UriKind]::Absolute, [ref]$uri) -and
        $uri.Host -in @('nesine.com','www.nesine.com','istatistik.nesine.com')) {
        $target = $uri.AbsoluteUri
    } else {
        $target = 'https://istatistik.nesine.com/' + $code + '/ozet'
    }
    try { Start-Process $target }
    catch { (Find-BasketControl 'WorkStatus').Text = 'Site sayfası açılamadı. ' + $_.Exception.Message }
})
(Find-BasketControl 'ModelLineButton').Add_Click({
    if ($null -ne $script:BasketShownMatch) {
        Show-BasketModelLines $script:BasketShownMatch ((Find-BasketControl 'ModelLineInput').Text.Trim())
    }
})
(Find-BasketControl 'RefreshButton').Add_Click({
    try {
    $value = (Find-BasketControl 'UrlBox').Text.Trim()
    $pastMode = (Find-BasketControl 'ModePast').IsChecked
    $code = Get-BasketMatchCode $value
    if ($pastMode -and -not $code -and $value -match '^[A-Za-z0-9]{8}$') { $code = $value }
    if (-not $code) { Set-BasketMatch $null 'Maç bağlantısını veya maç kodunu gir.'; return }
    $reference = Get-BasketMatchReference $value
    $requestedDay = $reference.Day
    $providerId = $reference.ProviderId
    $requestedDatePrefix = if ($requestedDay) { $requestedDay.Insert(4, '-').Insert(7, '-') }
    if ($pastMode -and @($script:BasketHistory).Count -eq 0) { Read-BasketRecords }   # 120: maç öncesi analizde kayıt beklenmez; okunmuş liste kullanılır
    $nowTr = ([DateTimeOffset]::UtcNow).ToOffset([TimeSpan]::FromHours(3)).ToString('yyyy-MM-dd HH:mm')
    $r = $script:BasketHistory | Where-Object {
        $_.Code -ceq $code -and $_.Time -le $nowTr -and $_.Expected -and
            (-not $requestedDatePrefix -or ([string]$_.Time).StartsWith($requestedDatePrefix)) -and
            (-not $providerId -or [string]$_.Actual)
    } | Sort-Object -Property @{Expression = { [bool]$_.ReplaySource }} | Select-Object -First 1
    if ($null -ne $r) {
        (Find-BasketControl 'ModePast').IsChecked = $true
        Set-BasketMatch $r
        return
    }
    if ($pastMode -and $code -notmatch '^\d{5,14}$') {
        Set-BasketMatch $null 'Bu maç için geçmiş analiz kaydı bulunamadı.'
        return
    }
    Set-BasketMatch $null
    Start-BasketJob 'single' @($code) 0 8 $pastMode $requestedDay $providerId
    } catch {
        (Find-BasketControl 'WorkStatus').Text = 'Analiz başlatılamadı; pencere açık kaldı. ' + $_.Exception.Message
        Set-BasketButtons $true
    }
})
(Find-BasketControl 'ListFetch').Add_Click({
    (Find-BasketControl 'SuggestionGrid').ItemsSource = $null
    (Find-BasketControl 'SuggestionsStatus').Text = 'Kupon sekmesinde analiz başlat.'
    (Find-BasketControl 'BatchUrls').Clear()
    if ((Find-BasketControl 'ListDone').IsChecked) {
        $script:BasketBatchMode = 'Geçmiş maç'
        if (@($script:BasketHistory).Count -eq 0) { Read-BasketRecords } else { Start-BasketRecordLoad }   # 120
        $script:BasketBatchRows = @(Get-BasketFinishedRows)
        (Find-BasketControl 'BatchGrid').ItemsSource = $script:BasketBatchRows
        (Find-BasketControl 'BatchStatus').Text = "$($script:BasketBatchRows.Count) bitmiş maç kaydı."
        return
    }
    $script:BasketBatchMode = 'Maç öncesi'
    $script:BasketOffset = if ((Find-BasketControl 'ListTomorrow').IsChecked) { 1 } else { 0 }
    $script:BasketDays = if ((Find-BasketControl 'ListThree').IsChecked) { 3 } else { 1 }
    $script:BasketBatchRows = @()
    (Find-BasketControl 'BatchGrid').ItemsSource = $null
    Start-BasketJob 'list' @() $script:BasketOffset $script:BasketDays
})
(Find-BasketControl 'BatchStart').Add_Click({
    try {
    $inputText = (Find-BasketControl 'BatchUrls').Text.Trim()
    $references = @{}
    foreach ($entry in ($inputText -split '[\r\n]+')) {
        $code = Get-BasketMatchCode $entry
        if (-not $code) { continue }
        $reference = Get-BasketMatchReference $entry
        if ($reference -or -not $references.ContainsKey($code)) { $references[$code] = $reference }
    }
    $codes = @($references.Keys)
    if ($inputText -and $codes.Count -eq 0) { (Find-BasketControl 'BatchStatus').Text = 'Geçerli maç bağlantısı veya kodu bulunamadı.'; return }
    if ((Find-BasketControl 'ListDone').IsChecked -and $codes.Count -gt 0) {
        Start-BasketJob 'batch' $codes 0 8 $true '' '' $references
    } elseif ((Find-BasketControl 'ListDone').IsChecked) {
        if (@($script:BasketHistory).Count -eq 0) { Read-BasketRecords } else { Start-BasketRecordLoad }   # 120
        $past = @(Get-BasketFinishedRows)
        Set-BasketBatch $past
        (Find-BasketControl 'SuggestionGrid').ItemsSource = $null
        (Find-BasketControl 'SuggestionsStatus').Text = 'Maç öncesi kupon analizi başlat.'
    } elseif ($codes.Count -gt 0) {
        Start-BasketJob 'batch' $codes 0 8 $false '' '' $references
    } elseif ($script:BasketBatchMode -eq 'Maç öncesi' -and $script:BasketBatchRows.Count -gt 0) {
        Start-BasketJob 'batch' @($script:BasketBatchRows | ForEach-Object { [string]$_.Code }) $script:BasketOffset $script:BasketDays
    } else {
        (Find-BasketControl 'BatchStatus').Text = "Önce maçları getir veya bağlantıları gir."
    }
    } catch {
        (Find-BasketControl 'BatchStatus').Text = 'Kupon analizi başlatılamadı; pencere açık kaldı. ' + $_.Exception.Message
        Set-BasketButtons $true
    }
})
(Find-BasketControl 'BatchOpen').Add_Click({ Show-BasketSelected 'BatchGrid' })
(Find-BasketControl 'BatchGrid').Add_MouseDoubleClick({ Show-BasketSelected 'BatchGrid' })
(Find-BasketControl 'SuggestionOpen').Add_Click({ Show-BasketSelected 'SuggestionGrid' })
(Find-BasketControl 'RecordOpen').Add_Click({ Show-BasketSelected 'RecordGrid' })
(Find-BasketControl 'RecordGrid').Add_MouseDoubleClick({ Show-BasketSelected 'RecordGrid' })
# 95. düzeltme: Kayıtlar renkli (futbol Kayıtlar'ı gibi): OYNA satırı yeşil, Karar hücresi yeşil kutu; Sonuç: Tuttu yeşil, Tutmadı soluk (kırmızı yok)
try {
    $ns = 'xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"'
    $rx = '<Style ' + $ns + ' TargetType="DataGridRow"><Style.Triggers><DataTrigger Binding="{Binding Karar}" Value="OYNA"><Setter Property="Background" Value="#12301F"/><Setter Property="Foreground" Value="#DCFCE7"/></DataTrigger><Trigger Property="IsSelected" Value="True"><Setter Property="Background" Value="#2D5BB8"/></Trigger></Style.Triggers></Style>'
    (Find-BasketControl 'RecordGrid').RowStyle = [System.Windows.Markup.XamlReader]::Parse($rx)
    $kx = '<Style ' + $ns + ' TargetType="DataGridCell"><Setter Property="BorderThickness" Value="0"/><Style.Triggers><DataTrigger Binding="{Binding Karar}" Value="OYNA"><Setter Property="Background" Value="#1E8449"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="FontWeight" Value="SemiBold"/></DataTrigger></Style.Triggers></Style>'
    $sx = '<Style ' + $ns + ' TargetType="DataGridCell"><Setter Property="BorderThickness" Value="0"/><Style.Triggers><DataTrigger Binding="{Binding KararSonuc}" Value="Tuttu"><Setter Property="Foreground" Value="#4ADE80"/><Setter Property="FontWeight" Value="Bold"/></DataTrigger><DataTrigger Binding="{Binding KararSonuc}" Value="Tutmadı"><Setter Property="Foreground" Value="#8197AE"/></DataTrigger></Style.Triggers></Style>'
    foreach ($col in (Find-BasketControl 'RecordGrid').Columns) {
        if ([string]$col.Header -eq 'Karar') { $col.CellStyle = [System.Windows.Markup.XamlReader]::Parse($kx) }
        elseif ([string]$col.Header -eq 'Sonuç') { $col.CellStyle = [System.Windows.Markup.XamlReader]::Parse($sx) }
    }
} catch {}
(Find-BasketControl 'ReloadRecords').Add_Click({ Start-BasketRecordLoad -Force })   # 120: arka planda
(Find-BasketControl 'RecordSearch').Add_TextChanged({ Show-BasketRecordGrid })
(Find-BasketControl 'RecordFilter').Add_SelectionChanged({ Show-BasketRecordGrid })
(Find-BasketControl 'MainTabs').Add_SelectionChanged({
    param($sender,$e)
    if ($e.OriginalSource -eq $sender -and $sender.SelectedIndex -in @(3,4)) { Start-BasketRecordLoad }   # 120: arka planda
})
if ($null -eq $HostContainer) {
    $script:BasketWindow.Add_Closing({
        param($sender,$e)
        if ($script:BasketJobs) { $e.Cancel = $true }
        else { $script:BasketTick.Stop() }
    })
}

(Find-BasketControl 'RunButton').Add_Click({ Start-BCycle })
(Find-BasketControl 'StatsButton').Add_Click({ Start-BStats })
(Find-BasketControl 'StopButton').Add_Click({ $script:BasketShared.Stop = $true; (Find-BasketControl 'StatusText').Text = 'Durduruluyor…' })
(Find-BasketControl 'FolderButton').Add_Click({ try { Start-Process explorer.exe -ArgumentList ('"' + $script:DataDir + '"') } catch {} })
(Find-BasketControl 'PackButton').Add_Click({
    $note = Find-BasketControl 'PackNote'
    try {
        foreach ($an in @('System.IO.Compression', 'System.IO.Compression.FileSystem')) { try { Add-Type -AssemblyName $an -ErrorAction Stop } catch {} }
        $desk = [Environment]::GetFolderPath('Desktop'); if (-not $desk -or -not (Test-Path -LiteralPath $desk)) { $desk = $script:DataDir }
        $zip = Join-Path $desk ('BAM_gonder_' + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.zip')
        if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
        $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('bam_gonder_' + [Guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Path $tmp -Force | Out-Null
        $n = 0
        try {
            foreach ($f in @(Get-ChildItem -LiteralPath $script:DataDir -File | Where-Object { $_.Name -like 'basket_*' })) {
                $fs = New-Object System.IO.FileStream($f.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
                try { $out = [System.IO.File]::Create((Join-Path $tmp $f.Name)); try { $fs.CopyTo($out) } finally { $out.Close() } } finally { $fs.Close() }
                $n++
            }
            if (Test-Path -LiteralPath $script:BasketResultsDir) {
                $recordExport = Join-Path $tmp 'AnalizKayitlari'
                [void][IO.Directory]::CreateDirectory($recordExport)
                foreach ($record in (Get-ChildItem -LiteralPath $script:BasketResultsDir -Filter '*.json' -File)) {
                    Copy-Item -LiteralPath $record.FullName -Destination $recordExport -ErrorAction Stop
                    $n++
                }
            }
            if ($n -eq 0) { throw 'Henüz toplanmış veri yok.' }
            $ok = $false
            try { [System.IO.Compression.ZipFile]::CreateFromDirectory($tmp, $zip); $ok = $true } catch { if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue } }
            if (-not $ok) { Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zip -Force -ErrorAction Stop }
        } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
        $note.Text = 'Hazır: ' + $zip + ' (' + $n + ' dosya). Bana bu zip''i gönder.'
        try { Start-Process explorer.exe -ArgumentList ('/select,"' + $zip + '"') } catch {}
    } catch { $note.Text = 'Zip yapılamadı: ' + $_.Exception.Message }
})
$script:BasketUiStarted = $false
# 131. düzeltme: BASKET HÜCRE DENETİMİ (futboldaki gibi; Basket_Tahmin.ps1'deki BasketHucre). Arka planda: açılıştan 90 sn sonra (basket_hucre.txt yoksa
# ya da 12 saatten eskiyse), sonra 12 saatte bir. Satırlar: Flashscore arşivi (Basket_Arsiv_Testi) + sonucu belli kaydedilen analizler. Ekler değişince
# arşiv ve kayıt kararları yeni sürümle yeniden hesaplanır (Kayıtlar ekranı kendiliğinden yenilenir).
[void](Initialize-BHucre $script:DataDir)
$script:BHucreJob = $null; $script:BHucreNext = (Get-Date).AddSeconds(90); $script:BHucreYenile = $false
function Write-BHucreLog([string]$m) {
    $l = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m; [void]$script:BasketShared.Lines.Add($l)
    try { [IO.File]::AppendAllText($script:BasketShared.LogPath, $l + "`r`n", (New-Object System.Text.UTF8Encoding $false)) } catch {}
}
function Get-BHucreText {
    if ($null -ne $script:BHucreJob) { return 'Hücre denetimi arka planda çalışıyor (başlangıç ' + $script:BHucreJob.At.ToString('HH:mm:ss') + '; birkaç dakika sürer)…' }
    $s = $null; try { $s = [BasketHucre.Hucre]::Aktif } catch {}
    if ($null -eq $s) { return 'Hücre denetimi (maç toplamı Alt / Üst): açılıştan 1,5 dakika sonra arka planda çalışır. Kural futboldaki gibi: görmediği günlerde katkısı artıysa girer, OYNA''yı bozan girmez.' }
    $t = 'Hücre denetimi (maç toplamı Alt / Üst) · son: ' + $s.Tarih
    foreach ($sl in $s.Satirlar) { $sp = $sl.Split('|'); if ($sp.Count -ge 5) { $t += ' · açık: ' + $sp[2] + ' · girmeyenler: ' + $sp[3] } }
    foreach ($r in $s.Rapor) { $t += ' · ' + $r }
    if ($s.Hata) { $t += ' · hata: ' + $s.Hata }
    return $t
}
function Show-BHucre { try { (Find-BasketControl 'BHucreDurum').Text = (Get-BHucreText) } catch {} }
# 132: ekrandaki (Kupon / Kupon önerisi) analizler ve kaydedilmiş oynanacak maçlar yeni eklerle yeniden hesaplanır ve kaydedilir
function Update-BHucreEkran {
    $n0 = 0; $n1 = 0; $dg = 0
    try {
        $rows = @($script:BasketBatchRows | Where-Object { $null -ne $_ })
        if ($rows.Count -gt 0) {
            $o0 = @($rows | Where-Object { $_.Karar -eq 'OYNA' }).Count
            foreach ($r in $rows) { $k0 = [string]$r.KararText; Set-BKarar $r; if ([string]$r.KararText -ne $k0) { $dg++ } }
            Set-BasketBatch $rows; Save-BasketAnalysis $rows; Save-BasketSonKarar $rows
            $n0 = $o0; $n1 = @($rows | Where-Object { $_.Karar -eq 'OYNA' }).Count
        }
        # kaydedilmiş ve henüz oynanmamış site analizleri (Kupon önerisi bunlardan da okuyabilir)
        $sv = 0
        if (Test-Path -LiteralPath $script:BasketResultsDir) {
            $now = (Get-Date).AddHours(-3).ToString('yyyy-MM-dd HH:mm')
            $up = New-Object System.Collections.ArrayList
            $lim3 = (Get-Date).AddDays(-3)
            foreach ($f in (Get-ChildItem -LiteralPath $script:BasketResultsDir -Filter '*.json' -File | Where-Object { $_.LastWriteTime -ge $lim3 } | Sort-Object LastWriteTime -Descending | Select-Object -First 200)) {
                try { $r = ConvertFrom-Json ([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)); if ($null -ne $r -and [string]$r.Time -ge $now -and [string]$r.Mode -eq 'Maç öncesi') { $k0 = [string]$r.KararText; Set-BKarar $r; if ([string]$r.KararText -ne $k0) { $sv++ }; [void]$up.Add($r) } } catch {}
            }
            if ($up.Count -gt 0) { Save-BasketAnalysis @($up); Save-BasketSonKarar @($up) }
        }
        Write-BHucreLog ('Hücre denetimi ekrana işlendi: ekrandaki ' + $rows.Count + ' analizin ' + $dg + ' tanesinde karar değişti (OYNA ' + $n0 + ' → ' + $n1 + '); kaydedilmiş oynanacak analizlerde ' + $sv + ' karar değişti')
    } catch { Write-BHucreLog ('Hücre denetimi ekrana işlenemedi: ' + $_.Exception.Message) }
}
function Start-BHucreDenetim {
    if ($null -ne $script:BHucreJob) { return }
    $rs = [runspacefactory]::CreateRunspace(); $rs.Open(); $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript({
        param($p)
        try {
            # tahmin kodu (takım kimliği eşleştirme: Resolve-BHucreIds) bu iş parçacığında da
            $global:Shared = [hashtable]::Synchronized(@{ DataDir = $p.Dir; LogPath = (Join-Path $p.Dir 'basket_tahmin_log.txt'); Lines = (New-Object System.Collections.ArrayList) })
            . ([scriptblock]::Create($p.Worker))
            $inv = [System.Globalization.CultureInfo]::InvariantCulture
            $sb = New-Object System.Text.StringBuilder; [void]$sb.Append("kod;zaman;lig;gercek;cizgiler;prog;sapma;ev_id;dep_id`n")
            $add = {
                param($r, [double]$act)
                if ($null -eq $r -or $null -eq $r.Lines -or $act -le 0) { return }
                $ls = @(foreach ($l in @($r.Lines)) { if ($null -ne $l -and [string]$l.Line -and [string]$l.UnderOdds -and [string]$l.OverOdds) { [string]$l.Line + ':' + [string]$l.UnderOdds + ':' + [string]$l.OverOdds } }) -join '|'
                if (-not $ls -or ([string]$r.Time).Length -lt 16) { return }
                $pp = $r.PSObject.Properties; $pt = ''; $sd = ''
                $x = 0.0; if ($pp['ProgToplam'] -and $null -ne $r.ProgToplam -and [double]::TryParse(([string]$r.ProgToplam).Replace(',', '.'), [System.Globalization.NumberStyles]::Float, $inv, [ref]$x)) { $pt = $x.ToString($inv); $y = 0.0; if ($pp['ProgSapma'] -and [double]::TryParse(([string]$r.ProgSapma).Replace(',', '.'), [System.Globalization.NumberStyles]::Float, $inv, [ref]$y)) { $sd = $y.ToString($inv) } else { $pt = '' } }
                [void]$sb.Append(([string]$r.Code + ';' + [string]$r.Time + ';' + (([string]$r.League) -replace '[;\r\n]', ' ') + ';' + $act.ToString($inv) + ';' + $ls + ';' + $pt + ';' + $sd + ';' + $(if ($pp['HomeId']) { [string]$r.HomeId }) + ';' + $(if ($pp['AwayId']) { [string]$r.AwayId }) + "`n"))
            }
            # Flashscore arşivi
            if ($p.Arsiv -and (Test-Path -LiteralPath $p.Arsiv)) { foreach ($f in (Get-ChildItem -LiteralPath $p.Arsiv -Filter '*.json' -File)) { foreach ($r in (ConvertFrom-Json ([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)))) { $a = 0.0; if ([double]::TryParse([string]$r.Actual, [System.Globalization.NumberStyles]::Float, $inv, [ref]$a)) { & $add $r $a } } } }
            # sonucu belli kaydedilmiş site analizleri (skor: basket_nesine_sonuclar.csv; takım kimliği yoksa Flashscore maçlarıyla eşleştirilir)
            $sc = @{}; $sp = Join-Path $p.Dir 'basket_nesine_sonuclar.csv'
            if (Test-Path -LiteralPath $sp) { foreach ($l in [IO.File]::ReadAllLines($sp, [Text.Encoding]::UTF8)) { $c = $l.Split(';'); if ($c.Count -ge 9 -and $c[7] -match '^\d+$' -and $c[8] -match '^\d+$') { $sc[$c[0]] = @($c[2], ([int]$c[7] + [int]$c[8])) } } }
            if ($p.Kayit -and (Test-Path -LiteralPath $p.Kayit)) {
                foreach ($f in (Get-ChildItem -LiteralPath $p.Kayit -Filter '*.json' -File)) {
                    try {
                        $r = ConvertFrom-Json ([IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)); $k = [string]$r.Code
                        if (-not $sc.ContainsKey($k)) { continue }
                        $t1 = [datetime]::MinValue; $t2 = [datetime]::MinValue
                        if (-not [datetime]::TryParseExact([string]$r.Time, 'yyyy-MM-dd HH:mm', $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t1) -or -not [datetime]::TryParseExact([string]$sc[$k][0], 'yyyy-MM-dd HH:mm', $inv, [System.Globalization.DateTimeStyles]::None, [ref]$t2) -or [Math]::Abs(($t1 - $t2).TotalMinutes) -gt 90) { continue }
                        if (-not $r.PSObject.Properties['HomeId'] -or -not [string]$r.HomeId) { [void](Resolve-BHucreIds $r) }
                        & $add $r ([double]$sc[$k][1])
                    } catch {}
                }
            }
            $rp = Join-Path $p.Dir 'basket_hucre_satirlar.csv'
            [IO.File]::WriteAllText($rp, $sb.ToString(), (New-Object System.Text.UTF8Encoding $false))
            if (-not ('BasketHucre.Hucre' -as [type])) { Add-Type -TypeDefinition $p.Code }
            $h = [BasketHucre.Hucre]::Audit($rp, $p.Dir, $p.Ka, $p.Ku, $p.Kan, $p.Kun, $p.Kk, $p.Esik, $p.EnDusuk, $p.Payi)
            if (-not $h.Hata) { [BasketHucre.Hucre]::Save($h, (Join-Path $p.Dir 'basket_hucre.txt')) }
            return , $h
        } catch { return ('hata: ' + $_.Exception.Message) }
    }).AddArgument(@{ Arsiv = (Get-BasketFilePath 'Basket_Arsiv_Testi'); Kayit = $script:BasketResultsDir; Dir = $script:DataDir; Code = $global:BHucreCode; Worker = $script:BasketForecastWorker
        Ka = [double[]]$global:BOranKatsayi['Alt']; Ku = [double[]]$global:BOranKatsayi['Üst']; Kan = [double[]]$global:BOranKatsayi['NBA Alt']; Kun = [double[]]$global:BOranKatsayi['NBA Üst']
        Kk = [double[]]$global:BProgKarisim; Esik = [double]$global:BOynaSiniri; EnDusuk = [double]$global:BEnDusukOran; Payi = [double]$global:BNesinePayi })
    $script:BHucreJob = [pscustomobject]@{ PS = $ps; RS = $rs; Handle = $ps.BeginInvoke(); At = Get-Date }
    Write-BHucreLog 'Hücre denetimi başladı (maç toplamı Alt / Üst; takım karnesi, iç / dış, form, dinlenme, periyot karnesi, yarı karnesi, uzatma, puan gücü; görmediği günlerde ölçülür)'
    Show-BHucre
}
function Complete-BHucreDenetim {
    $j = $script:BHucreJob; if ($null -eq $j -or -not $j.Handle.IsCompleted) { return }
    $script:BHucreJob = $null; $h = $null; $err = ''
    try { foreach ($o in $j.PS.EndInvoke($j.Handle)) { if ($o -is [BasketHucre.Sonuc]) { $h = $o } elseif ($o -is [string]) { $err = $o } } } catch { $err = $_.Exception.Message }
    try { $j.PS.Dispose(); $j.RS.Dispose() } catch {}
    $sn = [Math]::Round(((Get-Date) - $j.At).TotalSeconds)
    if ($null -eq $h -or $h.Hata) { Write-BHucreLog ('Hücre denetimi yapılamadı (' + $sn + ' sn): ' + $(if ($null -ne $h) { $h.Hata } else { $err })); Show-BHucre; return }
    $old = [BasketHucre.Hucre]::Imza(); [BasketHucre.Hucre]::Aktif = $h; [void](Initialize-BHucre $script:DataDir)
    $new = [BasketHucre.Hucre]::Imza()
    $ac = ''; foreach ($sl in $h.Satirlar) { $sp = $sl.Split('|'); if ($sp.Count -ge 3) { $ac = $sp[2] } }
    Write-BHucreLog ('Hücre denetimi uygulandı (' + $sn + ' sn, ' + $h.Satir + ' biten maç): açık: ' + $ac + ' · ' + ($h.Rapor -join ' · ') + $(if ($new -ne $old) { ' · kararlar yeni eklerle yeniden hesaplanıyor (sürüm ' + $global:BKararSurum + ')' } else { ' · ekler aynı' }))
    if ($new -ne $old) { $script:BHucreYenile = $true }
    Show-BHucre
}
$script:BasketWindow.Add_Loaded({
    if ($script:BasketUiStarted) { return }
    $script:BasketUiStarted = $true
    if ($script:BasketWindow -is [System.Windows.Window]) {
        try { if ([System.Windows.SystemParameters]::WorkArea.Height -lt 740) { $script:BasketWindow.WindowState = 'Maximized' } } catch {}
    }
    # önceki günlüğün son satırları ve sayaçlar
    try { if (Test-Path -LiteralPath $script:BasketShared.LogPath) { $old = @(Get-Content -LiteralPath $script:BasketShared.LogPath -Encoding UTF8 -Tail 40); foreach ($l in $old) { (Find-BasketControl 'LogBox').AppendText($l + "`r`n") }; (Find-BasketControl 'LogBox').AppendText("— — —`r`n") } } catch {}
    Start-BCounts
    $script:Tick.Start()
})
if ($null -ne $HostContainer) {
    $OwnerWindow.Add_Closed({
        $script:BasketShared.Stop = $true
        $script:Tick.Stop()
        $script:BasketTick.Stop()
        if ($script:BasketJobs) { try { [void]$script:BasketJobs.PowerShell.BeginStop($null, $null) } catch {} }
        if ($script:Job) { try { [void]$script:Job.ps.BeginStop($null, $null) } catch {} }
        else { try { $script:Rs.Dispose() } catch {} }
    })
    [void]$HostContainer.Children.Add($script:BasketWindow)
} else {
    $script:BasketWindow.Add_Closing({ $script:BasketShared.Stop = $true; try { $script:Tick.Stop() } catch {} })
    [void]$script:BasketWindow.ShowDialog()
    try { $script:Rs.Close() } catch {}
}
