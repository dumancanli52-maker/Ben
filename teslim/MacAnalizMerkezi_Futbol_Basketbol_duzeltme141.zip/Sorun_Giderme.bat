@echo off
rem Sorun olursa bunu ac: siyah pencerede hata yazilari gorunur.
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0MacAnalizMerkezi.ps1" -Konsol
echo.
echo Program kapandi. Yukarida hata varsa fotografini gonder.
pause
