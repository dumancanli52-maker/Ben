@echo off
rem Programi siyah pencere olmadan acar.
start "" powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0MacAnalizMerkezi.ps1"
exit
